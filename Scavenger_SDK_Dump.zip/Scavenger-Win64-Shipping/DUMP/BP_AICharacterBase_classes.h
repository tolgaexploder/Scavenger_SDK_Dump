// BlueprintGeneratedClass BP_AICharacterBase.BP_AICharacterBase_C
// Size: 0x263c (Inherited: 0x25c0)
struct ABP_AICharacterBase_C : AS_AICharacter {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x25c0(0x08)
	struct US_BoneDataComponent* Scavenger BoneData; // 0x25c8(0x08)
	struct US_EquipmentComponent* Scavenger Equipment; // 0x25d0(0x08)
	struct UBlackboardComponent* Blackboard; // 0x25d8(0x08)
	struct US_ItemData* EquippedWeapon; // 0x25e0(0x08)
	enum class ES_AmmoType AmmoType; // 0x25e8(0x01)
	char UnknownData_25E9[0x7]; // 0x25e9(0x07)
	struct UDataTable* DropTable; // 0x25f0(0x08)
	struct FName DropTableRowName; // 0x25f8(0x08)
	float GearHead_AccumulatedDamage; // 0x2600(0x04)
	struct FVector GearHead_HitLocation; // 0x2604(0x0c)
	bool GearHead_Break; // 0x2610(0x01)
	bool GearHead_Break_Local; // 0x2611(0x01)
	char UnknownData_2612[0x2]; // 0x2612(0x02)
	struct FName BoneName; // 0x2614(0x08)
	bool HelmetBreakEnable; // 0x261c(0x01)
	char UnknownData_261D[0x3]; // 0x261d(0x03)
	struct UParticleSystem* Dismemberment_PS_Limb; // 0x2620(0x08)
	struct AActor* LastHitByAbilityActor; // 0x2628(0x08)
	struct UParticleSystem* Dismemberment_PS_Head; // 0x2630(0x08)
	int32_t AiGrenadeCount; // 0x2638(0x04)

	void GetLastHitByAbilityActor(struct AActor* ActorPerformingTheHIt); // Function BP_AICharacterBase.BP_AICharacterBase_C.GetLastHitByAbilityActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetLastHitByAbilityActor(struct AActor* ActorPerformingLastHit, struct AActor* ActorHit); // Function BP_AICharacterBase.BP_AICharacterBase_C.SetLastHitByAbilityActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetGrenadeCount(int32_t GrenadeInvCount); // Function BP_AICharacterBase.BP_AICharacterBase_C.GetGrenadeCount // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsFollowerCompanion(bool IsFollowerCompanion); // Function BP_AICharacterBase.BP_AICharacterBase_C.IsFollowerCompanion // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GrenadeCooldownTime(float GrenadeCooldownTime); // Function BP_AICharacterBase.BP_AICharacterBase_C.GrenadeCooldownTime // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	bool GetPingDialogueContext(struct AS_PlayerController* pingingPlayerController, struct FS_DialogueContext OutContext); // Function BP_AICharacterBase.BP_AICharacterBase_C.GetPingDialogueContext // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnRep_AiGrenadeCount(); // Function BP_AICharacterBase.BP_AICharacterBase_C.OnRep_AiGrenadeCount // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Handle Dismemberment VFX(struct FName InputPin, int32_t Bone Index Offset); // Function BP_AICharacterBase.BP_AICharacterBase_C.Handle Dismemberment VFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void TriggerHelmetBasedHardPing(struct UAnimMontage* FromLeftMontage, struct UAnimMontage* FromRightMontage, struct UAnimMontage* FromBackMontage, struct UAnimMontage* FromFrontMontage, struct FVector ImpactDirection); // Function BP_AICharacterBase.BP_AICharacterBase_C.TriggerHelmetBasedHardPing // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetupGrenadeDropListener(); // Function BP_AICharacterBase.BP_AICharacterBase_C.SetupGrenadeDropListener // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetEquippedWeaponsAndAmmo(); // Function BP_AICharacterBase.BP_AICharacterBase_C.GetEquippedWeaponsAndAmmo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SpawnWeapon(struct US_ItemData* WeaponItemDataOverride); // Function BP_AICharacterBase.BP_AICharacterBase_C.SpawnWeapon // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SpawnAmmo(enum class ES_AmmoType AmmoSource); // Function BP_AICharacterBase.BP_AICharacterBase_C.SpawnAmmo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void DropRelevantWeaponAndAmmo(float ChanceToDropWeapon, float ChanceToDropAmmo, struct US_ItemData* OverrideWeaponDrop); // Function BP_AICharacterBase.BP_AICharacterBase_C.DropRelevantWeaponAndAmmo // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void FootParticleFX(struct FVector WorldPosition, enum class EPhysicalSurface SurfaceType); // Function BP_AICharacterBase.BP_AICharacterBase_C.FootParticleFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	struct UAnimMontage* SelectAttackMontageVariant(struct TArray<struct UAnimMontage*> MontageVariations, enum class ES_WeaponMontageEvent attackEvent, enum class ES_TriggerType triggerType); // Function BP_AICharacterBase.BP_AICharacterBase_C.SelectAttackMontageVariant // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_AICharacterBase.BP_AICharacterBase_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void NotifyBoneEnteredSnow_BP(struct FName BoneName, struct FVector GroundPosition, float SnowHeight, struct UPhysicalMaterial* PhysicalMaterial); // Function BP_AICharacterBase.BP_AICharacterBase_C.NotifyBoneEnteredSnow_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void NotifyBoneLeftSnow_BP(struct FName BoneName, struct FVector GroundPosition, float SnowHeight, struct UPhysicalMaterial* PhysicalMaterial); // Function BP_AICharacterBase.BP_AICharacterBase_C.NotifyBoneLeftSnow_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void MakeJump(); // Function BP_AICharacterBase.BP_AICharacterBase_C.MakeJump // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void BaseGrenadeEvent(struct AActor* DamagedActor, float UnmodifiedDamageAmount, float ArmorDamageAmount, float HealthDamageAmount, struct FPointDamageEvent PointDamageEvent, struct FHitResult HitResult, struct AActor* CauseActor, enum class None DamageModifiersApplied, bool Critical); // Function BP_AICharacterBase.BP_AICharacterBase_C.BaseGrenadeEvent // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void DropEquipped(struct US_StatsComponent* StatsComponent, enum class ES_StatsState OldState, enum class ES_StatsState NewState); // Function BP_AICharacterBase.BP_AICharacterBase_C.DropEquipped // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnHit_BreakHelmet(struct AActor* DamagedActor, float UnmodifiedDamageAmount, float ArmorDamageAmount, float HealthDamageAmount, struct FPointDamageEvent PointDamageEvent, struct FHitResult HitResult, struct AActor* CauseActor, enum class None DamageModifiersApplied, bool Critical); // Function BP_AICharacterBase.BP_AICharacterBase_C.OnHit_BreakHelmet // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnEnterRagDoll_BP(struct FHitResult HitResult, float timeSinceHit); // Function BP_AICharacterBase.BP_AICharacterBase_C.OnEnterRagDoll_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void CustomEvent_OnRagdollRollback(struct AController* PredictiveInstigator); // Function BP_AICharacterBase.BP_AICharacterBase_C.CustomEvent_OnRagdollRollback // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void BP_HandleOnStatChange(enum class ES_StatType StatType, enum class ES_StatChangeCauseType CauseType, struct AActor* SourceActor, struct AController* InstigatorController, float OldStatValue, float StatValueChange, float NewStatValue); // Function BP_AICharacterBase.BP_AICharacterBase_C.BP_HandleOnStatChange // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void RevealAI(); // Function BP_AICharacterBase.BP_AICharacterBase_C.RevealAI // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetAIIgnored(); // Function BP_AICharacterBase.BP_AICharacterBase_C.SetAIIgnored // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateGrenadeCount(int32_t NewCount); // Function BP_AICharacterBase.BP_AICharacterBase_C.UpdateGrenadeCount // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_AICharacterBase(int32_t EntryPoint); // Function BP_AICharacterBase.BP_AICharacterBase_C.ExecuteUbergraph_BP_AICharacterBase // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

