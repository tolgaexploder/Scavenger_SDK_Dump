// BlueprintGeneratedClass BPI_Mantle.BPI_Mantle_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_Mantle_C : UInterface {

	void MakeJump(); // Function BPI_Mantle.BPI_Mantle_C.MakeJump // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

