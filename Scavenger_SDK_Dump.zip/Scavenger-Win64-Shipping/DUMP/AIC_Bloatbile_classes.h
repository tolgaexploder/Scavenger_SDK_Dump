// BlueprintGeneratedClass AIC_Bloatbile.AIC_Bloatbile_C
// Size: 0x8e5 (Inherited: 0x8cb)
struct AAIC_Bloatbile_C : AAIC_Scourge_BP_C {
	char UnknownData_8CB[0x5]; // 0x8cb(0x05)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x8d0(0x08)
	bool ShouldBeDamageable; // 0x8d8(0x01)
	char UnknownData_8D9[0x3]; // 0x8d9(0x03)
	struct FName Active_Target; // 0x8dc(0x08)
	bool IsLeader; // 0x8e4(0x01)

	void ReceiveBeginPlay(); // Function AIC_Bloatbile.AIC_Bloatbile_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceivePossess(struct APawn* possessedPawn); // Function AIC_Bloatbile.AIC_Bloatbile_C.ReceivePossess // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_AIC_Bloatbile(int32_t EntryPoint); // Function AIC_Bloatbile.AIC_Bloatbile_C.ExecuteUbergraph_AIC_Bloatbile // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

