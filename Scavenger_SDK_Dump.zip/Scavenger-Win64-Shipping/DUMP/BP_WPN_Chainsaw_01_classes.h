// BlueprintGeneratedClass BP_WPN_Chainsaw_01.BP_WPN_Chainsaw_01_C
// Size: 0xd60 (Inherited: 0xd50)
struct ABP_WPN_Chainsaw_01_C : AS_WeaponBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd50(0x08)
	struct UAkComponent* Ak; // 0xd58(0x08)

	void ReceiveBeginPlay(); // Function BP_WPN_Chainsaw_01.BP_WPN_Chainsaw_01_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_WPN_Chainsaw_01(int32_t EntryPoint); // Function BP_WPN_Chainsaw_01.BP_WPN_Chainsaw_01_C.ExecuteUbergraph_BP_WPN_Chainsaw_01 // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

