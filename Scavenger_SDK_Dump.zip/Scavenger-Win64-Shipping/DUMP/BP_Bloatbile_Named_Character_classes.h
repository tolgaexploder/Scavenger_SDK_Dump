// BlueprintGeneratedClass BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C
// Size: 0x2775 (Inherited: 0x2678)
struct ABP_Bloatbile_Named_Character_C : ABP_Bloatbile_Character_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2678(0x08)
	struct UChildActorComponent* SlukaSpawnChild; // 0x2680(0x08)
	struct US_OverheadMapIconComponent* S_OverheadMapIcon; // 0x2688(0x08)
	struct US_MapDetectableComponent* S_MapDetectable; // 0x2690(0x08)
	struct AS_AIController* AIC_NamedBloatbile; // 0x2698(0x08)
	int32_t PointValue; // 0x26a0(0x04)
	char UnknownData_26A4[0x4]; // 0x26a4(0x04)
	struct ABP_SlukaProxy_C* MapProxy; // 0x26a8(0x08)
	bool Dead; // 0x26b0(0x01)
	bool PlayDeathAnim; // 0x26b1(0x01)
	char UnknownData_26B2[0x6]; // 0x26b2(0x06)
	struct TArray<struct FS_ItemState> LocalLootArray; // 0x26b8(0x10)
	bool HelmetBreakEnable; // 0x26c8(0x01)
	char UnknownData_26C9[0x3]; // 0x26c9(0x03)
	float GearHead_AccumulatedDamage; // 0x26cc(0x04)
	bool GearHead_Break; // 0x26d0(0x01)
	char UnknownData_26D1[0x3]; // 0x26d1(0x03)
	struct FVector GearHead_HitLocation; // 0x26d4(0x0c)
	bool GearHead_Break_Local; // 0x26e0(0x01)
	char UnknownData_26E1[0x3]; // 0x26e1(0x03)
	float GearHead_AccumulatedDamage_2; // 0x26e4(0x04)
	bool GearHead_Break_2; // 0x26e8(0x01)
	bool GearHead_Break_Local_2; // 0x26e9(0x01)
	char UnknownData_26EA[0x2]; // 0x26ea(0x02)
	struct FName BoilName; // 0x26ec(0x08)
	float GearHead_AccumulatedDamage_3; // 0x26f4(0x04)
	bool GearHead_Break_3; // 0x26f8(0x01)
	bool GearHead_Break_Local_3; // 0x26f9(0x01)
	char UnknownData_26FA[0x2]; // 0x26fa(0x02)
	float GearHead_AccumulatedDamage_4; // 0x26fc(0x04)
	bool GearHead_Break_4; // 0x2700(0x01)
	bool GearHead_Break_Local_4; // 0x2701(0x01)
	char UnknownData_2702[0x2]; // 0x2702(0x02)
	float GearHead_AccumulatedDamage_5; // 0x2704(0x04)
	bool GearHead_Break_5; // 0x2708(0x01)
	bool GearHead_Break_Local_5; // 0x2709(0x01)
	char UnknownData_270A[0x6]; // 0x270a(0x06)
	struct FS_NamedLocationMetadata BannerData; // 0x2710(0x28)
	struct AS_PlayerController* LocalPlayer; // 0x2738(0x08)
	float IntroRange; // 0x2740(0x04)
	char UnknownData_2744[0x4]; // 0x2744(0x04)
	struct FTimerHandle IntroTimerHandle; // 0x2748(0x08)
	struct AS_PlayerCharacter* LastPlayerThatDestroyedBoil; // 0x2750(0x08)
	struct AS_PlayerCharacter* DamageInstigator; // 0x2758(0x08)
	int32_t BoilsDestroyed; // 0x2760(0x04)
	struct FName DisplayName; // 0x2764(0x08)
	struct FName Banner Subtitle; // 0x276c(0x08)
	enum class ES_LocationFaction Loc Faction; // 0x2774(0x01)

	void IsNamedWarlord(bool NamedWarlord); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.IsNamedWarlord // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsNamedBloatbile(bool NamedBloater); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.IsNamedBloatbile // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsNamedBear(bool NamedBear); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.IsNamedBear // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetBullRushVolume(struct USphereComponent* BullRushCollision); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.GetBullRushVolume // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsSluka(bool IsSluka); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.IsSluka // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnRep_AIC_NamedBloatbile(); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.OnRep_AIC_NamedBloatbile // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateBoilInfo(); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.UpdateBoilInfo // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void PlayerInIntroRange(bool InRange); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.PlayerInIntroRange // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnRep_SheDead(); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.OnRep_SheDead // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnRep_PlayDeathAnim(); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.OnRep_PlayDeathAnim // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTick(float DeltaSeconds); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void InitWanderingBoss(int32_t PointsValue); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.InitWanderingBoss // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void BndEvt__m_statsComponent_K2Node_ComponentBoundEvent_1_OnStateChange__DelegateSignature(struct US_StatsComponent* StatsComponent, enum class ES_StatsState OldState, enum class ES_StatsState NewState); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.BndEvt__m_statsComponent_K2Node_ComponentBoundEvent_1_OnStateChange__DelegateSignature // (BlueprintEvent) // @ game+0xffff8009123b0000
	void BossTest(int32_t NewParam); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.BossTest // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnEnterRagDoll_BP(struct FHitResult HitResult, float timeSinceHit); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.OnEnterRagDoll_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void MostlyDeadSluka(struct US_StatsComponent* StatsComponent, enum class ES_StatsState OldState, enum class ES_StatsState NewState); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.MostlyDeadSluka // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EVENT_PlayDeathAnim(); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.EVENT_PlayDeathAnim // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnHit_BreakBoil(struct AActor* DamagedActor, float UnmodifiedDamageAmount, float ArmorDamageAmount, float HealthDamageAmount, struct FPointDamageEvent PointDamageEvent, struct FHitResult HitResult, struct AActor* CauseActor, enum class None DamageModifiersApplied, bool Critical); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.OnHit_BreakBoil // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EVENT_CanPlaySlukaMusic(); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.EVENT_CanPlaySlukaMusic // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void BndEvt__m_statsComponent_K2Node_ComponentBoundEvent_2_OnStatChange__DelegateSignature(enum class ES_StatType StatType, enum class ES_StatChangeCauseType CauseType, struct AActor* SourceActor, struct AController* InstigatorController, float OldStatValue, float StatValueChange, float NewStatValue); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.BndEvt__m_statsComponent_K2Node_ComponentBoundEvent_2_OnStatChange__DelegateSignature // (BlueprintEvent) // @ game+0xffff8009123b0000
	void PostSelfDestruct(bool Interrupted); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.PostSelfDestruct // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetCachedVomitLocation(struct FTransform VomitLocation); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.SetCachedVomitLocation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReportDeathToGPM(); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.ReportDeathToGPM // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Bloatbile_Named_Character(int32_t EntryPoint); // Function BP_Bloatbile_Named_Character.BP_Bloatbile_Named_Character_C.ExecuteUbergraph_BP_Bloatbile_Named_Character // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

