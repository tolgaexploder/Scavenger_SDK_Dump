// BlueprintGeneratedClass BPI_PlayerCharacter.BPI_PlayerCharacter_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_PlayerCharacter_C : UInterface {

	void GetLastHitByAbiltiyActor(struct AActor* LastHitByAbilityActor); // Function BPI_PlayerCharacter.BPI_PlayerCharacter_C.GetLastHitByAbiltiyActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetLastHitByAbilityActor(struct AActor* ActorPerformingTheHIt, struct AActor* Actor); // Function BPI_PlayerCharacter.BPI_PlayerCharacter_C.SetLastHitByAbilityActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetCharacterAbility(bool NewParam); // Function BPI_PlayerCharacter.BPI_PlayerCharacter_C.GetCharacterAbility // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void FreedFromCocoon(); // Function BPI_PlayerCharacter.BPI_PlayerCharacter_C.FreedFromCocoon // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetGameVars(struct UBP_PlayerCharacterGameVarsTemplate_C* NewParam); // Function BPI_PlayerCharacter.BPI_PlayerCharacter_C.GetGameVars // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

