// BlueprintGeneratedClass BP_AutoPing_Vehicle.BP_AutoPing_Vehicle_C
// Size: 0x209 (Inherited: 0x209)
struct UBP_AutoPing_Vehicle_C : UBP_AutoPing_C {

	bool EvaluatePing_BP(struct AS_PlayerController* PlayerController); // Function BP_AutoPing_Vehicle.BP_AutoPing_Vehicle_C.EvaluatePing_BP // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

