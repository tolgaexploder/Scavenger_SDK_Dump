// BlueprintGeneratedClass BP_BloatbileFlatulence.BP_BloatbileFlatulence_C
// Size: 0x298 (Inherited: 0x290)
struct ABP_BloatbileFlatulence_C : AS_GameplayEffectVolume {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)

	void ReceiveBeginPlay(); // Function BP_BloatbileFlatulence.BP_BloatbileFlatulence_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_BloatbileFlatulence(int32_t EntryPoint); // Function BP_BloatbileFlatulence.BP_BloatbileFlatulence_C.ExecuteUbergraph_BP_BloatbileFlatulence // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

