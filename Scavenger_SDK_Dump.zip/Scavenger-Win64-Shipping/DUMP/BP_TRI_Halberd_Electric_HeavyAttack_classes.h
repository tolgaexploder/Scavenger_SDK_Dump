// BlueprintGeneratedClass BP_TRI_Halberd_Electric_HeavyAttack.BP_TRI_Halberd_Electric_HeavyAttack_C
// Size: 0x630 (Inherited: 0x624)
struct ABP_TRI_Halberd_Electric_HeavyAttack_C : ABP_TRI_Halberd_HeavyAttack_C {
	char UnknownData_624[0x4]; // 0x624(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x628(0x08)

	void ReceiveBeginPlay(); // Function BP_TRI_Halberd_Electric_HeavyAttack.BP_TRI_Halberd_Electric_HeavyAttack_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_TRI_Halberd_Electric_HeavyAttack(int32_t EntryPoint); // Function BP_TRI_Halberd_Electric_HeavyAttack.BP_TRI_Halberd_Electric_HeavyAttack_C.ExecuteUbergraph_BP_TRI_Halberd_Electric_HeavyAttack // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

