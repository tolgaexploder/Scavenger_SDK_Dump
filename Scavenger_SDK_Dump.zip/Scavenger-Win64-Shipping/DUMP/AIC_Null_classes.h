// BlueprintGeneratedClass AIC_Null.AIC_Null_C
// Size: 0x870 (Inherited: 0x868)
struct AAIC_Null_C : AS_AIController {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x868(0x08)

	void ReceiveBeginPlay(); // Function AIC_Null.AIC_Null_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_AIC_Null(int32_t EntryPoint); // Function AIC_Null.AIC_Null_C.ExecuteUbergraph_AIC_Null // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

