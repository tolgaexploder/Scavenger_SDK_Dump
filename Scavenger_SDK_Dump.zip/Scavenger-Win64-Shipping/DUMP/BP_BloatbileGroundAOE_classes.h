// BlueprintGeneratedClass BP_BloatbileGroundAOE.BP_BloatbileGroundAOE_C
// Size: 0x298 (Inherited: 0x290)
struct ABP_BloatbileGroundAOE_C : AS_GameplayEffectVolume {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)

	void ReceiveBeginPlay(); // Function BP_BloatbileGroundAOE.BP_BloatbileGroundAOE_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_BloatbileGroundAOE(int32_t EntryPoint); // Function BP_BloatbileGroundAOE.BP_BloatbileGroundAOE_C.ExecuteUbergraph_BP_BloatbileGroundAOE // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

