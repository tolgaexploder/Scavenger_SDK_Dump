// BlueprintGeneratedClass BTT_CombatRunnerExplode.BTT_CombatRunnerExplode_C
// Size: 0xf0 (Inherited: 0xa8)
struct UBTT_CombatRunnerExplode_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb0(0x08)
	struct AS_AIController* ScavengerController; // 0xb8(0x08)
	struct AActor* CurrentTarget; // 0xc0(0x08)
	float AttackAlpha; // 0xc8(0x04)
	struct FName IsPlayingAnimMontage; // 0xcc(0x08)
	bool Exploding; // 0xd4(0x01)
	char UnknownData_D5[0x3]; // 0xd5(0x03)
	struct FVector hitdirection; // 0xd8(0x0c)
	struct FVector Location; // 0xe4(0x0c)

	void ActivateSelfDestruct(); // Function BTT_CombatRunnerExplode.BTT_CombatRunnerExplode_C.ActivateSelfDestruct // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTT_CombatRunnerExplode.BTT_CombatRunnerExplode_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void PostSelfDestruct(bool Interrupted); // Function BTT_CombatRunnerExplode.BTT_CombatRunnerExplode_C.PostSelfDestruct // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatRunnerExplode(int32_t EntryPoint); // Function BTT_CombatRunnerExplode.BTT_CombatRunnerExplode_C.ExecuteUbergraph_BTT_CombatRunnerExplode // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

