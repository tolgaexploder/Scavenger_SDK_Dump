// BlueprintGeneratedClass BP_TRI_CompoundBow_Scatter.BP_TRI_CompoundBow_Scatter_C
// Size: 0x660 (Inherited: 0x658)
struct ABP_TRI_CompoundBow_Scatter_C : ABP_TRI_Bow_Compound_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x658(0x08)

	void ReceiveBeginPlay(); // Function BP_TRI_CompoundBow_Scatter.BP_TRI_CompoundBow_Scatter_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_TRI_CompoundBow_Scatter(int32_t EntryPoint); // Function BP_TRI_CompoundBow_Scatter.BP_TRI_CompoundBow_Scatter_C.ExecuteUbergraph_BP_TRI_CompoundBow_Scatter // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

