// BlueprintGeneratedClass BPI_EditorTick.BPI_EditorTick_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_EditorTick_C : UInterface {

	void EditorTick(struct FVector CameraPosition, struct FRotator CameraRotation); // Function BPI_EditorTick.BPI_EditorTick_C.EditorTick // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

