// BlueprintGeneratedClass BTT_FleeMoveTo.BTT_FleeMoveTo_C
// Size: 0xd4 (Inherited: 0xa8)
struct UBTT_FleeMoveTo_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xb0(0x08)
	struct AS_AIController* CachedAIController; // 0xb8(0x08)
	float MoveAcceptanceRadius; // 0xc0(0x04)
	float MoveStartTime; // 0xc4(0x04)
	float FleeMoveSpeedFactor; // 0xc8(0x04)
	struct FName IsStartling; // 0xcc(0x08)

	void OnMoveFinished_EDE00032424B57E1802B408B20E4B21F(struct AAIController* AIController, enum class EPathFollowingResult PathFollowingResult, enum class ENavPathEvent NavPathEvent, enum class EPathFollowingRequestResult PathFollowingRequestResult); // Function BTT_FleeMoveTo.BTT_FleeMoveTo_C.OnMoveFinished_EDE00032424B57E1802B408B20E4B21F // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnAlreadyAtTargetLocation(); // Function BTT_FleeMoveTo.BTT_FleeMoveTo_C.OnAlreadyAtTargetLocation // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_FleeMoveTo.BTT_FleeMoveTo_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_FleeMoveTo(int32_t EntryPoint); // Function BTT_FleeMoveTo.BTT_FleeMoveTo_C.ExecuteUbergraph_BTT_FleeMoveTo // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

