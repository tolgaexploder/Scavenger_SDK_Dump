// BlueprintGeneratedClass BTT_CombaSlukaAntic.BTT_CombaSlukaAntic_C
// Size: 0xd4 (Inherited: 0xa8)
struct UBTT_CombaSlukaAntic_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb0(0x08)
	struct AS_AIController* ScavengerController; // 0xb8(0x08)
	struct AActor* CurrentTarget; // 0xc0(0x08)
	bool ReturnTrue; // 0xc8(0x01)
	char UnknownData_C9[0x3]; // 0xc9(0x03)
	struct FName IsPlayingAnimMontage; // 0xcc(0x08)

	void Interrupted_B797AEE04D78C87D1F32A18E3C01A743(); // Function BTT_CombaSlukaAntic.BTT_CombaSlukaAntic_C.Interrupted_B797AEE04D78C87D1F32A18E3C01A743 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Completed_B797AEE04D78C87D1F32A18E3C01A743(); // Function BTT_CombaSlukaAntic.BTT_CombaSlukaAntic_C.Completed_B797AEE04D78C87D1F32A18E3C01A743 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTT_CombaSlukaAntic.BTT_CombaSlukaAntic_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombaSlukaAntic(int32_t EntryPoint); // Function BTT_CombaSlukaAntic.BTT_CombaSlukaAntic_C.ExecuteUbergraph_BTT_CombaSlukaAntic // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

