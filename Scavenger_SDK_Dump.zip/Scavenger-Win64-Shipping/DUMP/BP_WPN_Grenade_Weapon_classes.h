// BlueprintGeneratedClass BP_WPN_Grenade_Weapon.BP_WPN_Grenade_Weapon_C
// Size: 0xd78 (Inherited: 0xd70)
struct ABP_WPN_Grenade_Weapon_C : AS_WeaponGrenade {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd70(0x08)

	void OnAttackEvent_BP(enum class ES_TriggerType triggerType, enum class ES_AttackEvent attackEvent); // Function BP_WPN_Grenade_Weapon.BP_WPN_Grenade_Weapon_C.OnAttackEvent_BP // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_WPN_Grenade_Weapon(int32_t EntryPoint); // Function BP_WPN_Grenade_Weapon.BP_WPN_Grenade_Weapon_C.ExecuteUbergraph_BP_WPN_Grenade_Weapon // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

