// BlueprintGeneratedClass BTT_SpitterHail.BTT_SpitterHail_C
// Size: 0xe0 (Inherited: 0xa8)
struct UBTT_SpitterHail_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb0(0x08)
	struct AS_AIController* ScavengerAIController; // 0xb8(0x08)
	struct FName IsPlayingAnimMontage; // 0xc0(0x08)
	struct AS_CharacterBase* CurrentTarget; // 0xc8(0x08)
	float MinDotToTarget; // 0xd0(0x04)
	float MinRangeToTarget; // 0xd4(0x04)
	float MaxRangeToTarget; // 0xd8(0x04)
	float Chance; // 0xdc(0x04)

	void Interrupted_4E5FA5A94306D00D1E06FBB8892360E9(); // Function BTT_SpitterHail.BTT_SpitterHail_C.Interrupted_4E5FA5A94306D00D1E06FBB8892360E9 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Completed_4E5FA5A94306D00D1E06FBB8892360E9(); // Function BTT_SpitterHail.BTT_SpitterHail_C.Completed_4E5FA5A94306D00D1E06FBB8892360E9 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_SpitterHail.BTT_SpitterHail_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_SpitterHail(int32_t EntryPoint); // Function BTT_SpitterHail.BTT_SpitterHail_C.ExecuteUbergraph_BTT_SpitterHail // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

