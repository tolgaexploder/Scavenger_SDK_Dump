// BlueprintGeneratedClass BTT_TurnToFaceLocation.BTT_TurnToFaceLocation_C
// Size: 0xe0 (Inherited: 0xa8)
struct UBTT_TurnToFaceLocation_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xb0(0x08)
	struct AS_AIController* CachedAIController; // 0xb8(0x08)
	float MoveAcceptanceRadius; // 0xc0(0x04)
	float MoveStartTime; // 0xc4(0x04)
	bool PlayIdleMontage; // 0xc8(0x01)
	char UnknownData_C9[0x7]; // 0xc9(0x07)
	struct US_AIAudioEventType* Patrol Idle Audio; // 0xd0(0x08)
	struct US_AIAudioEventType* Patrol Move Audio; // 0xd8(0x08)

	void OnMoveFinished_2CA184C04253B7CF2BCFF0A1AAFB27B8(struct AAIController* AIController, enum class EPathFollowingResult PathFollowingResult, enum class ENavPathEvent NavPathEvent, enum class EPathFollowingRequestResult PathFollowingRequestResult); // Function BTT_TurnToFaceLocation.BTT_TurnToFaceLocation_C.OnMoveFinished_2CA184C04253B7CF2BCFF0A1AAFB27B8 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_TurnToFaceLocation.BTT_TurnToFaceLocation_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_TurnToFaceLocation(int32_t EntryPoint); // Function BTT_TurnToFaceLocation.BTT_TurnToFaceLocation_C.ExecuteUbergraph_BTT_TurnToFaceLocation // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

