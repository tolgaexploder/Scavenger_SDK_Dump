// BlueprintGeneratedClass BTT_CombatHoldPosition.BTT_CombatHoldPosition_C
// Size: 0x118 (Inherited: 0xa8)
struct UBTT_CombatHoldPosition_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AActor* CurrentTarget; // 0xb0(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xb8(0x08)
	struct AS_AIController* CachedAIController; // 0xc0(0x08)
	float FireDuration; // 0xc8(0x04)
	float MinHoldTime; // 0xcc(0x04)
	float MaxHoldTime; // 0xd0(0x04)
	float stopFireAge; // 0xd4(0x04)
	int32_t FireCount; // 0xd8(0x04)
	struct FName HoldPosition; // 0xdc(0x08)
	bool UseADS; // 0xe4(0x01)
	bool AlwaysHold?; // 0xe5(0x01)
	char UnknownData_E6[0x2]; // 0xe6(0x02)
	struct US_AIAudioEventType* Combat Hold Audio; // 0xe8(0x08)
	bool HasStringWeapon; // 0xf0(0x01)
	char UnknownData_F1[0x3]; // 0xf1(0x03)
	struct FName Shotgunner; // 0xf4(0x08)
	struct FName FoundIdealPosition; // 0xfc(0x08)
	bool PreserveAndHold; // 0x104(0x01)
	char UnknownData_105[0x3]; // 0x105(0x03)
	struct FName StringWeapon; // 0x108(0x08)
	struct FName SuccessfulSearch; // 0x110(0x08)

	void ShouldHoldPosition(bool ShouldHold?); // Function BTT_CombatHoldPosition.BTT_CombatHoldPosition_C.ShouldHoldPosition // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CountReached_AAA01304421BCE1B2DDA71B8FB814E40(enum class ES_ScavengerResult Result); // Function BTT_CombatHoldPosition.BTT_CombatHoldPosition_C.CountReached_AAA01304421BCE1B2DDA71B8FB814E40 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_CombatHoldPosition.BTT_CombatHoldPosition_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatHoldPosition(int32_t EntryPoint); // Function BTT_CombatHoldPosition.BTT_CombatHoldPosition_C.ExecuteUbergraph_BTT_CombatHoldPosition // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

