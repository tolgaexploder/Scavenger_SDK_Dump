// BlueprintGeneratedClass BP_AnimNotify_HandIK_Disable.BP_AnimNotify_HandIK_Disable_C
// Size: 0x30 (Inherited: 0x30)
struct UBP_AnimNotify_HandIK_Disable_C : US_AnimNotifyStateBase {

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function BP_AnimNotify_HandIK_Disable.BP_AnimNotify_HandIK_Disable_C.Received_NotifyEnd // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xffff8009123b0000
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function BP_AnimNotify_HandIK_Disable.BP_AnimNotify_HandIK_Disable_C.Received_NotifyBegin // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xffff8009123b0000
};

