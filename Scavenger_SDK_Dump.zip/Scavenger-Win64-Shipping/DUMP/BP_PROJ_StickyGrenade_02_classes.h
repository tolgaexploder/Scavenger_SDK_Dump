// BlueprintGeneratedClass BP_PROJ_StickyGrenade_02.BP_PROJ_StickyGrenade_02_C
// Size: 0x55c (Inherited: 0x549)
struct ABP_PROJ_StickyGrenade_02_C : ABP_PROJ_Grenade_Base_C {
	char UnknownData_549[0x7]; // 0x549(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x550(0x08)
	float Homing Angle; // 0x558(0x04)

	void ReceiveBeginPlay(); // Function BP_PROJ_StickyGrenade_02.BP_PROJ_StickyGrenade_02_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveDestroyed(); // Function BP_PROJ_StickyGrenade_02.BP_PROJ_StickyGrenade_02_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void BP_OnExplode(struct UPhysicalMaterial* hitMaterial); // Function BP_PROJ_StickyGrenade_02.BP_PROJ_StickyGrenade_02_C.BP_OnExplode // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnImpact(struct FHitResult ImpactResult); // Function BP_PROJ_StickyGrenade_02.BP_PROJ_StickyGrenade_02_C.OnImpact // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_PROJ_StickyGrenade_02(int32_t EntryPoint); // Function BP_PROJ_StickyGrenade_02.BP_PROJ_StickyGrenade_02_C.ExecuteUbergraph_BP_PROJ_StickyGrenade_02 // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

