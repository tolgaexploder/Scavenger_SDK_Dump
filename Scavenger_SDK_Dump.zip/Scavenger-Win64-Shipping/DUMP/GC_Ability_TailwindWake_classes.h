// BlueprintGeneratedClass GC_Ability_TailwindWake.GC_Ability_TailwindWake_C
// Size: 0x4fc (Inherited: 0x460)
struct AGC_Ability_TailwindWake_C : AGC_StatusEffect_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)
	struct UParticleSystemComponent* Center PS; // 0x468(0x08)
	struct UParticleSystemComponent* Left PS 02; // 0x470(0x08)
	struct UParticleSystemComponent* Left PS 01; // 0x478(0x08)
	struct UParticleSystemComponent* Right PS 02; // 0x480(0x08)
	struct UParticleSystemComponent* Right PS 01; // 0x488(0x08)
	struct UArrowComponent* Arrow; // 0x490(0x08)
	float Timeline_0_NewTrack_0_0E5D875A4900774C5F0E4DB2F8F5860F; // 0x498(0x04)
	enum class ETimelineDirection Timeline_0__Direction_0E5D875A4900774C5F0E4DB2F8F5860F; // 0x49c(0x01)
	char UnknownData_49D[0x3]; // 0x49d(0x03)
	struct UTimelineComponent* Timeline_1; // 0x4a0(0x08)
	struct FVector Move Placement To Front; // 0x4a8(0x0c)
	int32_t Number Of Loops; // 0x4b4(0x04)
	bool Is Moving?; // 0x4b8(0x01)
	char UnknownData_4B9[0x7]; // 0x4b9(0x07)
	struct ABP_Tailwind_Wake_Row_C* Last Grid Line; // 0x4c0(0x08)
	struct FVector StoredDirectionalVector; // 0x4c8(0x0c)
	float Grid Size; // 0x4d4(0x04)
	float Particle Height Offset Amount; // 0x4d8(0x04)
	float Move PS Over Time; // 0x4dc(0x04)
	enum class EDrawDebugTrace Trace Draw Debug Type; // 0x4e0(0x01)
	char UnknownData_4E1[0x3]; // 0x4e1(0x03)
	float Trace Draw Time; // 0x4e4(0x04)
	struct FVector Half Trace distance; // 0x4e8(0x0c)
	float Wake to Player Speed; // 0x4f4(0x04)
	float Snow Particle Height Offset Amount; // 0x4f8(0x04)

	void Timeline_0__FinishedFunc(); // Function GC_Ability_TailwindWake.GC_Ability_TailwindWake_C.Timeline_0__FinishedFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void Timeline_0__UpdateFunc(); // Function GC_Ability_TailwindWake.GC_Ability_TailwindWake_C.Timeline_0__UpdateFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function GC_Ability_TailwindWake.GC_Ability_TailwindWake_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GC_Ability_TailwindWake.GC_Ability_TailwindWake_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void Move FX(); // Function GC_Ability_TailwindWake.GC_Ability_TailwindWake_C.Move FX // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Update(); // Function GC_Ability_TailwindWake.GC_Ability_TailwindWake_C.Update // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTick(float DeltaSeconds); // Function GC_Ability_TailwindWake.GC_Ability_TailwindWake_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void Spawn Grid Line(); // Function GC_Ability_TailwindWake.GC_Ability_TailwindWake_C.Spawn Grid Line // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_GC_Ability_TailwindWake(int32_t EntryPoint); // Function GC_Ability_TailwindWake.GC_Ability_TailwindWake_C.ExecuteUbergraph_GC_Ability_TailwindWake // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

