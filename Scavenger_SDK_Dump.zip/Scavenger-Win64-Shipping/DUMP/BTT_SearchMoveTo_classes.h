// BlueprintGeneratedClass BTT_SearchMoveTo.BTT_SearchMoveTo_C
// Size: 0x128 (Inherited: 0xa8)
struct UBTT_SearchMoveTo_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AIController* ScavengerAIController; // 0xb0(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb8(0x08)
	float AcceptanceRadius; // 0xc0(0x04)
	float SearchMoveSpeedScalar; // 0xc4(0x04)
	float MoveStartTime; // 0xc8(0x04)
	float LongRangeMoveDistance; // 0xcc(0x04)
	float DistanceToActiveAIPoint; // 0xd0(0x04)
	bool FocusOnLastKnown; // 0xd4(0x01)
	char UnknownData_D5[0x3]; // 0xd5(0x03)
	struct US_AIAudioEventType* OnStartMoveAudio; // 0xd8(0x08)
	bool SearchIdleAtComplete; // 0xe0(0x01)
	char UnknownData_E1[0x3]; // 0xe1(0x03)
	struct FVector CurrentTargetLastKnownLocation; // 0xe4(0x0c)
	bool currenttargetlastknownset; // 0xf0(0x01)
	char UnknownData_F1[0x7]; // 0xf1(0x07)
	struct US_CharacterMovementComponent* CachedMovementComponent; // 0xf8(0x08)
	struct FName IsPlayingAnimMontage; // 0x100(0x08)
	bool MoveToLastKnown; // 0x108(0x01)
	char UnknownData_109[0x3]; // 0x109(0x03)
	struct FVector GoalLocation; // 0x10c(0x0c)
	bool TauntOnComplete; // 0x118(0x01)
	bool HoldADS; // 0x119(0x01)
	char UnknownData_11A[0x6]; // 0x11a(0x06)
	struct US_AIAudioEventType* TauntAudio; // 0x120(0x08)

	void FocusOnSearchPoint(struct FVector InVec); // Function BTT_SearchMoveTo.BTT_SearchMoveTo_C.FocusOnSearchPoint // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnMoveFinished_91131D8F479B2CBF0C0B0BB2591BD5FF(struct AAIController* AIController, enum class EPathFollowingResult PathFollowingResult, enum class ENavPathEvent NavPathEvent, enum class EPathFollowingRequestResult PathFollowingRequestResult); // Function BTT_SearchMoveTo.BTT_SearchMoveTo_C.OnMoveFinished_91131D8F479B2CBF0C0B0BB2591BD5FF // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Interrupted_0A1B9B55494596721BB64A9EBFFAE40D(); // Function BTT_SearchMoveTo.BTT_SearchMoveTo_C.Interrupted_0A1B9B55494596721BB64A9EBFFAE40D // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Completed_0A1B9B55494596721BB64A9EBFFAE40D(); // Function BTT_SearchMoveTo.BTT_SearchMoveTo_C.Completed_0A1B9B55494596721BB64A9EBFFAE40D // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Interrupted_4A54193C416DE0A398E85597288ACD46(); // Function BTT_SearchMoveTo.BTT_SearchMoveTo_C.Interrupted_4A54193C416DE0A398E85597288ACD46 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Completed_4A54193C416DE0A398E85597288ACD46(); // Function BTT_SearchMoveTo.BTT_SearchMoveTo_C.Completed_4A54193C416DE0A398E85597288ACD46 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_SearchMoveTo.BTT_SearchMoveTo_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnAlreadyAtTargetLocation(); // Function BTT_SearchMoveTo.BTT_SearchMoveTo_C.OnAlreadyAtTargetLocation // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Abort Search Montage(struct AActor* DamagedActor, float UnmodifiedDamageAmount, float ArmorDamageAmount, float HealthDamageAmount, struct FDamageEvent DamageEvent, struct AActor* CauseActor, enum class None DamageModifiersApplied, struct AController* InstigatorController, struct FS_PreTakeDamageInfo DamageInfo); // Function BTT_SearchMoveTo.BTT_SearchMoveTo_C.Abort Search Montage // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void TauntDamageInterrupt(struct AActor* DamagedActor, float UnmodifiedDamageAmount, float ArmorDamageAmount, float HealthDamageAmount, struct FDamageEvent DamageEvent, struct AActor* CauseActor, enum class None DamageModifiersApplied, struct AController* InstigatorController, struct FS_PreTakeDamageInfo DamageInfo); // Function BTT_SearchMoveTo.BTT_SearchMoveTo_C.TauntDamageInterrupt // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_SearchMoveTo(int32_t EntryPoint); // Function BTT_SearchMoveTo.BTT_SearchMoveTo_C.ExecuteUbergraph_BTT_SearchMoveTo // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

