// BlueprintGeneratedClass BTT_ReturnFALSE.BTT_ReturnFALSE_C
// Size: 0xb0 (Inherited: 0xa8)
struct UBTT_ReturnFALSE_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)

	void ReceiveExecute(struct AActor* OwnerActor); // Function BTT_ReturnFALSE.BTT_ReturnFALSE_C.ReceiveExecute // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_ReturnFALSE(int32_t EntryPoint); // Function BTT_ReturnFALSE.BTT_ReturnFALSE_C.ExecuteUbergraph_BTT_ReturnFALSE // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

