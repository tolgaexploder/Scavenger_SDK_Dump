// BlueprintGeneratedClass BP_Pickup_salv_scourgeseed.BP_Pickup_salv_scourgeseed_C
// Size: 0x498 (Inherited: 0x488)
struct ABP_Pickup_salv_scourgeseed_C : AS_ItemPickup {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct UParticleSystemComponent* PS_Item_Salvage_Loop; // 0x490(0x08)

	void ReceiveBeginPlay(); // Function BP_Pickup_salv_scourgeseed.BP_Pickup_salv_scourgeseed_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Pickup_salv_scourgeseed(int32_t EntryPoint); // Function BP_Pickup_salv_scourgeseed.BP_Pickup_salv_scourgeseed_C.ExecuteUbergraph_BP_Pickup_salv_scourgeseed // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

