// BlueprintGeneratedClass BTD_StopMontageOnAbort.BTD_StopMontageOnAbort_C
// Size: 0xb8 (Inherited: 0xa0)
struct UBTD_StopMontageOnAbort_C : UBTDecorator_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa0(0x08)
	struct FName IsInCover; // 0xa8(0x08)
	struct FName PursueTarget; // 0xb0(0x08)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_StopMontageOnAbort.BTD_StopMontageOnAbort_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecutionStart(struct AActor* OwnerActor); // Function BTD_StopMontageOnAbort.BTD_StopMontageOnAbort_C.ReceiveExecutionStart // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecutionFinish(struct AActor* OwnerActor, enum class EBTNodeResult NodeResult); // Function BTD_StopMontageOnAbort.BTD_StopMontageOnAbort_C.ReceiveExecutionFinish // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTD_StopMontageOnAbort(int32_t EntryPoint); // Function BTD_StopMontageOnAbort.BTD_StopMontageOnAbort_C.ExecuteUbergraph_BTD_StopMontageOnAbort // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

