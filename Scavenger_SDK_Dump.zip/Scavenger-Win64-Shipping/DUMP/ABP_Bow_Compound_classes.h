// AnimBlueprintGeneratedClass ABP_Bow_Compound.ABP_Bow_Compound_C
// Size: 0x2138 (Inherited: 0x212a)
struct UABP_Bow_Compound_C : UABP_Bow_C {
	char UnknownData_212A[0x6]; // 0x212a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2130(0x08)

	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Bow_Compound.ABP_Bow_Compound_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_ABP_Bow_Compound(int32_t EntryPoint); // Function ABP_Bow_Compound.ABP_Bow_Compound_C.ExecuteUbergraph_ABP_Bow_Compound // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

