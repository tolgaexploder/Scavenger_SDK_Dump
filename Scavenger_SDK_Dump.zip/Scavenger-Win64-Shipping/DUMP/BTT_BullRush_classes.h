// BlueprintGeneratedClass BTT_BullRush.BTT_BullRush_C
// Size: 0xfc (Inherited: 0xa8)
struct UBTT_BullRush_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct FName Charging; // 0xb0(0x08)
	struct FName PursueTarget; // 0xb8(0x08)
	struct FName LastOffhandMeleeAttack; // 0xc0(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xc8(0x08)
	struct AS_AIController* CachedAIController; // 0xd0(0x08)
	float PathfindingAcceptanceRadius; // 0xd8(0x04)
	float MaxAcceleration; // 0xdc(0x04)
	float MaxSpeed; // 0xe0(0x04)
	float MoveStartTime; // 0xe4(0x04)
	float DefaultAcceleration; // 0xe8(0x04)
	float DefaultSpeed; // 0xec(0x04)
	bool StopFire; // 0xf0(0x01)
	bool PlayAntic; // 0xf1(0x01)
	char UnknownData_F2[0x2]; // 0xf2(0x02)
	struct FName IsPlayingAnimMontage; // 0xf4(0x08)

	void OnMoveFinished_C0D9EAFE4882B7420F10D6B2D8063E5A(struct AAIController* AIController, enum class EPathFollowingResult PathFollowingResult, enum class ENavPathEvent NavPathEvent, enum class EPathFollowingRequestResult PathFollowingRequestResult); // Function BTT_BullRush.BTT_BullRush_C.OnMoveFinished_C0D9EAFE4882B7420F10D6B2D8063E5A // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Interrupted_1AB6B3E54BFCBFA56451B790842C1ED4(); // Function BTT_BullRush.BTT_BullRush_C.Interrupted_1AB6B3E54BFCBFA56451B790842C1ED4 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Completed_1AB6B3E54BFCBFA56451B790842C1ED4(); // Function BTT_BullRush.BTT_BullRush_C.Completed_1AB6B3E54BFCBFA56451B790842C1ED4 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_BullRush.BTT_BullRush_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnAlreadyAtTargetLocation(); // Function BTT_BullRush.BTT_BullRush_C.OnAlreadyAtTargetLocation // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_BullRush(int32_t EntryPoint); // Function BTT_BullRush.BTT_BullRush_C.ExecuteUbergraph_BTT_BullRush // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

