// BlueprintGeneratedClass BTT_CombatBloatbileVomitStream.BTT_CombatBloatbileVomitStream_C
// Size: 0xe8 (Inherited: 0xa8)
struct UBTT_CombatBloatbileVomitStream_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb0(0x08)
	struct AS_AIController* ScavengerController; // 0xb8(0x08)
	struct AActor* CurrentTarget; // 0xc0(0x08)
	float AttackAlpha; // 0xc8(0x04)
	float AllowFireAngle; // 0xcc(0x04)
	struct FName IsAttackingWithMelee; // 0xd0(0x08)
	struct FName LastOffhandMeleeAttack; // 0xd8(0x08)
	struct FName HoldPosition; // 0xe0(0x08)

	void CountReached_1AFE3C39410DB7C7EDDC158322E0F7D7(enum class ES_ScavengerResult Result); // Function BTT_CombatBloatbileVomitStream.BTT_CombatBloatbileVomitStream_C.CountReached_1AFE3C39410DB7C7EDDC158322E0F7D7 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTT_CombatBloatbileVomitStream.BTT_CombatBloatbileVomitStream_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatBloatbileVomitStream(int32_t EntryPoint); // Function BTT_CombatBloatbileVomitStream.BTT_CombatBloatbileVomitStream_C.ExecuteUbergraph_BTT_CombatBloatbileVomitStream // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

