// BlueprintGeneratedClass BPI_AI_Outlander.BPI_AI_Outlander_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_AI_Outlander_C : UInterface {

	void IsImmobile(bool IsImmobile); // Function BPI_AI_Outlander.BPI_AI_Outlander_C.IsImmobile // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void HasStringWeapoon(bool HasStringWeapon); // Function BPI_AI_Outlander.BPI_AI_Outlander_C.HasStringWeapoon // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void HasShotgun(bool Shotgunner); // Function BPI_AI_Outlander.BPI_AI_Outlander_C.HasShotgun // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ShouldAlwaysHail(bool ShouldAlwaysHail); // Function BPI_AI_Outlander.BPI_AI_Outlander_C.ShouldAlwaysHail // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void DoesHardPingGrenadeDrop(bool Result); // Function BPI_AI_Outlander.BPI_AI_Outlander_C.DoesHardPingGrenadeDrop // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CanUseTactics(bool Result); // Function BPI_AI_Outlander.BPI_AI_Outlander_C.CanUseTactics // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsBuzzsaw(bool Result); // Function BPI_AI_Outlander.BPI_AI_Outlander_C.IsBuzzsaw // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

