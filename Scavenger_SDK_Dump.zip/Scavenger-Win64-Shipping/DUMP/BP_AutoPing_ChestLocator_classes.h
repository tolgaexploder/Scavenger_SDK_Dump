// BlueprintGeneratedClass BP_AutoPing_ChestLocator.BP_AutoPing_ChestLocator_C
// Size: 0x2a0 (Inherited: 0x298)
struct UBP_AutoPing_ChestLocator_C : US_EncounterAutoPing {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x298(0x08)

	bool EvaluatePing_BP(struct AS_PlayerController* PlayerController); // Function BP_AutoPing_ChestLocator.BP_AutoPing_ChestLocator_C.EvaluatePing_BP // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_AutoPing_ChestLocator.BP_AutoPing_ChestLocator_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_AutoPing_ChestLocator(int32_t EntryPoint); // Function BP_AutoPing_ChestLocator.BP_AutoPing_ChestLocator_C.ExecuteUbergraph_BP_AutoPing_ChestLocator // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

