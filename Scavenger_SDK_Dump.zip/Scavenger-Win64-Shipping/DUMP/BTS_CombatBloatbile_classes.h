// BlueprintGeneratedClass BTS_CombatBloatbile.BTS_CombatBloatbile_C
// Size: 0xf9 (Inherited: 0x98)
struct UBTS_CombatBloatbile_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xa0(0x08)
	struct AS_AIController* CachedAIController; // 0xa8(0x08)
	struct FName HealthIsLow; // 0xb0(0x08)
	struct FName ThrowGrenade; // 0xb8(0x08)
	struct FName BloatbileExplode; // 0xc0(0x08)
	struct FName BloatbileCharge; // 0xc8(0x08)
	struct FName BloatbileExplodeAttack; // 0xd0(0x08)
	float DeltaSeconds; // 0xd8(0x04)
	float CurrentTime; // 0xdc(0x04)
	float LowHealthThreshold; // 0xe0(0x04)
	float TargetCloseRange; // 0xe4(0x04)
	float TimeInCloseRange; // 0xe8(0x04)
	float ChargeHealthTrigger; // 0xec(0x04)
	float ExplodeTimeTrigger; // 0xf0(0x04)
	float ExplodeHealthTrigger; // 0xf4(0x04)
	bool LowHealth; // 0xf8(0x01)

	void CheckTargetCloseRange(bool TargetInCloseRange); // Function BTS_CombatBloatbile.BTS_CombatBloatbile_C.CheckTargetCloseRange // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateHealthIsLow(); // Function BTS_CombatBloatbile.BTS_CombatBloatbile_C.UpdateHealthIsLow // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_CombatBloatbile.BTS_CombatBloatbile_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void CustomEvent(struct AActor* DamagedActor, float DamageAmount, struct FDamageEvent DamageEvent, struct AActor* CauseActor, bool Critical); // Function BTS_CombatBloatbile.BTS_CombatBloatbile_C.CustomEvent // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ClearExplodeAttack(); // Function BTS_CombatBloatbile.BTS_CombatBloatbile_C.ClearExplodeAttack // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTS_CombatBloatbile(int32_t EntryPoint); // Function BTS_CombatBloatbile.BTS_CombatBloatbile_C.ExecuteUbergraph_BTS_CombatBloatbile // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

