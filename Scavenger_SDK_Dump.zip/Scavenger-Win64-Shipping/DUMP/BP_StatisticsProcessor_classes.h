// BlueprintGeneratedClass BP_StatisticsProcessor.BP_StatisticsProcessor_C
// Size: 0xd8 (Inherited: 0x90)
struct UBP_StatisticsProcessor_C : US_ChallengeStatisticsProcessor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x90(0x08)
	struct FS_ItemState Item State; // 0x98(0x40)

	void OnItemCraftedByPlayer(int32_t RecipeIndex, struct FS_RecipeMetadata RecipeMetadata); // Function BP_StatisticsProcessor.BP_StatisticsProcessor_C.OnItemCraftedByPlayer // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetupCraftingCallbacks(struct AS_PlayerController* PlayerController); // Function BP_StatisticsProcessor.BP_StatisticsProcessor_C.SetupCraftingCallbacks // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnItemUsedByPlayer(struct FS_ItemState ItemState); // Function BP_StatisticsProcessor.BP_StatisticsProcessor_C.OnItemUsedByPlayer // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetupCallbacks_BP(struct AS_PlayerController* PlayerController); // Function BP_StatisticsProcessor.BP_StatisticsProcessor_C.SetupCallbacks_BP // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ProcessEnemyKilled_BP(struct AActor* actorKilled); // Function BP_StatisticsProcessor.BP_StatisticsProcessor_C.ProcessEnemyKilled_BP // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_StatisticsProcessor(int32_t EntryPoint); // Function BP_StatisticsProcessor.BP_StatisticsProcessor_C.ExecuteUbergraph_BP_StatisticsProcessor // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

