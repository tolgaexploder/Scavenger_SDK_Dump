// BlueprintGeneratedClass BP_Rocket.BP_Rocket_C
// Size: 0x40c (Inherited: 0x338)
struct ABP_Rocket_C : AS_PlayerHome {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x338(0x08)
	struct UPointLightComponent* LIGHT_Booster; // 0x340(0x08)
	struct UBP_OverheadMapIconComponent_Rocket_C* BP_OverheadMapIconComponent_Rocket; // 0x348(0x08)
	struct UAudioComponent* A_Planetfall_RocketEngine; // 0x350(0x08)
	struct USceneComponent* Scene; // 0x358(0x08)
	struct UCapsuleComponent* PHYSICS_DeathVolume; // 0x360(0x08)
	struct UAudioComponent* A_Planetfall_Start; // 0x368(0x08)
	struct UParticleSystemComponent* P_LandingSmoke; // 0x370(0x08)
	struct UStaticMeshComponent* MARKER_Raycast; // 0x378(0x08)
	struct UParticleSystemComponent* PS_RocketBoosterEngine; // 0x380(0x08)
	struct UStaticMeshComponent* Cone1; // 0x388(0x08)
	struct UStaticMeshComponent* StaticMesh_1; // 0x390(0x08)
	struct UStaticMeshComponent* Cone; // 0x398(0x08)
	struct UStaticMeshComponent* Cylinder; // 0x3a0(0x08)
	float TL_Takeoff_TakeoffFactor_296F73564DCAAEA1D690BDBCC209BFCF; // 0x3a8(0x04)
	enum class ETimelineDirection TL_Takeoff__Direction_296F73564DCAAEA1D690BDBCC209BFCF; // 0x3ac(0x01)
	char UnknownData_3AD[0x3]; // 0x3ad(0x03)
	struct UTimelineComponent* TL_Takeoff; // 0x3b0(0x08)
	float TL_Landing_LandingFactor_6E0EA3904030377C33D953BA33FEFE46; // 0x3b8(0x04)
	enum class ETimelineDirection TL_Landing__Direction_6E0EA3904030377C33D953BA33FEFE46; // 0x3bc(0x01)
	char UnknownData_3BD[0x3]; // 0x3bd(0x03)
	struct UTimelineComponent* TL_Landing; // 0x3c0(0x08)
	struct FVector StartLocation; // 0x3c8(0x0c)
	struct FVector LandingLocation; // 0x3d4(0x0c)
	float LandDuration; // 0x3e0(0x04)
	int32_t FinalWaitTime; // 0x3e4(0x04)
	int32_t BaseWaitTime; // 0x3e8(0x04)
	int32_t BonusWaitTimeFactor; // 0x3ec(0x04)
	int32_t MinBonusWaitTimeMultiplier; // 0x3f0(0x04)
	int32_t MaxBonusWaitTimeMultiplier; // 0x3f4(0x04)
	float TakeoffDuration; // 0x3f8(0x04)
	enum class ERocketState RocketState; // 0x3fc(0x01)
	char UnknownData_3FD[0x3]; // 0x3fd(0x03)
	float TakeoffStartTime; // 0x400(0x04)
	struct FName RocketLandedEventId; // 0x404(0x08)

	void OnRocketLanded(); // Function BP_Rocket.BP_Rocket_C.OnRocketLanded // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetTimeUntilTakeoff(float Time); // Function BP_Rocket.BP_Rocket_C.GetTimeUntilTakeoff // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xffff8009123b0000
	void OnRep_TakeoffStartTime(); // Function BP_Rocket.BP_Rocket_C.OnRep_TakeoffStartTime // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnRep_RocketState(); // Function BP_Rocket.BP_Rocket_C.OnRep_RocketState // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetDistanceToLandingLocation(float Distance); // Function BP_Rocket.BP_Rocket_C.GetDistanceToLandingLocation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xffff8009123b0000
	void UpdateLandingSmokeLocation(); // Function BP_Rocket.BP_Rocket_C.UpdateLandingSmokeLocation // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CalculateLandingLocation(float LandingHeight, struct FVector LandingLocation); // Function BP_Rocket.BP_Rocket_C.CalculateLandingLocation // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xffff8009123b0000
	void UserConstructionScript(); // Function BP_Rocket.BP_Rocket_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void TL_Landing__FinishedFunc(); // Function BP_Rocket.BP_Rocket_C.TL_Landing__FinishedFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void TL_Landing__UpdateFunc(); // Function BP_Rocket.BP_Rocket_C.TL_Landing__UpdateFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void TL_Takeoff__FinishedFunc(); // Function BP_Rocket.BP_Rocket_C.TL_Takeoff__FinishedFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void TL_Takeoff__UpdateFunc(); // Function BP_Rocket.BP_Rocket_C.TL_Takeoff__UpdateFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_Rocket.BP_Rocket_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTick(float DeltaSeconds); // Function BP_Rocket.BP_Rocket_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void BeginLanding(); // Function BP_Rocket.BP_Rocket_C.BeginLanding // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void BeginWaiting(); // Function BP_Rocket.BP_Rocket_C.BeginWaiting // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void StartCountdown(int32_t CountdownTime); // Function BP_Rocket.BP_Rocket_C.StartCountdown // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void MultiBeginTakeoff(); // Function BP_Rocket.BP_Rocket_C.MultiBeginTakeoff // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ActivateEngines(bool NewActive); // Function BP_Rocket.BP_Rocket_C.ActivateEngines // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void MultiActivateEngines(bool NewActive); // Function BP_Rocket.BP_Rocket_C.MultiActivateEngines // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ServerNotifyClientsOfLanding(); // Function BP_Rocket.BP_Rocket_C.ServerNotifyClientsOfLanding // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void BndEvt__PHYSICS_DeathVolume_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function BP_Rocket.BP_Rocket_C.BndEvt__PHYSICS_DeathVolume_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Rocket(int32_t EntryPoint); // Function BP_Rocket.BP_Rocket_C.ExecuteUbergraph_BP_Rocket // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

