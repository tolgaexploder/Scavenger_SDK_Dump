// BlueprintGeneratedClass BTT_TurnToFaceTarget.BTT_TurnToFaceTarget_C
// Size: 0xe8 (Inherited: 0xa8)
struct UBTT_TurnToFaceTarget_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xb0(0x08)
	struct AS_AIController* CachedAIController; // 0xb8(0x08)
	float MoveAcceptanceRadius; // 0xc0(0x04)
	float MoveStartTime; // 0xc4(0x04)
	bool PlayIdleMontage; // 0xc8(0x01)
	char UnknownData_C9[0x7]; // 0xc9(0x07)
	struct US_AIAudioEventType* Patrol Idle Audio; // 0xd0(0x08)
	struct US_AIAudioEventType* Patrol Move Audio; // 0xd8(0x08)
	struct FName IsTurningInPlace; // 0xe0(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_TurnToFaceTarget.BTT_TurnToFaceTarget_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_TurnToFaceTarget(int32_t EntryPoint); // Function BTT_TurnToFaceTarget.BTT_TurnToFaceTarget_C.ExecuteUbergraph_BTT_TurnToFaceTarget // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

