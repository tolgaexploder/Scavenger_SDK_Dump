// BlueprintGeneratedClass BPI_CompanionInterface.BPI_CompanionInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_CompanionInterface_C : UInterface {

	void GetAllCompanions(struct TArray<struct AActor*> Companions); // Function BPI_CompanionInterface.BPI_CompanionInterface_C.GetAllCompanions // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xffff8009123b0000
	void RemoveCompanion(struct AActor* Companion); // Function BPI_CompanionInterface.BPI_CompanionInterface_C.RemoveCompanion // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void AddCompanion(struct AActor* Companion); // Function BPI_CompanionInterface.BPI_CompanionInterface_C.AddCompanion // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

