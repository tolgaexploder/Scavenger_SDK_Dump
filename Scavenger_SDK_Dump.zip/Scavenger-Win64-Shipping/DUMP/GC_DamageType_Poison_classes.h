// BlueprintGeneratedClass GC_DamageType_Poison.GC_DamageType_Poison_C
// Size: 0x468 (Inherited: 0x460)
struct AGC_DamageType_Poison_C : AGC_StatusEffect_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)

	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GC_DamageType_Poison.GC_DamageType_Poison_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_GC_DamageType_Poison(int32_t EntryPoint); // Function GC_DamageType_Poison.GC_DamageType_Poison_C.ExecuteUbergraph_GC_DamageType_Poison // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

