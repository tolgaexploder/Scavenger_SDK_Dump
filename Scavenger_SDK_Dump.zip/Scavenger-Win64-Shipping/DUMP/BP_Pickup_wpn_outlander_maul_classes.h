// BlueprintGeneratedClass BP_Pickup_wpn_outlander_maul.BP_Pickup_wpn_outlander_maul_C
// Size: 0x490 (Inherited: 0x488)
struct ABP_Pickup_wpn_outlander_maul_C : AS_ItemPickup {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)

	void ReceiveBeginPlay(); // Function BP_Pickup_wpn_outlander_maul.BP_Pickup_wpn_outlander_maul_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Pickup_wpn_outlander_maul(int32_t EntryPoint); // Function BP_Pickup_wpn_outlander_maul.BP_Pickup_wpn_outlander_maul_C.ExecuteUbergraph_BP_Pickup_wpn_outlander_maul // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

