// BlueprintGeneratedClass BP_PROJ_BouncyGrenade.BP_PROJ_BouncyGrenade_C
// Size: 0x564 (Inherited: 0x549)
struct ABP_PROJ_BouncyGrenade_C : ABP_PROJ_Grenade_Base_C {
	char UnknownData_549[0x7]; // 0x549(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x550(0x08)
	enum class ECollisionChannel NewVar_0_1; // 0x558(0x01)
	enum class ECollisionEnabled CollisionEnabledSetting_1; // 0x559(0x01)
	char UnknownData_55A[0x2]; // 0x55a(0x02)
	int32_t BounceCount; // 0x55c(0x04)
	int32_t MaxBounce; // 0x560(0x04)

	void OnImpact(struct FHitResult ImpactResult); // Function BP_PROJ_BouncyGrenade.BP_PROJ_BouncyGrenade_C.OnImpact // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_PROJ_BouncyGrenade.BP_PROJ_BouncyGrenade_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void BP_OnExplode(struct UPhysicalMaterial* hitMaterial); // Function BP_PROJ_BouncyGrenade.BP_PROJ_BouncyGrenade_C.BP_OnExplode // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveDestroyed(); // Function BP_PROJ_BouncyGrenade.BP_PROJ_BouncyGrenade_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_PROJ_BouncyGrenade(int32_t EntryPoint); // Function BP_PROJ_BouncyGrenade.BP_PROJ_BouncyGrenade_C.ExecuteUbergraph_BP_PROJ_BouncyGrenade // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

