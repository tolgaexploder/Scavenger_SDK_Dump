// BlueprintGeneratedClass BTT_CombatSelectBestWeapon.BTT_CombatSelectBestWeapon_C
// Size: 0xdc (Inherited: 0xa8)
struct UBTT_CombatSelectBestWeapon_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AActor* CurrentTarget; // 0xb0(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb8(0x08)
	struct AS_AIController* AIController; // 0xc0(0x08)
	struct FName IsMelee; // 0xc8(0x08)
	bool allowUnarmed; // 0xd0(0x01)
	char UnknownData_D1[0x3]; // 0xd1(0x03)
	struct FName StringWeapon; // 0xd4(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_CombatSelectBestWeapon.BTT_CombatSelectBestWeapon_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void WeaponEvent(enum class ES_WeaponSlot weaponSlot, enum class ES_TriggerType triggerType, enum class ES_AttackEvent attackEvent); // Function BTT_CombatSelectBestWeapon.BTT_CombatSelectBestWeapon_C.WeaponEvent // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatSelectBestWeapon(int32_t EntryPoint); // Function BTT_CombatSelectBestWeapon.BTT_CombatSelectBestWeapon_C.ExecuteUbergraph_BTT_CombatSelectBestWeapon // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

