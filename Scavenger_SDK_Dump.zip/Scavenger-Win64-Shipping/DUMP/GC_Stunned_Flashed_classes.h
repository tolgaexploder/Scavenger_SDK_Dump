// BlueprintGeneratedClass GC_Stunned_Flashed.GC_Stunned_Flashed_C
// Size: 0x488 (Inherited: 0x460)
struct AGC_Stunned_Flashed_C : AGC_StatusEffect_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)
	struct USceneCaptureComponent2D* SceneCaptureComponent2D; // 0x468(0x08)
	float FlashBirghtness_Brightness_75FA11BD445651322BF7A4B9B295EBAC; // 0x470(0x04)
	enum class ETimelineDirection FlashBirghtness__Direction_75FA11BD445651322BF7A4B9B295EBAC; // 0x474(0x01)
	char UnknownData_475[0x3]; // 0x475(0x03)
	struct UTimelineComponent* FlashBirghtness; // 0x478(0x08)
	struct UMaterialInstanceDynamic* PP_MID; // 0x480(0x08)

	void FlashBirghtness__FinishedFunc(); // Function GC_Stunned_Flashed.GC_Stunned_Flashed_C.FlashBirghtness__FinishedFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void FlashBirghtness__UpdateFunc(); // Function GC_Stunned_Flashed.GC_Stunned_Flashed_C.FlashBirghtness__UpdateFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GC_Stunned_Flashed.GC_Stunned_Flashed_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function GC_Stunned_Flashed.GC_Stunned_Flashed_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_GC_Stunned_Flashed(int32_t EntryPoint); // Function GC_Stunned_Flashed.GC_Stunned_Flashed_C.ExecuteUbergraph_GC_Stunned_Flashed // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

