// BlueprintGeneratedClass GlobalAIFunctions.GlobalAIFunctions_C
// Size: 0x28 (Inherited: 0x28)
struct UGlobalAIFunctions_C : UBlueprintFunctionLibrary {

	void TargetIsSprinting(struct AS_AICharacter* S AI Character, float MinSpeedPercent, struct UObject* __WorldContext, bool IsSprinting); // Function GlobalAIFunctions.GlobalAIFunctions_C.TargetIsSprinting // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsAlive(struct AS_AICharacter* aiCharacter, struct UObject* __WorldContext, bool IsAlive); // Function GlobalAIFunctions.GlobalAIFunctions_C.IsAlive // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CanUseTactics(struct AS_AICharacter* AI Character, struct UObject* __WorldContext, bool Result); // Function GlobalAIFunctions.GlobalAIFunctions_C.CanUseTactics // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	bool HaveHighGroundOBOne(struct AS_AICharacter* AI Character, float MinHeight, struct UObject* __WorldContext); // Function GlobalAIFunctions.GlobalAIFunctions_C.HaveHighGroundOBOne // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void AmISprinting(struct AS_AICharacter* S AI Character, float MinSpeedPercent, struct UObject* __WorldContext, bool IsSprinting); // Function GlobalAIFunctions.GlobalAIFunctions_C.AmISprinting // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsInAnyCover(struct AS_AICharacter* aiCharacter, struct UObject* __WorldContext, bool Output); // Function GlobalAIFunctions.GlobalAIFunctions_C.IsInAnyCover // (Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

