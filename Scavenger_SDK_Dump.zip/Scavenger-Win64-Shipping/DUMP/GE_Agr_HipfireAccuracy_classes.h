// BlueprintGeneratedClass GE_Agr_HipfireAccuracy.GE_Agr_HipfireAccuracy_C
// Size: 0x7c0 (Inherited: 0x7b8)
struct UGE_Agr_HipfireAccuracy_C : UGameplayEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7b8(0x08)

	void ExecuteUbergraph_GE_Agr_HipfireAccuracy(int32_t EntryPoint); // Function GE_Agr_HipfireAccuracy.GE_Agr_HipfireAccuracy_C.ExecuteUbergraph_GE_Agr_HipfireAccuracy // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

