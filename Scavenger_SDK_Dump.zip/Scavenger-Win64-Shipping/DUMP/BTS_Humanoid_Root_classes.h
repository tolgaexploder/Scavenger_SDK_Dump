// BlueprintGeneratedClass BTS_Humanoid_Root.BTS_Humanoid_Root_C
// Size: 0x28c (Inherited: 0x98)
struct UBTS_Humanoid_Root_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xa0(0x08)
	struct AS_AIOverlordActor* MyOverlord; // 0xa8(0x08)
	struct AS_AIController* Controller; // 0xb0(0x08)
	struct FName CanAttack; // 0xb8(0x08)
	struct FName HealthIsLow; // 0xc0(0x08)
	struct FName HasValidEnemy; // 0xc8(0x08)
	struct FName WantToSearch; // 0xd0(0x08)
	struct FName WantToInvestigate; // 0xd8(0x08)
	struct FName FleeRecovery; // 0xe0(0x08)
	struct FName FleeFinalStand; // 0xe8(0x08)
	struct FName WasHailed; // 0xf0(0x08)
	struct FName ResolveIsBroken; // 0xf8(0x08)
	struct FName IsHailing; // 0x100(0x08)
	struct FName CombatFallBack; // 0x108(0x08)
	struct FName OutOfRange; // 0x110(0x08)
	struct FName IsActiveFighter; // 0x118(0x08)
	struct FName IsMelee; // 0x120(0x08)
	struct FName PursueTarget; // 0x128(0x08)
	struct FName Visible_Target; // 0x130(0x08)
	struct FName Active_Target; // 0x138(0x08)
	struct FName Lost_Target; // 0x140(0x08)
	struct FName CurrentTarget; // 0x148(0x08)
	struct FName TryHailAnim; // 0x150(0x08)
	struct FName FlinchEvent; // 0x158(0x08)
	struct FName OpportunityPointID; // 0x160(0x08)
	struct FName ShouldCrouch; // 0x168(0x08)
	struct FName SelfPreservationBlock; // 0x170(0x08)
	struct FName SelfPreservation; // 0x178(0x08)
	struct FName PullTether; // 0x180(0x08)
	struct FName TargetUnclear; // 0x188(0x08)
	struct FName RecentlyDamaged; // 0x190(0x08)
	struct FName IsPlayingAnimMontage; // 0x198(0x08)
	struct FName DataHarvestActive; // 0x1a0(0x08)
	struct FName Captive; // 0x1a8(0x08)
	struct FName SuccessfulSearch; // 0x1b0(0x08)
	struct FName Shotgunner; // 0x1b8(0x08)
	struct FName EncounterStrength; // 0x1c0(0x08)
	float DeltaSeconds; // 0x1c8(0x04)
	float CurrentTime; // 0x1cc(0x04)
	float ResolveRecoveryTime; // 0x1d0(0x04)
	float PursuitTimer; // 0x1d4(0x04)
	float AbortPursuitTimer; // 0x1d8(0x04)
	float AbortPursuitRange; // 0x1dc(0x04)
	float TargetID_VisibilityThreshold; // 0x1e0(0x04)
	float TargetLowHealthThreshold; // 0x1e4(0x04)
	float DistanceToTarget; // 0x1e8(0x04)
	float InvestigateDuration; // 0x1ec(0x04)
	float IntensityInterval; // 0x1f0(0x04)
	float LastStandOnFleeChance; // 0x1f4(0x04)
	float TargetAge; // 0x1f8(0x04)
	float OverlordAwarenessDelay; // 0x1fc(0x04)
	float OpportunityDelayTimer; // 0x200(0x04)
	float TetherDistance; // 0x204(0x04)
	float TargetAcquisitionDelay; // 0x208(0x04)
	float TargetAcquisitionTimeStamp; // 0x20c(0x04)
	float MaxAllowedToLookForExecutionDist; // 0x210(0x04)
	float ExecutionEnabledRange; // 0x214(0x04)
	bool ValidTarget; // 0x218(0x01)
	bool IWantToInvestigate; // 0x219(0x01)
	bool IWantToSearch; // 0x21a(0x01)
	bool WasCharging; // 0x21b(0x01)
	bool HealthLow; // 0x21c(0x01)
	bool HailedByFriendly; // 0x21d(0x01)
	bool ResolveBroken; // 0x21e(0x01)
	bool FinalStand; // 0x21f(0x01)
	bool FallBackFromPursuit; // 0x220(0x01)
	bool IsActiveKungFu; // 0x221(0x01)
	bool IsOutOfRange; // 0x222(0x01)
	bool TargetHealthLow; // 0x223(0x01)
	bool Target_Visible; // 0x224(0x01)
	bool Target_Lost; // 0x225(0x01)
	bool Target_Unknown_Heard; // 0x226(0x01)
	bool Target_Unknown_Damage; // 0x227(0x01)
	bool Target_Unknown_Partial; // 0x228(0x01)
	bool Target_Known_Damage; // 0x229(0x01)
	bool OLAwareAlarm; // 0x22a(0x01)
	bool Target_Unclear; // 0x22b(0x01)
	bool Target_Active; // 0x22c(0x01)
	char UnknownData_22D[0x3]; // 0x22d(0x03)
	struct FVector ImportancePoint; // 0x230(0x0c)
	enum class ES_CombatTargetAcquisition TargetAcquisitionState; // 0x23c(0x01)
	bool OLPhysicalAlarmOn; // 0x23d(0x01)
	char UnknownData_23E[0x2]; // 0x23e(0x02)
	int32_t AlertState; // 0x240(0x04)
	float ForceNextTargetDelay; // 0x244(0x04)
	float ForceNextTargetTimer; // 0x248(0x04)
	float ChachedSquadStrength; // 0x24c(0x04)
	float LastCachedStrengthTime; // 0x250(0x04)
	struct FName ExecutionTarget; // 0x254(0x08)
	struct FName EligibleExecutionTarget; // 0x25c(0x08)
	struct FName IsExecuting; // 0x264(0x08)
	struct FName TryDodgeDanger; // 0x26c(0x08)
	struct FName DangerLocationPositive; // 0x274(0x08)
	struct FName TargetIsSprinting; // 0x27c(0x08)
	struct FName TargetSpeed; // 0x284(0x08)

	void UpdateMyTargetIsSprinting(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.UpdateMyTargetIsSprinting // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnComingVehicle(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.OnComingVehicle // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void HasExecutionTarget(struct AS_PlayerCharacter* NewParam); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.HasExecutionTarget // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckForExecutionTarget(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CheckForExecutionTarget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckIfShotgunner(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CheckIfShotgunner // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckIgnoredAI(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CheckIgnoredAI // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OverlordStrength(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.OverlordStrength // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CalculateTimerPercentage(struct FName TimerName, float timerDuration, enum class ES_AIAlertState AlertState, bool ValidTimer); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CalculateTimerPercentage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateAlertState(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.UpdateAlertState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CalculateAlertStatePercent(float StartTime, float CurrentTime, float Delay, float StatePercent); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CalculateAlertStatePercent // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsMyTargetDown(bool Result); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.IsMyTargetDown // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateOverlordValues(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.UpdateOverlordValues // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckTetherSpring(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CheckTetherSpring // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateTargetAcquisition(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.UpdateTargetAcquisition // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckSelfPreservation(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CheckSelfPreservation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void TrySetOpportunityPoint(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.TrySetOpportunityPoint // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetImportancePoint(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.SetImportancePoint // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ProcessHail(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.ProcessHail // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateNewTarget(struct AS_CharacterBase* Old Target, struct AS_CharacterBase* New Target); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.UpdateNewTarget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetCustomPointFromLastKnown(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.SetCustomPointFromLastKnown // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateBlackboard(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.UpdateBlackboard // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	bool CheckWantToInvestigate(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CheckWantToInvestigate // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	bool CheckWantToSearch(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CheckWantToSearch // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckForActiveTarget(bool HasActiveTarget); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CheckForActiveTarget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void StoreTargetStates(bool HasValidTarget?); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.StoreTargetStates // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckMyHealth(bool MyHealthIsLow); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CheckMyHealth // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckTargetHealth(struct AActor* CurrentTarget, bool TargetHealthIsLow); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CheckTargetHealth // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckRangeToTarget(bool TargetOutOfRange); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CheckRangeToTarget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckVisibility(bool TargetIsVisible); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CheckVisibility // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void TestDistanceToTarget(float MaxDistanceToTarget, bool OutOfRange); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.TestDistanceToTarget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckIfWantToFlee(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.CheckIfWantToFlee // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EvaluateTarget(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.EvaluateTarget // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnTakeDamage(struct AActor* DamagedActor, float UnmodifiedDamageAmount, float ArmorDamageAmount, float HealthDamageAmount, struct FDamageEvent DamageEvent, struct AActor* CauseActor, enum class None DamageModifiersApplied, struct AController* InstigatorController, struct FS_PreTakeDamageInfo DamageInfo); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.OnTakeDamage // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void TargetChanged(struct AS_CharacterBase* oldTarget, struct AS_CharacterBase* newTarget); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.TargetChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateIntensity(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.UpdateIntensity // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ResetIntensityCheck(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.ResetIntensityCheck // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ResetPursuitTimer(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.ResetPursuitTimer // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetNewPursuitTimer(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.SetNewPursuitTimer // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void AbortPursuit(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.AbortPursuit // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ResumePursuit(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.ResumePursuit // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void AlertOverlordOfAnAttack(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.AlertOverlordOfAnAttack // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Reset Self Preservation(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.Reset Self Preservation // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void PostTakeDamage(struct AActor* DamagedActor, float DamageAmount, struct FDamageEvent DamageEvent, struct AActor* CauseActor, bool Critical); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.PostTakeDamage // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ResetRecentlyDamagedBB(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.ResetRecentlyDamagedBB // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ResetDamageOof(); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.ResetDamageOof // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTS_Humanoid_Root(int32_t EntryPoint); // Function BTS_Humanoid_Root.BTS_Humanoid_Root_C.ExecuteUbergraph_BTS_Humanoid_Root // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

