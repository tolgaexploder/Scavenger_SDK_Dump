// BlueprintGeneratedClass BTD_Combat_Events.BTD_Combat_Events_C
// Size: 0xe8 (Inherited: 0xa0)
struct UBTD_Combat_Events_C : UBTDecorator_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa0(0x08)
	struct FName IsInCover; // 0xa8(0x08)
	struct FName PursueTarget; // 0xb0(0x08)
	struct FName ArmedMelee; // 0xb8(0x08)
	struct FName FoundIdealPosition; // 0xc0(0x08)
	struct FName SelfPreservation; // 0xc8(0x08)
	struct FName Mantling; // 0xd0(0x08)
	struct FName RallyState; // 0xd8(0x08)
	struct FName SuccessfulMantle; // 0xe0(0x08)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_Combat_Events.BTD_Combat_Events_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecutionFinish(struct AActor* OwnerActor, enum class EBTNodeResult NodeResult); // Function BTD_Combat_Events.BTD_Combat_Events_C.ReceiveExecutionFinish // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecutionStart(struct AActor* OwnerActor); // Function BTD_Combat_Events.BTD_Combat_Events_C.ReceiveExecutionStart // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTD_Combat_Events(int32_t EntryPoint); // Function BTD_Combat_Events.BTD_Combat_Events_C.ExecuteUbergraph_BTD_Combat_Events // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

