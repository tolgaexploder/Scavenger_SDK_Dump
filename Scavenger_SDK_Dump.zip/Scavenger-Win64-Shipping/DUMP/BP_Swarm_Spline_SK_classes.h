// BlueprintGeneratedClass BP_Swarm_Spline_SK.BP_Swarm_Spline_SK_C
// Size: 0x2e9 (Inherited: 0x288)
struct ABP_Swarm_Spline_SK_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x288(0x08)
	struct UParticleSystemComponent* Trail; // 0x290(0x08)
	struct USplineComponent* Spline1; // 0x298(0x08)
	float Dematerialize_Alpha_65DBFFDC45F951A5C60CAA94DA2AF8DD; // 0x2a0(0x04)
	enum class ETimelineDirection Dematerialize__Direction_65DBFFDC45F951A5C60CAA94DA2AF8DD; // 0x2a4(0x01)
	char UnknownData_2A5[0x3]; // 0x2a5(0x03)
	struct UTimelineComponent* Dematerialize; // 0x2a8(0x08)
	float Scrap Search Radius; // 0x2b0(0x04)
	struct FVector PlayerPosition; // 0x2b4(0x0c)
	struct FLinearColor Item Color; // 0x2c0(0x10)
	float Alpha; // 0x2d0(0x04)
	char UnknownData_2D4[0x4]; // 0x2d4(0x04)
	struct USkeletalMeshComponent* Player Mesh; // 0x2d8(0x08)
	struct FName Player Mesh Socket; // 0x2e0(0x08)
	bool SkipAnimation; // 0x2e8(0x01)

	void GetLastHitByAbiltiyActor(struct AActor* LastHitByAbilityActor); // Function BP_Swarm_Spline_SK.BP_Swarm_Spline_SK_C.GetLastHitByAbiltiyActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetLastHitByAbilityActor(struct AActor* ActorPerformingTheHIt, struct AActor* Actor); // Function BP_Swarm_Spline_SK.BP_Swarm_Spline_SK_C.SetLastHitByAbilityActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetCharacterAbility(bool NewParam); // Function BP_Swarm_Spline_SK.BP_Swarm_Spline_SK_C.GetCharacterAbility // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetGameVars(struct UBP_PlayerCharacterGameVarsTemplate_C* NewParam); // Function BP_Swarm_Spline_SK.BP_Swarm_Spline_SK_C.GetGameVars // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	int32_t GetDataRevision(); // Function BP_Swarm_Spline_SK.BP_Swarm_Spline_SK_C.GetDataRevision // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xffff8009123b0000
	void Dematerialize__FinishedFunc(); // Function BP_Swarm_Spline_SK.BP_Swarm_Spline_SK_C.Dematerialize__FinishedFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void Dematerialize__UpdateFunc(); // Function BP_Swarm_Spline_SK.BP_Swarm_Spline_SK_C.Dematerialize__UpdateFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void Dematerialize__CollideEvent__EventFunc(); // Function BP_Swarm_Spline_SK.BP_Swarm_Spline_SK_C.Dematerialize__CollideEvent__EventFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void FreedFromCocoon(); // Function BP_Swarm_Spline_SK.BP_Swarm_Spline_SK_C.FreedFromCocoon // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_Swarm_Spline_SK.BP_Swarm_Spline_SK_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Swarm_Spline_SK(int32_t EntryPoint); // Function BP_Swarm_Spline_SK.BP_Swarm_Spline_SK_C.ExecuteUbergraph_BP_Swarm_Spline_SK // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

