// BlueprintGeneratedClass BP_PROJ_Handgun_Base.BP_PROJ_Handgun_Base_C
// Size: 0x478 (Inherited: 0x46c)
struct ABP_PROJ_Handgun_Base_C : ABP_PROJ_ProjectileBase_C {
	char UnknownData_46C[0x4]; // 0x46c(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x470(0x08)

	void ReceiveBeginPlay(); // Function BP_PROJ_Handgun_Base.BP_PROJ_Handgun_Base_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTick(float DeltaSeconds); // Function BP_PROJ_Handgun_Base.BP_PROJ_Handgun_Base_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnImpactWithLandscape(struct FHitResult ImpactResult, float SnowDepth); // Function BP_PROJ_Handgun_Base.BP_PROJ_Handgun_Base_C.OnImpactWithLandscape // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnImpact(struct FHitResult ImpactResult); // Function BP_PROJ_Handgun_Base.BP_PROJ_Handgun_Base_C.OnImpact // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_PROJ_Handgun_Base(int32_t EntryPoint); // Function BP_PROJ_Handgun_Base.BP_PROJ_Handgun_Base_C.ExecuteUbergraph_BP_PROJ_Handgun_Base // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

