// BlueprintGeneratedClass BP_WPN_WeaponBase.BP_WPN_WeaponBase_C
// Size: 0xd61 (Inherited: 0xd50)
struct ABP_WPN_WeaponBase_C : AS_WeaponBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd50(0x08)
	struct UParticleSystemComponent* PS_Shell_Eject; // 0xd58(0x08)
	bool WantsVOAnnounceReload; // 0xd60(0x01)

	void OnWeaponDoAttack(); // Function BP_WPN_WeaponBase.BP_WPN_WeaponBase_C.OnWeaponDoAttack // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_WPN_WeaponBase.BP_WPN_WeaponBase_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnAttackEvent_Shell_Eject(enum class ES_TriggerType triggerType, enum class ES_AttackEvent attackEvent); // Function BP_WPN_WeaponBase.BP_WPN_WeaponBase_C.OnAttackEvent_Shell_Eject // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnAttackEventForVO(enum class ES_TriggerType triggerType, enum class ES_AttackEvent attackEvent); // Function BP_WPN_WeaponBase.BP_WPN_WeaponBase_C.OnAttackEventForVO // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_WPN_WeaponBase(int32_t EntryPoint); // Function BP_WPN_WeaponBase.BP_WPN_WeaponBase_C.ExecuteUbergraph_BP_WPN_WeaponBase // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

