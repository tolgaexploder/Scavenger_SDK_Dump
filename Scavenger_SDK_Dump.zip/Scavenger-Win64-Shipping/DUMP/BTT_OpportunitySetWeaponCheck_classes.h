// BlueprintGeneratedClass BTT_OpportunitySetWeaponCheck.BTT_OpportunitySetWeaponCheck_C
// Size: 0xb8 (Inherited: 0xa8)
struct UBTT_OpportunitySetWeaponCheck_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct FName ChangingWeaponState; // 0xb0(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_OpportunitySetWeaponCheck.BTT_OpportunitySetWeaponCheck_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTT_OpportunitySetWeaponCheck.BTT_OpportunitySetWeaponCheck_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_OpportunitySetWeaponCheck(int32_t EntryPoint); // Function BTT_OpportunitySetWeaponCheck.BTT_OpportunitySetWeaponCheck_C.ExecuteUbergraph_BTT_OpportunitySetWeaponCheck // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

