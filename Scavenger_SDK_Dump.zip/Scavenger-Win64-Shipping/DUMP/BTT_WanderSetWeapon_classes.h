// BlueprintGeneratedClass BTT_WanderSetWeapon.BTT_WanderSetWeapon_C
// Size: 0xc0 (Inherited: 0xa8)
struct UBTT_WanderSetWeapon_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb0(0x08)
	struct US_WeaponSystem* Cached WeaponSystemComp; // 0xb8(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_WanderSetWeapon.BTT_WanderSetWeapon_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void WeaponEvent(enum class ES_WeaponSlot weaponSlot, enum class ES_TriggerType triggerType, enum class ES_AttackEvent attackEvent); // Function BTT_WanderSetWeapon.BTT_WanderSetWeapon_C.WeaponEvent // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void WereReady(enum class ES_WeaponSlot weaponSlot, enum class ES_TriggerType triggerType, enum class ES_AttackEvent attackEvent); // Function BTT_WanderSetWeapon.BTT_WanderSetWeapon_C.WereReady // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_WanderSetWeapon(int32_t EntryPoint); // Function BTT_WanderSetWeapon.BTT_WanderSetWeapon_C.ExecuteUbergraph_BTT_WanderSetWeapon // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

