// BlueprintGeneratedClass BPI_KeeperInteractable.BPI_KeeperInteractable_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_KeeperInteractable_C : UInterface {

	void RemoteDisable_BPI(); // Function BPI_KeeperInteractable.BPI_KeeperInteractable_C.RemoteDisable_BPI // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetHarvestTimeRemaining_BPI(float HarvestTimeRemaining); // Function BPI_KeeperInteractable.BPI_KeeperInteractable_C.GetHarvestTimeRemaining_BPI // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

