// BlueprintGeneratedClass BTD_HasOpportunity.BTD_HasOpportunity_C
// Size: 0xa0 (Inherited: 0xa0)
struct UBTD_HasOpportunity_C : UBTDecorator_BlueprintBase {

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_HasOpportunity.BTD_HasOpportunity_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

