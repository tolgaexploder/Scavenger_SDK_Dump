// BlueprintGeneratedClass GE_ColdBlooded.GE_ColdBlooded_C
// Size: 0x7c0 (Inherited: 0x7b8)
struct UGE_ColdBlooded_C : UGameplayEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7b8(0x08)

	void ExecuteUbergraph_GE_ColdBlooded(int32_t EntryPoint); // Function GE_ColdBlooded.GE_ColdBlooded_C.ExecuteUbergraph_GE_ColdBlooded // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

