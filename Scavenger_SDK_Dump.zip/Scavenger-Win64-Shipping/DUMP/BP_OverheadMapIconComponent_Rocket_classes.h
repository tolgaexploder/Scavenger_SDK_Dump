// BlueprintGeneratedClass BP_OverheadMapIconComponent_Rocket.BP_OverheadMapIconComponent_Rocket_C
// Size: 0x180 (Inherited: 0x178)
struct UBP_OverheadMapIconComponent_Rocket_C : UBP_OverheadMapIconComponent_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x178(0x08)

	void GetText(struct FText Text); // Function BP_OverheadMapIconComponent_Rocket.BP_OverheadMapIconComponent_Rocket_C.GetText // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xffff8009123b0000
	void ReceiveTick(float DeltaSeconds); // Function BP_OverheadMapIconComponent_Rocket.BP_OverheadMapIconComponent_Rocket_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_OverheadMapIconComponent_Rocket(int32_t EntryPoint); // Function BP_OverheadMapIconComponent_Rocket.BP_OverheadMapIconComponent_Rocket_C.ExecuteUbergraph_BP_OverheadMapIconComponent_Rocket // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

