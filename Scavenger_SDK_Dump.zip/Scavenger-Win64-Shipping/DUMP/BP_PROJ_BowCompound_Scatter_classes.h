// BlueprintGeneratedClass BP_PROJ_BowCompound_Scatter.BP_PROJ_BowCompound_Scatter_C
// Size: 0x4a0 (Inherited: 0x478)
struct ABP_PROJ_BowCompound_Scatter_C : ABP_PROJ_Bow_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x478(0x08)
	float Time Elapsed; // 0x480(0x04)
	char UnknownData_484[0x4]; // 0x484(0x04)
	struct UCurveFloat* Homing Acceleration Curve; // 0x488(0x08)
	float StartingDistToTarget; // 0x490(0x04)
	char UnknownData_494[0x4]; // 0x494(0x04)
	struct AActor* HomingTarget; // 0x498(0x08)

	void SetHomingTarget(struct AActor* Target Actor); // Function BP_PROJ_BowCompound_Scatter.BP_PROJ_BowCompound_Scatter_C.SetHomingTarget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_PROJ_BowCompound_Scatter.BP_PROJ_BowCompound_Scatter_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTick(float DeltaSeconds); // Function BP_PROJ_BowCompound_Scatter.BP_PROJ_BowCompound_Scatter_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_PROJ_BowCompound_Scatter(int32_t EntryPoint); // Function BP_PROJ_BowCompound_Scatter.BP_PROJ_BowCompound_Scatter_C.ExecuteUbergraph_BP_PROJ_BowCompound_Scatter // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

