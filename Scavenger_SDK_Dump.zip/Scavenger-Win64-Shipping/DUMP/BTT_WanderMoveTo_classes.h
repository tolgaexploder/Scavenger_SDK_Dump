// BlueprintGeneratedClass BTT_WanderMoveTo.BTT_WanderMoveTo_C
// Size: 0xe0 (Inherited: 0xa8)
struct UBTT_WanderMoveTo_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xb0(0x08)
	struct AS_AIController* CachedAIController; // 0xb8(0x08)
	float AcceptanceRadius; // 0xc0(0x04)
	float MoveStartTime; // 0xc4(0x04)
	bool PlayIdleMontage; // 0xc8(0x01)
	char UnknownData_C9[0x3]; // 0xc9(0x03)
	struct FName IsPlayingAnimMontage; // 0xcc(0x08)
	char UnknownData_D4[0x4]; // 0xd4(0x04)
	struct US_AIAudioEventType* Arrive Audio; // 0xd8(0x08)

	void OnMoveFinished_BCD9F3794EA0BF4444DCCFBC135404F5(struct AAIController* AIController, enum class EPathFollowingResult PathFollowingResult, enum class ENavPathEvent NavPathEvent, enum class EPathFollowingRequestResult PathFollowingRequestResult); // Function BTT_WanderMoveTo.BTT_WanderMoveTo_C.OnMoveFinished_BCD9F3794EA0BF4444DCCFBC135404F5 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Interrupted_E7B4A93542B64362416B6693306B43AE(); // Function BTT_WanderMoveTo.BTT_WanderMoveTo_C.Interrupted_E7B4A93542B64362416B6693306B43AE // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Completed_E7B4A93542B64362416B6693306B43AE(); // Function BTT_WanderMoveTo.BTT_WanderMoveTo_C.Completed_E7B4A93542B64362416B6693306B43AE // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_WanderMoveTo.BTT_WanderMoveTo_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnAlreadyAtTargetLocation(); // Function BTT_WanderMoveTo.BTT_WanderMoveTo_C.OnAlreadyAtTargetLocation // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Abort Search Montage(struct AActor* DamagedActor, float UnmodifiedDamageAmount, float ArmorDamageAmount, float HealthDamageAmount, struct FDamageEvent DamageEvent, struct AActor* CauseActor, enum class None DamageModifiersApplied, struct AController* InstigatorController, struct FS_PreTakeDamageInfo DamageInfo); // Function BTT_WanderMoveTo.BTT_WanderMoveTo_C.Abort Search Montage // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_WanderMoveTo(int32_t EntryPoint); // Function BTT_WanderMoveTo.BTT_WanderMoveTo_C.ExecuteUbergraph_BTT_WanderMoveTo // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

