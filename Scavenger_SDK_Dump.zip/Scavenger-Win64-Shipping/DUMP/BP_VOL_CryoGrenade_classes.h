// BlueprintGeneratedClass BP_VOL_CryoGrenade.BP_VOL_CryoGrenade_C
// Size: 0x2c0 (Inherited: 0x2a8)
struct ABP_VOL_CryoGrenade_C : AS_GameplayEffectTeamVolume {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2a8(0x08)
	struct UBillboardComponent* Billboard; // 0x2b0(0x08)
	struct UStaticMeshComponent* Sphere; // 0x2b8(0x08)

	void ReceiveActorBeginOverlap(struct AActor* OtherActor); // Function BP_VOL_CryoGrenade.BP_VOL_CryoGrenade_C.ReceiveActorBeginOverlap // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void CustomEvent_1(struct AActor* Actor, struct FActiveGameplayEffectHandle GameplayEffectHandle); // Function BP_VOL_CryoGrenade.BP_VOL_CryoGrenade_C.CustomEvent_1 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_VOL_CryoGrenade.BP_VOL_CryoGrenade_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_VOL_CryoGrenade(int32_t EntryPoint); // Function BP_VOL_CryoGrenade.BP_VOL_CryoGrenade_C.ExecuteUbergraph_BP_VOL_CryoGrenade // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

