// BlueprintGeneratedClass BP_PROJ_SCAR_Explosive.BP_PROJ_SCAR_Explosive_C
// Size: 0x480 (Inherited: 0x478)
struct ABP_PROJ_SCAR_Explosive_C : ABP_PROJ_Energy_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x478(0x08)

	void OnImpact(struct FHitResult ImpactResult); // Function BP_PROJ_SCAR_Explosive.BP_PROJ_SCAR_Explosive_C.OnImpact // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_PROJ_SCAR_Explosive(int32_t EntryPoint); // Function BP_PROJ_SCAR_Explosive.BP_PROJ_SCAR_Explosive_C.ExecuteUbergraph_BP_PROJ_SCAR_Explosive // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

