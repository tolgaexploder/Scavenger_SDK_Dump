// BlueprintGeneratedClass BTT_CombatShoveAttack.BTT_CombatShoveAttack_C
// Size: 0xf8 (Inherited: 0xa8)
struct UBTT_CombatShoveAttack_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb0(0x08)
	struct AS_AIController* ScavengerController; // 0xb8(0x08)
	struct AActor* CurrentTarget; // 0xc0(0x08)
	float AllowFireAngle; // 0xc8(0x04)
	float AttackAlpha; // 0xcc(0x04)
	struct FName LastOffhandMeleeAttack; // 0xd0(0x08)
	struct FName IsAttackingWithMelee; // 0xd8(0x08)
	struct US_AIAudioEventType* Attack Audio; // 0xe0(0x08)
	struct FName MeleeShove; // 0xe8(0x08)
	struct FName StringWeapon; // 0xf0(0x08)

	void CountReached_187D25C943654F27D8AFD1AC9E5E3C3D(enum class ES_ScavengerResult Result); // Function BTT_CombatShoveAttack.BTT_CombatShoveAttack_C.CountReached_187D25C943654F27D8AFD1AC9E5E3C3D // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CountReached_065E23B943318B0162EE5CA2AD35B535(enum class ES_ScavengerResult Result); // Function BTT_CombatShoveAttack.BTT_CombatShoveAttack_C.CountReached_065E23B943318B0162EE5CA2AD35B535 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTT_CombatShoveAttack.BTT_CombatShoveAttack_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatShoveAttack(int32_t EntryPoint); // Function BTT_CombatShoveAttack.BTT_CombatShoveAttack_C.ExecuteUbergraph_BTT_CombatShoveAttack // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

