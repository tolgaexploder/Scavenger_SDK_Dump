// BlueprintGeneratedClass BTT_CombatCrouchFire.BTT_CombatCrouchFire_C
// Size: 0x100 (Inherited: 0xa8)
struct UBTT_CombatCrouchFire_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AActor* CurrentTarget; // 0xb0(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xb8(0x08)
	struct AS_AIController* CachedAIController; // 0xc0(0x08)
	float MinFireTime; // 0xc8(0x04)
	float MaxFireTime; // 0xcc(0x04)
	float FireDuration; // 0xd0(0x04)
	float ADSMaxMoveDistance; // 0xd4(0x04)
	float stopFireAge; // 0xd8(0x04)
	int32_t FireCount; // 0xdc(0x04)
	bool ADSWhileShooting; // 0xe0(0x01)
	char UnknownData_E1[0x3]; // 0xe1(0x03)
	struct FName HoldPosition; // 0xe4(0x08)
	bool HoldCrouchAtFinish; // 0xec(0x01)
	char UnknownData_ED[0x3]; // 0xed(0x03)
	struct FName Shotgunner; // 0xf0(0x08)
	struct FName StringWeapon; // 0xf8(0x08)

	void FocusOnTarget(); // Function BTT_CombatCrouchFire.BTT_CombatCrouchFire_C.FocusOnTarget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CountReached_1952B47B43F699BFE8898D9AD2FBB086(enum class ES_ScavengerResult Result); // Function BTT_CombatCrouchFire.BTT_CombatCrouchFire_C.CountReached_1952B47B43F699BFE8898D9AD2FBB086 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_CombatCrouchFire.BTT_CombatCrouchFire_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatCrouchFire(int32_t EntryPoint); // Function BTT_CombatCrouchFire.BTT_CombatCrouchFire_C.ExecuteUbergraph_BTT_CombatCrouchFire // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

