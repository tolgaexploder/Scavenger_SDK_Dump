// BlueprintGeneratedClass BTT_Leap.BTT_Leap_C
// Size: 0xc8 (Inherited: 0xa8)
struct UBTT_Leap_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct FName IsPlayingAnimMontage; // 0xb0(0x08)
	struct FName RunnerLeapAbilityKey; // 0xb8(0x08)
	struct FName Leaped; // 0xc0(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_Leap.BTT_Leap_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTT_Leap.BTT_Leap_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_Leap(int32_t EntryPoint); // Function BTT_Leap.BTT_Leap_C.ExecuteUbergraph_BTT_Leap // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

