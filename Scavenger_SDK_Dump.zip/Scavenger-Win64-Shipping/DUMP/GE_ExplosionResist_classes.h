// BlueprintGeneratedClass GE_ExplosionResist.GE_ExplosionResist_C
// Size: 0x7c0 (Inherited: 0x7b8)
struct UGE_ExplosionResist_C : UGameplayEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7b8(0x08)

	void ExecuteUbergraph_GE_ExplosionResist(int32_t EntryPoint); // Function GE_ExplosionResist.GE_ExplosionResist_C.ExecuteUbergraph_GE_ExplosionResist // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

