// BlueprintGeneratedClass BTD_IsBrainDead.BTD_IsBrainDead_C
// Size: 0xa4 (Inherited: 0xa0)
struct UBTD_IsBrainDead_C : UBTDecorator_BlueprintBase {
	float Cooldown Time; // 0xa0(0x04)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_IsBrainDead.BTD_IsBrainDead_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

