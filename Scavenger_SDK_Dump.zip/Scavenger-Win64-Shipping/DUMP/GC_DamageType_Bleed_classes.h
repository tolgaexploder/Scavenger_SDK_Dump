// BlueprintGeneratedClass GC_DamageType_Bleed.GC_DamageType_Bleed_C
// Size: 0x468 (Inherited: 0x460)
struct AGC_DamageType_Bleed_C : AGC_StatusEffect_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)

	void ReceiveBeginPlay(); // Function GC_DamageType_Bleed.GC_DamageType_Bleed_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GC_DamageType_Bleed.GC_DamageType_Bleed_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_GC_DamageType_Bleed(int32_t EntryPoint); // Function GC_DamageType_Bleed.GC_DamageType_Bleed_C.ExecuteUbergraph_GC_DamageType_Bleed // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

