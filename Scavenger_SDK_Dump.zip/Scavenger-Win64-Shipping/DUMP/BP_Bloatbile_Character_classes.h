// BlueprintGeneratedClass BP_Bloatbile_Character.BP_Bloatbile_Character_C
// Size: 0x2678 (Inherited: 0x25d0)
struct ABP_Bloatbile_Character_C : AS_AICharacterScourge {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x25d0(0x08)
	struct UParticleSystemComponent* PS_Outlander_Eye_Lensflare; // 0x25d8(0x08)
	struct US_PingMetadataComponent* S_PingMetadata; // 0x25e0(0x08)
	struct US_BoneDataComponent* BoneDataComponent; // 0x25e8(0x08)
	struct US_EquipmentComponent* EquipmentComponent; // 0x25f0(0x08)
	struct UMaterialInstanceDynamic* DynamicBodyMaterial; // 0x25f8(0x08)
	struct AAIController* AIController; // 0x2600(0x08)
	char UnknownData_2608[0x8]; // 0x2608(0x08)
	struct FTransform CachedVomitTransform; // 0x2610(0x30)
	enum class ES_AILocomotionState PrevLocomotionState; // 0x2640(0x01)
	enum class Sound_AITargetState PrevSoundTargetState; // 0x2641(0x01)
	enum class Sound_ExtraAITargetState PrevSoundExtraTargetState; // 0x2642(0x01)
	char UnknownData_2643[0x5]; // 0x2643(0x05)
	struct UDataTable* DT_WpnOutlanders; // 0x2648(0x08)
	struct UDataTable* DT_AMMO; // 0x2650(0x08)
	struct FName BoneName; // 0x2658(0x08)
	struct UParticleSystem* Dismemberment_PS_Flesh; // 0x2660(0x08)
	struct UParticleSystem* Death VFX; // 0x2668(0x08)
	struct AActor* LastHitByAbilityActor; // 0x2670(0x08)

	void GrenadeCooldownTime(float GrenadeCooldownTime); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.GrenadeCooldownTime // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsFollowerCompanion(bool IsFollowerCompanion); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.IsFollowerCompanion // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetGrenadeCount(int32_t GrenadeInvCount); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.GetGrenadeCount // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetLastHitByAbilityActor(struct AActor* ActorPerformingLastHit, struct AActor* ActorHit); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.SetLastHitByAbilityActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetLastHitByAbilityActor(struct AActor* ActorPerformingTheHIt); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.GetLastHitByAbilityActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetCachedVomitLocation(struct FTransform VomitLocation); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.GetCachedVomitLocation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Foot Particle FX(enum class EPhysicalSurface Surface Type, struct FVector World Position); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.Foot Particle FX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void DropWpnAmmo(); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.DropWpnAmmo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetCachedVomitLocation(struct FTransform VomitLocation); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.SetCachedVomitLocation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateGrenadeCount(int32_t NewCount); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.UpdateGrenadeCount // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetAIIgnored(); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.SetAIIgnored // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnEnterRagDoll_BP(struct FHitResult HitResult, float timeSinceHit); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.OnEnterRagDoll_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void CustomEvent_OnRagdollRollback(struct AController* PredictiveInstigator); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.CustomEvent_OnRagdollRollback // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void RevealAI(); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.RevealAI // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void BP_HandleOnStatChange(enum class ES_StatType StatType, enum class ES_StatChangeCauseType CauseType, struct AActor* SourceActor, struct AController* InstigatorController, float OldStatValue, float StatValueChange, float NewStatValue); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.BP_HandleOnStatChange // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Play Death FX(bool Interrupted); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.Play Death FX // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void NotifyBoneEnteredSnow_BP(struct FName BoneName, struct FVector GroundPosition, float SnowHeight, struct UPhysicalMaterial* PhysicalMaterial); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.NotifyBoneEnteredSnow_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void NotifyBoneLeftSnow_BP(struct FName BoneName, struct FVector GroundPosition, float SnowHeight, struct UPhysicalMaterial* PhysicalMaterial); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.NotifyBoneLeftSnow_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Bloatbile_Character(int32_t EntryPoint); // Function BP_Bloatbile_Character.BP_Bloatbile_Character_C.ExecuteUbergraph_BP_Bloatbile_Character // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

