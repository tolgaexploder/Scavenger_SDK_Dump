// BlueprintGeneratedClass BP_Sight_Grenade_Base.BP_Sight_Grenade_Base_C
// Size: 0x408 (Inherited: 0x400)
struct ABP_Sight_Grenade_Base_C : ABP_Sight_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)

	void ReceiveBeginPlay(); // Function BP_Sight_Grenade_Base.BP_Sight_Grenade_Base_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Sight_Grenade_Base(int32_t EntryPoint); // Function BP_Sight_Grenade_Base.BP_Sight_Grenade_Base_C.ExecuteUbergraph_BP_Sight_Grenade_Base // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

