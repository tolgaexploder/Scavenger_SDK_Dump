// BlueprintGeneratedClass BPI_Bank.BPI_Bank_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_Bank_C : UInterface {

	void Bank_BankingCompleted(); // Function BPI_Bank.BPI_Bank_C.Bank_BankingCompleted // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

