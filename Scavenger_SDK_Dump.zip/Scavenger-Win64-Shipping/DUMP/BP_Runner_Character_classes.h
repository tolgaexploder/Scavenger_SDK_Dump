// BlueprintGeneratedClass BP_Runner_Character.BP_Runner_Character_C
// Size: 0x26ac (Inherited: 0x263c)
struct ABP_Runner_Character_C : ABP_AICharacterBase_C {
	char UnknownData_263C[0x4]; // 0x263c(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2640(0x08)
	struct UParticleSystemComponent* LensFlare; // 0x2648(0x08)
	struct US_PingMetadataComponent* S_PingMetadata; // 0x2650(0x08)
	struct UAudioComponent* Audio; // 0x2658(0x08)
	struct UMaterialInstanceDynamic* DynamicBodyMaterial; // 0x2660(0x08)
	struct FMulticastInlineDelegate MakeAggro; // 0x2668(0x10)
	struct AAIController* AIController; // 0x2678(0x08)
	struct UBlackboardComponent* Blackboard_1; // 0x2680(0x08)
	float LocalTime; // 0x2688(0x04)
	float NewVar_0_1; // 0x268c(0x04)
	bool isTerminal; // 0x2690(0x01)
	char UnknownData_2691[0x3]; // 0x2691(0x03)
	float BlendWeight; // 0x2694(0x04)
	bool Dead; // 0x2698(0x01)
	bool Left; // 0x2699(0x01)
	bool Right; // 0x269a(0x01)
	bool Front; // 0x269b(0x01)
	bool Back; // 0x269c(0x01)
	char UnknownData_269D[0x3]; // 0x269d(0x03)
	struct FName BonesBelow; // 0x26a0(0x08)
	enum class ES_AILocomotionState PrevLocomotionState; // 0x26a8(0x01)
	enum class Sound_AITargetState PrevSoundTargetState; // 0x26a9(0x01)
	enum class Sound_ExtraAITargetState PrevSoundExtraTargetState; // 0x26aa(0x01)
	bool AmCaptive; // 0x26ab(0x01)

	struct UAnimMontage* SelectAttackMontageVariant(struct TArray<struct UAnimMontage*> MontageVariations, enum class ES_WeaponMontageEvent attackEvent, enum class ES_TriggerType triggerType); // Function BP_Runner_Character.BP_Runner_Character_C.SelectAttackMontageVariant // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UserConstructionScript(); // Function BP_Runner_Character.BP_Runner_Character_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SpawnGroundGoop(struct FVector Location); // Function BP_Runner_Character.BP_Runner_Character_C.SpawnGroundGoop // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SpawnGroundMiasma(struct FVector Location); // Function BP_Runner_Character.BP_Runner_Character_C.SpawnGroundMiasma // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_Runner_Character.BP_Runner_Character_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetDeathOnTerminal(struct US_StatsComponent* StatsComponent, enum class ES_StatsState OldState, enum class ES_StatsState NewState); // Function BP_Runner_Character.BP_Runner_Character_C.SetDeathOnTerminal // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Runner_Character(int32_t EntryPoint); // Function BP_Runner_Character.BP_Runner_Character_C.ExecuteUbergraph_BP_Runner_Character // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
	void MakeAggro__DelegateSignature(struct AActor* Sender); // Function BP_Runner_Character.BP_Runner_Character_C.MakeAggro__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

