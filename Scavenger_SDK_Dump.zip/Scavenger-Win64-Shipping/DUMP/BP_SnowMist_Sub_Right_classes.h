// BlueprintGeneratedClass BP_SnowMist_Sub_Right.BP_SnowMist_Sub_Right_C
// Size: 0x2b8 (Inherited: 0x288)
struct ABP_SnowMist_Sub_Right_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x288(0x08)
	struct UArrowComponent* Arrow; // 0x290(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x298(0x08)
	float Mist Radius Scale; // 0x2a0(0x04)
	char UnknownData_2A4[0x4]; // 0x2a4(0x04)
	struct UParticleSystem* Particle System Played Within Radius; // 0x2a8(0x08)
	bool Is in Shelter; // 0x2b0(0x01)
	char UnknownData_2B1[0x3]; // 0x2b1(0x03)
	float Storminess; // 0x2b4(0x04)

	void Milliseconds(); // Function BP_SnowMist_Sub_Right.BP_SnowMist_Sub_Right_C.Milliseconds // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Custom Tick(); // Function BP_SnowMist_Sub_Right.BP_SnowMist_Sub_Right_C.Custom Tick // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_SnowMist_Sub_Right.BP_SnowMist_Sub_Right_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_SnowMist_Sub_Right(int32_t EntryPoint); // Function BP_SnowMist_Sub_Right.BP_SnowMist_Sub_Right_C.ExecuteUbergraph_BP_SnowMist_Sub_Right // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

