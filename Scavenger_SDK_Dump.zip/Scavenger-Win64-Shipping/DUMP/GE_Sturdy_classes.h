// BlueprintGeneratedClass GE_Sturdy.GE_Sturdy_C
// Size: 0x7c0 (Inherited: 0x7b8)
struct UGE_Sturdy_C : UGameplayEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7b8(0x08)

	void ExecuteUbergraph_GE_Sturdy(int32_t EntryPoint); // Function GE_Sturdy.GE_Sturdy_C.ExecuteUbergraph_GE_Sturdy // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

