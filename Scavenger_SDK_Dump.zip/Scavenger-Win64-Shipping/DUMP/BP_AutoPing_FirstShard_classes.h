// BlueprintGeneratedClass BP_AutoPing_FirstShard.BP_AutoPing_FirstShard_C
// Size: 0x2a0 (Inherited: 0x298)
struct UBP_AutoPing_FirstShard_C : US_EncounterAutoPing {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x298(0x08)

	bool EvaluatePing_BP(struct AS_PlayerController* PlayerController); // Function BP_AutoPing_FirstShard.BP_AutoPing_FirstShard_C.EvaluatePing_BP // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_AutoPing_FirstShard.BP_AutoPing_FirstShard_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_AutoPing_FirstShard(int32_t EntryPoint); // Function BP_AutoPing_FirstShard.BP_AutoPing_FirstShard_C.ExecuteUbergraph_BP_AutoPing_FirstShard // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

