// BlueprintGeneratedClass BP_SlukaProxy.BP_SlukaProxy_C
// Size: 0x2a1 (Inherited: 0x288)
struct ABP_SlukaProxy_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x288(0x08)
	struct US_OverheadMapIconComponent* S_OverheadMapIcon; // 0x290(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x298(0x08)
	bool Kill; // 0x2a0(0x01)

	void OnRep_kill(); // Function BP_SlukaProxy.BP_SlukaProxy_C.OnRep_kill // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_SlukaProxy.BP_SlukaProxy_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void RemoveMe(); // Function BP_SlukaProxy.BP_SlukaProxy_C.RemoveMe // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_SlukaProxy.BP_SlukaProxy_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_SlukaProxy(int32_t EntryPoint); // Function BP_SlukaProxy.BP_SlukaProxy_C.ExecuteUbergraph_BP_SlukaProxy // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

