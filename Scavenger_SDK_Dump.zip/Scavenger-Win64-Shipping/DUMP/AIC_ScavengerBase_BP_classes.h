// BlueprintGeneratedClass AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C
// Size: 0x8cb (Inherited: 0x868)
struct AAIC_ScavengerBase_BP_C : AS_AIController {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x868(0x08)
	struct UAIPerceptionComponent* AIPerception; // 0x870(0x08)
	struct AS_AIController* ScavengerFriend; // 0x878(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0x880(0x08)
	struct US_AIAudioEventType* LeaderDiedAudio; // 0x888(0x08)
	struct US_AIAudioEventType* FriendDiedAudio; // 0x890(0x08)
	int32_t SearchStage; // 0x898(0x04)
	struct FName TryHailAnim; // 0x89c(0x08)
	struct FName StringWeapon; // 0x8a4(0x08)
	struct FName Shotgunner; // 0x8ac(0x08)
	struct FName StageChanged; // 0x8b4(0x08)
	bool OverlordSetup; // 0x8bc(0x01)
	bool FlinchEvent; // 0x8bd(0x01)
	char UnknownData_8BE[0x2]; // 0x8be(0x02)
	float hailDistance; // 0x8c0(0x04)
	float MaxHailDistanceValid_Flinch; // 0x8c4(0x04)
	bool HasFlinched; // 0x8c8(0x01)
	bool IHasShotgun; // 0x8c9(0x01)
	bool IHasStringWeapon; // 0x8ca(0x01)

	void IsImmobile(bool IsImmobile); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.IsImmobile // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void HasStringWeapoon(bool HasStringWeapon); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.HasStringWeapoon // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsBuzzsaw(bool Result); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.IsBuzzsaw // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CanUseTactics(bool Result); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.CanUseTactics // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void DoesHardPingGrenadeDrop(bool Result); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.DoesHardPingGrenadeDrop // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ShouldAlwaysHail(bool ShouldAlwaysHail); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.ShouldAlwaysHail // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void HasShotgun(bool Shotgunner); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.HasShotgun // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void RegisterDebugBBKeys(); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.RegisterDebugBBKeys // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void TargetIsNotInCombatWithOverlord(struct AS_CharacterBase* SpottedTarget, bool UnknownTarget); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.TargetIsNotInCombatWithOverlord // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void MyFriendDied(); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.MyFriendDied // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void MyLeaderDied(); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.MyLeaderDied // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Muppet(); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.Muppet // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnFriendlyHail_BP(struct AS_AIController* ScavengerFriend, enum class ES_AIHail hailType, struct FString Message, float hailDistance); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.OnFriendlyHail_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTick(float DeltaSeconds); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnStageChanged(struct FString newStageName, enum class ES_StageChangeUrgency stageChangeUrgency, enum class ES_StageChangeStateHint stageChangeStateHint); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.OnStageChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Flinch(); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.Flinch // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnHailingFriendlies_BP(enum class ES_AIHail hailType, struct FString Message); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.OnHailingFriendlies_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_AIC_ScavengerBase_BP(int32_t EntryPoint); // Function AIC_ScavengerBase_BP.AIC_ScavengerBase_BP_C.ExecuteUbergraph_AIC_ScavengerBase_BP // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

