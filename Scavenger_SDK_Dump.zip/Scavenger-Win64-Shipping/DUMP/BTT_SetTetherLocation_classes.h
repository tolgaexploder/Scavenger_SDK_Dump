// BlueprintGeneratedClass BTT_SetTetherLocation.BTT_SetTetherLocation_C
// Size: 0xc0 (Inherited: 0xa8)
struct UBTT_SetTetherLocation_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	bool ReturnTrue?; // 0xb0(0x01)
	char UnknownData_B1[0x7]; // 0xb1(0x07)
	struct AS_AIOverlordActor* Overlord; // 0xb8(0x08)

	struct FVector SetOverlordScoringPoint(struct AS_AIOverlordActor* Overlord, struct AS_AIController* Controller); // Function BTT_SetTetherLocation.BTT_SetTetherLocation_C.SetOverlordScoringPoint // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_SetTetherLocation.BTT_SetTetherLocation_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_SetTetherLocation(int32_t EntryPoint); // Function BTT_SetTetherLocation.BTT_SetTetherLocation_C.ExecuteUbergraph_BTT_SetTetherLocation // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

