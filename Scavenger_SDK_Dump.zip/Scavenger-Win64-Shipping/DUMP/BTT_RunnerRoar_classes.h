// BlueprintGeneratedClass BTT_RunnerRoar.BTT_RunnerRoar_C
// Size: 0xc8 (Inherited: 0xa8)
struct UBTT_RunnerRoar_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xb0(0x08)
	struct AS_AIController* CachedAIController; // 0xb8(0x08)
	struct FName IsPlayingAnimMontage; // 0xc0(0x08)

	void Interrupted_5373E75646BFABAA714D5DAF951CE78A(); // Function BTT_RunnerRoar.BTT_RunnerRoar_C.Interrupted_5373E75646BFABAA714D5DAF951CE78A // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Completed_5373E75646BFABAA714D5DAF951CE78A(); // Function BTT_RunnerRoar.BTT_RunnerRoar_C.Completed_5373E75646BFABAA714D5DAF951CE78A // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_RunnerRoar.BTT_RunnerRoar_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_RunnerRoar(int32_t EntryPoint); // Function BTT_RunnerRoar.BTT_RunnerRoar_C.ExecuteUbergraph_BTT_RunnerRoar // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

