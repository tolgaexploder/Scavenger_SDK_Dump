// BlueprintGeneratedClass BTT_OpportunityMoveToTarget.BTT_OpportunityMoveToTarget_C
// Size: 0xd4 (Inherited: 0xa8)
struct UBTT_OpportunityMoveToTarget_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xb0(0x08)
	struct AS_AIController* CachedAIController; // 0xb8(0x08)
	float PathfindingAcceptanceRadius; // 0xc0(0x04)
	bool StopFire; // 0xc4(0x01)
	char UnknownData_C5[0x3]; // 0xc5(0x03)
	float MoveStartTime; // 0xc8(0x04)
	struct FName IsPlayingAnimMontage; // 0xcc(0x08)

	void OnMoveFinished_253BBE1C47341CA4BC0445B6A973D9D8(struct AAIController* AIController, enum class EPathFollowingResult PathFollowingResult, enum class ENavPathEvent NavPathEvent, enum class EPathFollowingRequestResult PathFollowingRequestResult); // Function BTT_OpportunityMoveToTarget.BTT_OpportunityMoveToTarget_C.OnMoveFinished_253BBE1C47341CA4BC0445B6A973D9D8 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void LerpToReached_3A0D449A45AD42873CC24686013A6723(enum class ES_ScavengerResult Result); // Function BTT_OpportunityMoveToTarget.BTT_OpportunityMoveToTarget_C.LerpToReached_3A0D449A45AD42873CC24686013A6723 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_OpportunityMoveToTarget.BTT_OpportunityMoveToTarget_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_OpportunityMoveToTarget(int32_t EntryPoint); // Function BTT_OpportunityMoveToTarget.BTT_OpportunityMoveToTarget_C.ExecuteUbergraph_BTT_OpportunityMoveToTarget // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

