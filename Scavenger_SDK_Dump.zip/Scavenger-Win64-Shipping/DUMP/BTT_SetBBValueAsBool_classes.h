// BlueprintGeneratedClass BTT_SetBBValueAsBool.BTT_SetBBValueAsBool_C
// Size: 0xe0 (Inherited: 0xa8)
struct UBTT_SetBBValueAsBool_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	bool ValueToSet; // 0xb0(0x01)
	char UnknownData_B1[0x7]; // 0xb1(0x07)
	struct FBlackboardKeySelector Blackboard; // 0xb8(0x28)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_SetBBValueAsBool.BTT_SetBBValueAsBool_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_SetBBValueAsBool(int32_t EntryPoint); // Function BTT_SetBBValueAsBool.BTT_SetBBValueAsBool_C.ExecuteUbergraph_BTT_SetBBValueAsBool // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

