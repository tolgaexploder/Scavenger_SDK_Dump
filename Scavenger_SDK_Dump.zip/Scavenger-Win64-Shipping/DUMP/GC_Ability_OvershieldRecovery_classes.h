// BlueprintGeneratedClass GC_Ability_OvershieldRecovery.GC_Ability_OvershieldRecovery_C
// Size: 0x468 (Inherited: 0x460)
struct AGC_Ability_OvershieldRecovery_C : AGC_StatusEffect_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)

	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GC_Ability_OvershieldRecovery.GC_Ability_OvershieldRecovery_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_GC_Ability_OvershieldRecovery(int32_t EntryPoint); // Function GC_Ability_OvershieldRecovery.GC_Ability_OvershieldRecovery_C.ExecuteUbergraph_GC_Ability_OvershieldRecovery // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

