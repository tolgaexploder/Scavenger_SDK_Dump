// BlueprintGeneratedClass GC_Ability_CurativeAura.GC_Ability_CurativeAura_C
// Size: 0x468 (Inherited: 0x460)
struct AGC_Ability_CurativeAura_C : AGC_StatusEffect_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)

	void ReceiveBeginPlay(); // Function GC_Ability_CurativeAura.GC_Ability_CurativeAura_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GC_Ability_CurativeAura.GC_Ability_CurativeAura_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_GC_Ability_CurativeAura(int32_t EntryPoint); // Function GC_Ability_CurativeAura.GC_Ability_CurativeAura_C.ExecuteUbergraph_GC_Ability_CurativeAura // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

