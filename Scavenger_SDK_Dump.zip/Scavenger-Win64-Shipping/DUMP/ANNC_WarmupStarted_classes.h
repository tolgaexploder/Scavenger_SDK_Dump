// BlueprintGeneratedClass ANNC_WarmupStarted.SequenceDirector_C
// Size: 0x38 (Inherited: 0x30)
struct USequenceDirector_C : ULevelSequenceDirector {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x30(0x08)

	void SequenceEvent__ENTRYPOINTSequenceDirector_1(); // Function ANNC_WarmupStarted.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SequenceEvent_1(enum class ES_MusicCue Cue); // Function ANNC_WarmupStarted.SequenceDirector_C.SequenceEvent_1 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_SequenceDirector(int32_t EntryPoint); // Function ANNC_WarmupStarted.SequenceDirector_C.ExecuteUbergraph_SequenceDirector // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

