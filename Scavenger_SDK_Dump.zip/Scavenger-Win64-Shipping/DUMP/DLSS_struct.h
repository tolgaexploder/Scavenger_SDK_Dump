// Enum DLSS.EDLSSSettingOverride
enum class EDLSSSettingOverride : uint8 {
	Enabled,
	Disabled,
	UseProjectSettings,
	EDLSSSettingOverride_MAX,
};

