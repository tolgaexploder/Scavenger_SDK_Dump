// BlueprintGeneratedClass BP_WPN_Bow_Wood.BP_WPN_Bow_Wood_C
// Size: 0xd90 (Inherited: 0xd61)
struct ABP_WPN_Bow_Wood_C : ABP_WPN_WeaponBase_C {
	char UnknownData_D61[0x7]; // 0xd61(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd68(0x08)
	struct UParticleSystemComponent* Arrow_VFX; // 0xd70(0x08)
	struct USC_SkeletalMeshComponent* Arrow; // 0xd78(0x08)
	float Timeline_0_EffectAlpha_640BB58A47E5FE1E630C2C94F83FB755; // 0xd80(0x04)
	enum class ETimelineDirection Timeline_0__Direction_640BB58A47E5FE1E630C2C94F83FB755; // 0xd84(0x01)
	char UnknownData_D85[0x3]; // 0xd85(0x03)
	struct UTimelineComponent* Timeline_1; // 0xd88(0x08)

	void Timeline_0__FinishedFunc(); // Function BP_WPN_Bow_Wood.BP_WPN_Bow_Wood_C.Timeline_0__FinishedFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void Timeline_0__UpdateFunc(); // Function BP_WPN_Bow_Wood.BP_WPN_Bow_Wood_C.Timeline_0__UpdateFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTick(float DeltaSeconds); // Function BP_WPN_Bow_Wood.BP_WPN_Bow_Wood_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void Handle Arrow Visibility(enum class ES_TriggerType triggerType, enum class ES_AttackEvent attackEvent); // Function BP_WPN_Bow_Wood.BP_WPN_Bow_Wood_C.Handle Arrow Visibility // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_WPN_Bow_Wood.BP_WPN_Bow_Wood_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_WPN_Bow_Wood(int32_t EntryPoint); // Function BP_WPN_Bow_Wood.BP_WPN_Bow_Wood_C.ExecuteUbergraph_BP_WPN_Bow_Wood // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

