// BlueprintGeneratedClass GE_BleedReq.GE_BleedReq_C
// Size: 0x28 (Inherited: 0x28)
struct UGE_BleedReq_C : UGameplayEffectCustomApplicationRequirement {

	bool CanApplyGameplayEffect(struct UGameplayEffect* GameplayEffect, struct FGameplayEffectSpec Spec, struct UAbilitySystemComponent* ASC); // Function GE_BleedReq.GE_BleedReq_C.CanApplyGameplayEffect // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xffff8009123b0000
};

