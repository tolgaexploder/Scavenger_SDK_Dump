// BlueprintGeneratedClass BTT_SetLocomotionState.BTT_SetLocomotionState_C
// Size: 0xb1 (Inherited: 0xa8)
struct UBTT_SetLocomotionState_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	enum class ES_AILocomotionState newLocomotionState; // 0xb0(0x01)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_SetLocomotionState.BTT_SetLocomotionState_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_SetLocomotionState(int32_t EntryPoint); // Function BTT_SetLocomotionState.BTT_SetLocomotionState_C.ExecuteUbergraph_BTT_SetLocomotionState // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

