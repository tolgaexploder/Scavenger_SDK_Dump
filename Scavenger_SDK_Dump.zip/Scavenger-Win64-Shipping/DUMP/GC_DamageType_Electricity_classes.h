// BlueprintGeneratedClass GC_DamageType_Electricity.GC_DamageType_Electricity_C
// Size: 0x468 (Inherited: 0x460)
struct AGC_DamageType_Electricity_C : AGC_StatusEffect_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)

	void Get Camera Data(struct AActor* Target, struct FVector Camera Position, struct FRotator Camera Rotation, float Camera FOV, float Camera Aspect Ratio, struct APlayerCameraManager* Camera); // Function GC_DamageType_Electricity.GC_DamageType_Electricity_C.Get Camera Data // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GC_DamageType_Electricity.GC_DamageType_Electricity_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function GC_DamageType_Electricity.GC_DamageType_Electricity_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_GC_DamageType_Electricity(int32_t EntryPoint); // Function GC_DamageType_Electricity.GC_DamageType_Electricity_C.ExecuteUbergraph_GC_DamageType_Electricity // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

