// BlueprintGeneratedClass BP_AutoPing_ShardLocator.BP_AutoPing_ShardLocator_C
// Size: 0x2a0 (Inherited: 0x298)
struct UBP_AutoPing_ShardLocator_C : US_EncounterAutoPing {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x298(0x08)

	bool EvaluatePing_BP(struct AS_PlayerController* PlayerController); // Function BP_AutoPing_ShardLocator.BP_AutoPing_ShardLocator_C.EvaluatePing_BP // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_AutoPing_ShardLocator.BP_AutoPing_ShardLocator_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_AutoPing_ShardLocator(int32_t EntryPoint); // Function BP_AutoPing_ShardLocator.BP_AutoPing_ShardLocator_C.ExecuteUbergraph_BP_AutoPing_ShardLocator // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

