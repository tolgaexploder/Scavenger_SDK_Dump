// BlueprintGeneratedClass BTT_StopPathfinding.BTT_StopPathfinding_C
// Size: 0xb1 (Inherited: 0xa8)
struct UBTT_StopPathfinding_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	bool ReturnTrue?; // 0xb0(0x01)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_StopPathfinding.BTT_StopPathfinding_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_StopPathfinding(int32_t EntryPoint); // Function BTT_StopPathfinding.BTT_StopPathfinding_C.ExecuteUbergraph_BTT_StopPathfinding // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

