// BlueprintGeneratedClass BPI_AI_TurretSentry.BPI_AI_TurretSentry_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_AI_TurretSentry_C : UInterface {

	void FireAlert_BPI(); // Function BPI_AI_TurretSentry.BPI_AI_TurretSentry_C.FireAlert_BPI // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

