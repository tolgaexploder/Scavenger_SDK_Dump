// BlueprintGeneratedClass BP_Runner_Elite_Character.BP_Runner_Elite_Character_C
// Size: 0x26d2 (Inherited: 0x26ac)
struct ABP_Runner_Elite_Character_C : ABP_Runner_Character_C {
	char UnknownData_26AC[0x4]; // 0x26ac(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x26b0(0x08)
	struct FMulticastInlineDelegate MakeAggro_1; // 0x26b8(0x10)
	struct UBlackboardComponent* BlackBoard_0_1; // 0x26c8(0x08)
	bool isTerminal_1; // 0x26d0(0x01)
	bool Dead_1; // 0x26d1(0x01)

	struct UAnimMontage* SelectAttackMontageVariant(struct TArray<struct UAnimMontage*> MontageVariations, enum class ES_WeaponMontageEvent attackEvent, enum class ES_TriggerType triggerType); // Function BP_Runner_Elite_Character.BP_Runner_Elite_Character_C.SelectAttackMontageVariant // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Runner_Elite_Character(int32_t EntryPoint); // Function BP_Runner_Elite_Character.BP_Runner_Elite_Character_C.ExecuteUbergraph_BP_Runner_Elite_Character // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
	void MakeAggro_0__DelegateSignature(struct AActor* Sender); // Function BP_Runner_Elite_Character.BP_Runner_Elite_Character_C.MakeAggro_0__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

