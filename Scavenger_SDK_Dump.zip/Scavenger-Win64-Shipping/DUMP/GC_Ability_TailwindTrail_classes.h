// BlueprintGeneratedClass GC_Ability_TailwindTrail.GC_Ability_TailwindTrail_C
// Size: 0x470 (Inherited: 0x460)
struct AGC_Ability_TailwindTrail_C : AGC_StatusEffect_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)
	struct UParticleSystemComponent* PS_Sprint_DashLines; // 0x468(0x08)

	void Check Velocity(); // Function GC_Ability_TailwindTrail.GC_Ability_TailwindTrail_C.Check Velocity // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GC_Ability_TailwindTrail.GC_Ability_TailwindTrail_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_GC_Ability_TailwindTrail(int32_t EntryPoint); // Function GC_Ability_TailwindTrail.GC_Ability_TailwindTrail_C.ExecuteUbergraph_GC_Ability_TailwindTrail // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

