// BlueprintGeneratedClass BP_WPN_Player_MP7_RapidFire.BP_WPN_Player_MP7_RapidFire_C
// Size: 0xd70 (Inherited: 0xd61)
struct ABP_WPN_Player_MP7_RapidFire_C : ABP_WPN_Player_MP7_Base_C {
	char UnknownData_D61[0x7]; // 0xd61(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd68(0x08)

	void ReceiveBeginPlay(); // Function BP_WPN_Player_MP7_RapidFire.BP_WPN_Player_MP7_RapidFire_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_WPN_Player_MP7_RapidFire(int32_t EntryPoint); // Function BP_WPN_Player_MP7_RapidFire.BP_WPN_Player_MP7_RapidFire_C.ExecuteUbergraph_BP_WPN_Player_MP7_RapidFire // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

