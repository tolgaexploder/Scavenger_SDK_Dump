// BlueprintGeneratedClass BPI_Consumable.BPI_Consumable_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_Consumable_C : UInterface {

	void SwitchTeamOnConsume(bool TRUE); // Function BPI_Consumable.BPI_Consumable_C.SwitchTeamOnConsume // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Consume(bool Consumed); // Function BPI_Consumable.BPI_Consumable_C.Consume // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

