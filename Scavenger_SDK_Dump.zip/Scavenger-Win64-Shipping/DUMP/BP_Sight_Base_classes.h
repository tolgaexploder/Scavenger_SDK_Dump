// BlueprintGeneratedClass BP_Sight_Base.BP_Sight_Base_C
// Size: 0x400 (Inherited: 0x3e8)
struct ABP_Sight_Base_C : AS_WeaponAttachmentSight {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3e8(0x08)
	struct UParticleSystemComponent* PS_Lens_Glint_Common; // 0x3f0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x3f8(0x08)

	void ADS Update(bool IsADSOn); // Function BP_Sight_Base.BP_Sight_Base_C.ADS Update // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_Sight_Base.BP_Sight_Base_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Sight_Base(int32_t EntryPoint); // Function BP_Sight_Base.BP_Sight_Base_C.ExecuteUbergraph_BP_Sight_Base // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

