// BlueprintGeneratedClass BTT_CombatSpitterShove.BTT_CombatSpitterShove_C
// Size: 0xe0 (Inherited: 0xa8)
struct UBTT_CombatSpitterShove_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb0(0x08)
	struct AS_AIController* ScavengerController; // 0xb8(0x08)
	struct AActor* CurrentTarget; // 0xc0(0x08)
	float AttackAlpha; // 0xc8(0x04)
	float AllowFireAngle; // 0xcc(0x04)
	struct FName IsAttackingWithMelee; // 0xd0(0x08)
	struct FName LastOffhandMeleeAttack; // 0xd8(0x08)

	void CountReached_A26AFEF146CB78A7C5BAE9A3196F58C2(enum class ES_ScavengerResult Result); // Function BTT_CombatSpitterShove.BTT_CombatSpitterShove_C.CountReached_A26AFEF146CB78A7C5BAE9A3196F58C2 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTT_CombatSpitterShove.BTT_CombatSpitterShove_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatSpitterShove(int32_t EntryPoint); // Function BTT_CombatSpitterShove.BTT_CombatSpitterShove_C.ExecuteUbergraph_BTT_CombatSpitterShove // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

