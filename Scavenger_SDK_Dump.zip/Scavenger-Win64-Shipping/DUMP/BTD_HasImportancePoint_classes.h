// BlueprintGeneratedClass BTD_HasImportancePoint.BTD_HasImportancePoint_C
// Size: 0xa0 (Inherited: 0xa0)
struct UBTD_HasImportancePoint_C : UBTDecorator_BlueprintBase {

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_HasImportancePoint.BTD_HasImportancePoint_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

