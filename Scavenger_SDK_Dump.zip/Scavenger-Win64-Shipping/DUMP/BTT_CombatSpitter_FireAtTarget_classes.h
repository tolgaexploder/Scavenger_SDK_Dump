// BlueprintGeneratedClass BTT_CombatSpitter_FireAtTarget.BTT_CombatSpitter_FireAtTarget_C
// Size: 0xec (Inherited: 0xa8)
struct UBTT_CombatSpitter_FireAtTarget_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb0(0x08)
	struct AS_AIController* ScavengerController; // 0xb8(0x08)
	struct AActor* CurrentTarget; // 0xc0(0x08)
	float AllowFireAngle; // 0xc8(0x04)
	struct FName Spitter Leap Ability Key; // 0xcc(0x08)
	struct FName IsUsingWindupAttack; // 0xd4(0x08)
	float StopFireTime; // 0xdc(0x04)
	struct FVector Target; // 0xe0(0x0c)

	void CountReached_9C2E4D0F47BEE6F92D6F6BB22A37C713(enum class ES_ScavengerResult Result); // Function BTT_CombatSpitter_FireAtTarget.BTT_CombatSpitter_FireAtTarget_C.CountReached_9C2E4D0F47BEE6F92D6F6BB22A37C713 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTT_CombatSpitter_FireAtTarget.BTT_CombatSpitter_FireAtTarget_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatSpitter_FireAtTarget(int32_t EntryPoint); // Function BTT_CombatSpitter_FireAtTarget.BTT_CombatSpitter_FireAtTarget_C.ExecuteUbergraph_BTT_CombatSpitter_FireAtTarget // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

