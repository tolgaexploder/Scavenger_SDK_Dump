// BlueprintGeneratedClass BP_TRI_Bow_Compound.BP_TRI_Bow_Compound_C
// Size: 0x658 (Inherited: 0x650)
struct ABP_TRI_Bow_Compound_C : ABP_TRI_Bow_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x650(0x08)

	void ReceiveBeginPlay(); // Function BP_TRI_Bow_Compound.BP_TRI_Bow_Compound_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_TRI_Bow_Compound(int32_t EntryPoint); // Function BP_TRI_Bow_Compound.BP_TRI_Bow_Compound_C.ExecuteUbergraph_BP_TRI_Bow_Compound // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

