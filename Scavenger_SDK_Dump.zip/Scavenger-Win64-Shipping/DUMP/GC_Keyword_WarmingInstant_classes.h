// BlueprintGeneratedClass GC_Keyword_WarmingInstant.GC_Keyword_WarmingInstant_C
// Size: 0x470 (Inherited: 0x468)
struct AGC_Keyword_WarmingInstant_C : AGC_Keyword_HealDuration_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x468(0x08)

	void ReceiveBeginPlay(); // Function GC_Keyword_WarmingInstant.GC_Keyword_WarmingInstant_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GC_Keyword_WarmingInstant.GC_Keyword_WarmingInstant_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_GC_Keyword_WarmingInstant(int32_t EntryPoint); // Function GC_Keyword_WarmingInstant.GC_Keyword_WarmingInstant_C.ExecuteUbergraph_GC_Keyword_WarmingInstant // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

