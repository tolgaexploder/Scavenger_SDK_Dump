// BlueprintGeneratedClass GE_Uti_CheaperJumpSlideDodge.GE_Uti_CheaperJumpSlideDodge_C
// Size: 0x7c0 (Inherited: 0x7b8)
struct UGE_Uti_CheaperJumpSlideDodge_C : UGameplayEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7b8(0x08)

	void ExecuteUbergraph_GE_Uti_CheaperJumpSlideDodge(int32_t EntryPoint); // Function GE_Uti_CheaperJumpSlideDodge.GE_Uti_CheaperJumpSlideDodge_C.ExecuteUbergraph_GE_Uti_CheaperJumpSlideDodge // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

