// BlueprintGeneratedClass BP_WPN_Player_CompoundBow_Scatter.BP_WPN_Player_CompoundBow_Scatter_C
// Size: 0xdb0 (Inherited: 0xd98)
struct ABP_WPN_Player_CompoundBow_Scatter_C : ABP_WPN_Player_CompoundBow_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd98(0x08)
	struct USkeletalMeshComponent* SK_Arrow_Basic_02; // 0xda0(0x08)
	struct USkeletalMeshComponent* SK_Arrow_Basic_01; // 0xda8(0x08)

	void ReceiveBeginPlay(); // Function BP_WPN_Player_CompoundBow_Scatter.BP_WPN_Player_CompoundBow_Scatter_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_WPN_Player_CompoundBow_Scatter(int32_t EntryPoint); // Function BP_WPN_Player_CompoundBow_Scatter.BP_WPN_Player_CompoundBow_Scatter_C.ExecuteUbergraph_BP_WPN_Player_CompoundBow_Scatter // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

