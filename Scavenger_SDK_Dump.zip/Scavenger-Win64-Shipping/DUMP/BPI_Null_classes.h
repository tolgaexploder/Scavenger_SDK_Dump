// BlueprintGeneratedClass BPI_Null.BPI_Null_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_Null_C : UInterface {

	void KeeferGotAnOwie(struct AActor* Attkr); // Function BPI_Null.BPI_Null_C.KeeferGotAnOwie // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

