// BlueprintGeneratedClass BTT_CleanupAIPoints.BTT_CleanupAIPoints_C
// Size: 0xbc (Inherited: 0xa8)
struct UBTT_CleanupAIPoints_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	bool bClearActiveAIPoint; // 0xb0(0x01)
	bool bClearReservedAIPoints; // 0xb1(0x01)
	char UnknownData_B2[0x2]; // 0xb2(0x02)
	struct FName HasReservedAIPoint; // 0xb4(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_CleanupAIPoints.BTT_CleanupAIPoints_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CleanupAIPoints(int32_t EntryPoint); // Function BTT_CleanupAIPoints.BTT_CleanupAIPoints_C.ExecuteUbergraph_BTT_CleanupAIPoints // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

