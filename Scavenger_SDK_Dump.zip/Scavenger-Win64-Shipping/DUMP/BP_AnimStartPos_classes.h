// BlueprintGeneratedClass BP_AnimStartPos.BP_AnimStartPos_C
// Size: 0x44 (Inherited: 0x40)
struct UBP_AnimStartPos_C : US_AnimNotifyBase {
	float AnimStartPos; // 0x40(0x04)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function BP_AnimStartPos.BP_AnimStartPos_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xffff8009123b0000
};

