// BlueprintGeneratedClass BPI_AI_Sluka.BPI_AI_Sluka_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_AI_Sluka_C : UInterface {

	void GetBullRushVolume(struct USphereComponent* BullRushCollision); // Function BPI_AI_Sluka.BPI_AI_Sluka_C.GetBullRushVolume // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsSluka(bool IsSluka); // Function BPI_AI_Sluka.BPI_AI_Sluka_C.IsSluka // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

