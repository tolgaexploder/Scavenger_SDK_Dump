// BlueprintGeneratedClass BP_GameStateScavengers.BP_GameStateScavengers_C
// Size: 0xe8c (Inherited: 0xd30)
struct ABP_GameStateScavengers_C : AS_GameState {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd30(0x08)
	struct UBP_PlayerStatusEffects_C* m_playerStatusEffects; // 0xd38(0x08)
	struct US_HarvestManagerComponent* ScavengerHarvestManagerComponent; // 0xd40(0x08)
	struct UPostProcessComponent* StormPostProcessComponent; // 0xd48(0x08)
	struct US_DecalManagerComponent* ScavengerDecalManager; // 0xd50(0x08)
	bool bIsRoundEnding; // 0xd58(0x01)
	char UnknownData_D59[0x3]; // 0xd59(0x03)
	int32_t TotalLivingPlayers; // 0xd5c(0x04)
	float LastTimeOfDay; // 0xd60(0x04)
	float MatchEndTime; // 0xd64(0x04)
	enum class EMatchPhase matchPhase; // 0xd68(0x01)
	char UnknownData_D69[0x7]; // 0xd69(0x07)
	struct FMulticastInlineDelegate OnNewMatchPhase; // 0xd70(0x10)
	struct TArray<int32_t> ScrapScores; // 0xd80(0x10)
	struct FMulticastInlineDelegate OnStormCat1; // 0xd90(0x10)
	struct FMulticastInlineDelegate OnStormCat2; // 0xda0(0x10)
	struct FMulticastInlineDelegate OnStormCat3; // 0xdb0(0x10)
	struct FMulticastInlineDelegate OnStormCat4; // 0xdc0(0x10)
	struct FMulticastInlineDelegate OnStormCat5; // 0xdd0(0x10)
	struct FMulticastInlineDelegate FireWarmupObjectiveToast; // 0xde0(0x10)
	struct FMulticastInlineDelegate OnSupplyDrop; // 0xdf0(0x10)
	enum class ES_DropshipWaves DropshipWave; // 0xe00(0x01)
	char UnknownData_E01[0x7]; // 0xe01(0x07)
	struct FMulticastInlineDelegate OnNewDropshipWave; // 0xe08(0x10)
	struct TArray<struct AS_PlayerController*> TutorializedCold; // 0xe18(0x10)
	struct FMulticastInlineDelegate OnShuttleSealed; // 0xe28(0x10)
	struct FMulticastInlineDelegate OnShuttleEngaged; // 0xe38(0x10)
	struct FMulticastInlineDelegate OnShuttleOpened; // 0xe48(0x10)
	struct FMulticastInlineDelegate OnStormsInit; // 0xe58(0x10)
	int32_t AIPhase; // 0xe68(0x04)
	char UnknownData_E6C[0x4]; // 0xe6c(0x04)
	struct UDataTable* locTextData; // 0xe70(0x08)
	struct FName GlobalAlertLevel; // 0xe78(0x08)
	enum class ES_LocationDifficultyTier GlobalDifficulty; // 0xe80(0x01)
	char UnknownData_E81[0x3]; // 0xe81(0x03)
	struct FName Cleared; // 0xe84(0x08)

	void GetClearedText_BPI(struct FName locdText); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.GetClearedText_BPI // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetBannerData_BPI(struct FName Subtitle, enum class ES_LocationDifficultyTier Diff); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.GetBannerData_BPI // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetPlayerStatusEffects(struct UBP_PlayerStatusEffects_C* PlayerStatusEffects); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.GetPlayerStatusEffects // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetGradListCold_BPI(struct TArray<struct AS_PlayerController*> ColdGrads); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.GetGradListCold_BPI // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateAIPhaseData(int32_t newPhase); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.UpdateAIPhaseData // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetupAlphaPostProcess(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.SetupAlphaPostProcess // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnRep_DropshipWave(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnRep_DropshipWave // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnRep_OnStormCat5(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnRep_OnStormCat5 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	int32_t GetTeamScrapCollected_BP(int32_t TeamIndex); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.GetTeamScrapCollected_BP // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetTeamScrapScore(int32_t TeamIndex, int32_t ScrapScore); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.GetTeamScrapScore // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void AddTeamScrapScore(int32_t TeamIndex, int32_t ScrapValue); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.AddTeamScrapScore // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnRep_MatchPhase(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnRep_MatchPhase // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetTeamInLead(int32_t LeadTeamIndex, int32_t LeadTeamScore); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.GetTeamInLead // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xffff8009123b0000
	void UpdateDayNightAnnouncements(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.UpdateDayNightAnnouncements // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTick(float DeltaSeconds); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventStormCat1(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.EventStormCat1 // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventStormCat2(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.EventStormCat2 // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventStormCat3(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.EventStormCat3 // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventStormCat4(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.EventStormCat4 // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventStormCat5(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.EventStormCat5 // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventWarmupToast(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.EventWarmupToast // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventSupplyDrop(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.EventSupplyDrop // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void TutorializedCold_BPI(struct AS_PlayerController* TutorializedPlayer); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.TutorializedCold_BPI // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventShuttleSealed(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.EventShuttleSealed // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventShuttleEngaged(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.EventShuttleEngaged // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventShuttleOpened(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.EventShuttleOpened // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void InitStorm(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.InitStorm // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateAiPhase(int32_t Phase); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.UpdateAiPhase // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_GameStateScavengers(int32_t EntryPoint); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.ExecuteUbergraph_BP_GameStateScavengers // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
	void OnStormsInit__DelegateSignature(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnStormsInit__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnShuttleOpened__DelegateSignature(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnShuttleOpened__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnShuttleEngaged__DelegateSignature(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnShuttleEngaged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnShuttleSealed__DelegateSignature(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnShuttleSealed__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnNewDropshipWave__DelegateSignature(enum class ES_DropshipWaves Wave); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnNewDropshipWave__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnSupplyDrop__DelegateSignature(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnSupplyDrop__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void FireWarmupObjectiveToast__DelegateSignature(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.FireWarmupObjectiveToast__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnStormCat5__DelegateSignature(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnStormCat5__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnStormCat4__DelegateSignature(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnStormCat4__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnStormCat3__DelegateSignature(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnStormCat3__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnStormCat2__DelegateSignature(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnStormCat2__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnStormCat1__DelegateSignature(); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnStormCat1__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnNewMatchPhase__DelegateSignature(enum class EMatchPhase newPhase); // Function BP_GameStateScavengers.BP_GameStateScavengers_C.OnNewMatchPhase__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

