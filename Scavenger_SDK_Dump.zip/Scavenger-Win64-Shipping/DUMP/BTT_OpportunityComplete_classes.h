// BlueprintGeneratedClass BTT_OpportunityComplete.BTT_OpportunityComplete_C
// Size: 0xd0 (Inherited: 0xa8)
struct UBTT_OpportunityComplete_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* Scavenger AICharacter; // 0xb0(0x08)
	struct AS_AIController* Controller; // 0xb8(0x08)
	struct TScriptInterface<None> OverlordBPIVar; // 0xc0(0x10)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_OpportunityComplete.BTT_OpportunityComplete_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_OpportunityComplete(int32_t EntryPoint); // Function BTT_OpportunityComplete.BTT_OpportunityComplete_C.ExecuteUbergraph_BTT_OpportunityComplete // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

