// BlueprintGeneratedClass BP_Runner_Weak_Character.BP_Runner_Weak_Character_C
// Size: 0x270b (Inherited: 0x26ac)
struct ABP_Runner_Weak_Character_C : ABP_Runner_Character_C {
	char UnknownData_26AC[0x4]; // 0x26ac(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x26b0(0x08)
	struct UAudioComponent* Audio_1; // 0x26b8(0x08)
	struct UMaterialInstanceDynamic* DynamicBodyMaterial_1; // 0x26c0(0x08)
	struct FMulticastInlineDelegate MakeAggro_1; // 0x26c8(0x10)
	struct AAIController* AIController_1; // 0x26d8(0x08)
	struct UBlackboardComponent* BlackBoard_0_1; // 0x26e0(0x08)
	float LocalTime_1; // 0x26e8(0x04)
	float NewVar_0_0_1; // 0x26ec(0x04)
	bool isTerminal_1; // 0x26f0(0x01)
	char UnknownData_26F1[0x3]; // 0x26f1(0x03)
	float BlendWeight_1; // 0x26f4(0x04)
	bool Dead_1; // 0x26f8(0x01)
	bool Left_1; // 0x26f9(0x01)
	bool Right_1; // 0x26fa(0x01)
	bool Front_1; // 0x26fb(0x01)
	bool Back_1; // 0x26fc(0x01)
	char UnknownData_26FD[0x3]; // 0x26fd(0x03)
	struct FName BonesBelow_1; // 0x2700(0x08)
	enum class ES_AILocomotionState PrevLocomotionState_1; // 0x2708(0x01)
	enum class Sound_AITargetState PrevSoundTargetState_1; // 0x2709(0x01)
	enum class Sound_ExtraAITargetState PrevSoundExtraTargetState_1; // 0x270a(0x01)

	struct UAnimMontage* SelectAttackMontageVariant(struct TArray<struct UAnimMontage*> MontageVariations, enum class ES_WeaponMontageEvent attackEvent, enum class ES_TriggerType triggerType); // Function BP_Runner_Weak_Character.BP_Runner_Weak_Character_C.SelectAttackMontageVariant // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_Runner_Weak_Character.BP_Runner_Weak_Character_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTick(float DeltaSeconds); // Function BP_Runner_Weak_Character.BP_Runner_Weak_Character_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Runner_Weak_Character(int32_t EntryPoint); // Function BP_Runner_Weak_Character.BP_Runner_Weak_Character_C.ExecuteUbergraph_BP_Runner_Weak_Character // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
	void MakeAggro_0__DelegateSignature(struct AActor* Sender); // Function BP_Runner_Weak_Character.BP_Runner_Weak_Character_C.MakeAggro_0__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

