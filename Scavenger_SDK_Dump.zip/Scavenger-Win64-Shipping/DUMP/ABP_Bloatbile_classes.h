// AnimBlueprintGeneratedClass ABP_Bloatbile.ABP_Bloatbile_C
// Size: 0x1a30 (Inherited: 0x500)
struct UABP_Bloatbile_C : US_CharacterAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x500(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x508(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x538(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5; // 0x5b8(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x5e8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x610(0x28)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer; // 0x638(0xe8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // 0x720(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x750(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x7d0(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_2; // 0x800(0xb0)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x8b0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x8e0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x960(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x990(0xb0)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0xa40(0x48)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0xa88(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0xaa8(0x20)
	struct FAnimNode_SpringBone AnimGraphNode_SpringBone_10; // 0xac8(0x128)
	struct FAnimNode_SpringBone AnimGraphNode_SpringBone_9; // 0xbf0(0x128)
	struct FAnimNode_SpringBone AnimGraphNode_SpringBone_8; // 0xd18(0x128)
	struct FAnimNode_SpringBone AnimGraphNode_SpringBone_7; // 0xe40(0x128)
	struct FAnimNode_SpringBone AnimGraphNode_SpringBone_6; // 0xf68(0x128)
	struct FAnimNode_SpringBone AnimGraphNode_SpringBone_5; // 0x1090(0x128)
	struct FAnimNode_SpringBone AnimGraphNode_SpringBone_4; // 0x11b8(0x128)
	struct FAnimNode_SpringBone AnimGraphNode_SpringBone_3; // 0x12e0(0x128)
	struct FAnimNode_SpringBone AnimGraphNode_SpringBone_2; // 0x1408(0x128)
	struct FAnimNode_SpringBone AnimGraphNode_SpringBone; // 0x1530(0x128)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_4; // 0x1658(0xf0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_3; // 0x1748(0xf0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_2; // 0x1838(0xf0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone; // 0x1928(0xf0)
	bool IsExploding; // 0x1a18(0x01)
	bool IsFleeing; // 0x1a19(0x01)
	bool IsSearching; // 0x1a1a(0x01)
	char UnknownData_1A1B[0x5]; // 0x1a1b(0x05)
	struct AS_CharacterBase* ScavengerCharacterBase; // 0x1a20(0x08)
	float TimeInAir; // 0x1a28(0x04)
	float TmpAlphaControl; // 0x1a2c(0x04)

	void AnimGraph(struct FPoseLink AnimGraph); // Function ABP_Bloatbile.ABP_Bloatbile_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Bloatbile_AnimGraphNode_TransitionResult_D9AC2CAB43E2FBEADB74CC82394AA8DB(); // Function ABP_Bloatbile.ABP_Bloatbile_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Bloatbile_AnimGraphNode_TransitionResult_D9AC2CAB43E2FBEADB74CC82394AA8DB // (BlueprintEvent) // @ game+0xffff8009123b0000
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Bloatbile_AnimGraphNode_TransitionResult_7E0093284AAE9571F86E69A3B989BE91(); // Function ABP_Bloatbile.ABP_Bloatbile_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Bloatbile_AnimGraphNode_TransitionResult_7E0093284AAE9571F86E69A3B989BE91 // (BlueprintEvent) // @ game+0xffff8009123b0000
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Bloatbile.ABP_Bloatbile_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_ABP_Bloatbile(int32_t EntryPoint); // Function ABP_Bloatbile.ABP_Bloatbile_C.ExecuteUbergraph_ABP_Bloatbile // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

