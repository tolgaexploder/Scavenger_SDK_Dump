// BlueprintGeneratedClass BP_SpawnSlukaSpit.BP_SpawnSlukaSpit_C
// Size: 0x70 (Inherited: 0x40)
struct UBP_SpawnSlukaSpit_C : US_AnimNotifyBase {
	struct FTransform vomit location; // 0x40(0x30)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function BP_SpawnSlukaSpit.BP_SpawnSlukaSpit_C.Received_Notify // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xffff8009123b0000
};

