// BlueprintGeneratedClass BTT_CombatSpitterLeap.BTT_CombatSpitterLeap_C
// Size: 0xe4 (Inherited: 0xa8)
struct UBTT_CombatSpitterLeap_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb0(0x08)
	struct AS_AIController* ScavengerController; // 0xb8(0x08)
	float AttackAlpha; // 0xc0(0x04)
	struct FName IsAttackingWithMelee; // 0xc4(0x08)
	struct FName SpitterLeapAbilityKey; // 0xcc(0x08)
	struct FName IsPlayingAnimMontage; // 0xd4(0x08)
	struct FName IsLeaping; // 0xdc(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_CombatSpitterLeap.BTT_CombatSpitterLeap_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTT_CombatSpitterLeap.BTT_CombatSpitterLeap_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatSpitterLeap(int32_t EntryPoint); // Function BTT_CombatSpitterLeap.BTT_CombatSpitterLeap_C.ExecuteUbergraph_BTT_CombatSpitterLeap // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

