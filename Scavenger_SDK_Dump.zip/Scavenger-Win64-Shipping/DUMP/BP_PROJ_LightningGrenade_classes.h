// BlueprintGeneratedClass BP_PROJ_LightningGrenade.BP_PROJ_LightningGrenade_C
// Size: 0x5a8 (Inherited: 0x549)
struct ABP_PROJ_LightningGrenade_C : ABP_PROJ_Grenade_Base_C {
	char UnknownData_549[0x7]; // 0x549(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x550(0x08)
	float ShockRadius; // 0x558(0x04)
	struct FVector GrenadeLoc; // 0x55c(0x0c)
	float ClosestActorDist; // 0x568(0x04)
	char UnknownData_56C[0x4]; // 0x56c(0x04)
	struct AActor* ClosestActor; // 0x570(0x08)
	struct TArray<struct AActor*> HitActors; // 0x578(0x10)
	int32_t ChainCount; // 0x588(0x04)
	int32_t ChainMax; // 0x58c(0x04)
	struct TArray<struct AActor*> ActorsToCheck; // 0x590(0x10)
	struct AActor* OriginActor; // 0x5a0(0x08)

	void PulseLightning(); // Function BP_PROJ_LightningGrenade.BP_PROJ_LightningGrenade_C.PulseLightning // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetEnemyActorsInRange(struct AActor* CenterActor, struct TArray<struct AActor*> EnemiesInRange); // Function BP_PROJ_LightningGrenade.BP_PROJ_LightningGrenade_C.GetEnemyActorsInRange // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ChainToNearestEnemy(); // Function BP_PROJ_LightningGrenade.BP_PROJ_LightningGrenade_C.ChainToNearestEnemy // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsEnemy(struct AActor* ActorToCheck, bool IsEnemy); // Function BP_PROJ_LightningGrenade.BP_PROJ_LightningGrenade_C.IsEnemy // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ApplyImpulseAndDamage(struct AActor* OriginActor); // Function BP_PROJ_LightningGrenade.BP_PROJ_LightningGrenade_C.ApplyImpulseAndDamage // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Get Closest Actor(struct AActor* OriginActor, bool NewTargetFound); // Function BP_PROJ_LightningGrenade.BP_PROJ_LightningGrenade_C.Get Closest Actor // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void LightningBlast(); // Function BP_PROJ_LightningGrenade.BP_PROJ_LightningGrenade_C.LightningBlast // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void BP_OnExplode(struct UPhysicalMaterial* hitMaterial); // Function BP_PROJ_LightningGrenade.BP_PROJ_LightningGrenade_C.BP_OnExplode // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_PROJ_LightningGrenade.BP_PROJ_LightningGrenade_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveDestroyed(); // Function BP_PROJ_LightningGrenade.BP_PROJ_LightningGrenade_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnImpact(struct FHitResult ImpactResult); // Function BP_PROJ_LightningGrenade.BP_PROJ_LightningGrenade_C.OnImpact // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_PROJ_LightningGrenade(int32_t EntryPoint); // Function BP_PROJ_LightningGrenade.BP_PROJ_LightningGrenade_C.ExecuteUbergraph_BP_PROJ_LightningGrenade // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

