// BlueprintGeneratedClass BP_TRI_CompoundBow_Base.BP_TRI_CompoundBow_Base_C
// Size: 0x668 (Inherited: 0x660)
struct ABP_TRI_CompoundBow_Base_C : ABP_TRI_CompoundBow_Scatter_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x660(0x08)

	void ReceiveTick(float DeltaSeconds); // Function BP_TRI_CompoundBow_Base.BP_TRI_CompoundBow_Base_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_TRI_CompoundBow_Base(int32_t EntryPoint); // Function BP_TRI_CompoundBow_Base.BP_TRI_CompoundBow_Base_C.ExecuteUbergraph_BP_TRI_CompoundBow_Base // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

