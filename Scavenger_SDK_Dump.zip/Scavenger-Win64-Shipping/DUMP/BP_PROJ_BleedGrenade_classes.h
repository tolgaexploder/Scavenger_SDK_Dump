// BlueprintGeneratedClass BP_PROJ_BleedGrenade.BP_PROJ_BleedGrenade_C
// Size: 0x58c (Inherited: 0x549)
struct ABP_PROJ_BleedGrenade_C : ABP_PROJ_Grenade_Base_C {
	char UnknownData_549[0x7]; // 0x549(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x550(0x08)
	float ArmingTime; // 0x558(0x04)
	float TriggerRadius; // 0x55c(0x04)
	float ProximityFrequency; // 0x560(0x04)
	float ExplosionDelay; // 0x564(0x04)
	struct AS_CharacterBase* OwnerCharacter; // 0x568(0x08)
	bool PendingExplosion; // 0x570(0x01)
	char UnknownData_571[0x7]; // 0x571(0x07)
	struct FTimerHandle ProximityCheckTimer; // 0x578(0x08)
	float BeepFrequency; // 0x580(0x04)
	enum class ECollisionEnabled CollisionEnabledSetting_2; // 0x584(0x01)
	char UnknownData_585[0x3]; // 0x585(0x03)
	int32_t DynamicOpportunityPointID; // 0x588(0x04)

	void ReceiveBeginPlay(); // Function BP_PROJ_BleedGrenade.BP_PROJ_BleedGrenade_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckForProximity(); // Function BP_PROJ_BleedGrenade.BP_PROJ_BleedGrenade_C.CheckForProximity // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Beep(); // Function BP_PROJ_BleedGrenade.BP_PROJ_BleedGrenade_C.Beep // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveDestroyed(); // Function BP_PROJ_BleedGrenade.BP_PROJ_BleedGrenade_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void CleanupOppPoint(); // Function BP_PROJ_BleedGrenade.BP_PROJ_BleedGrenade_C.CleanupOppPoint // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_PROJ_BleedGrenade(int32_t EntryPoint); // Function BP_PROJ_BleedGrenade.BP_PROJ_BleedGrenade_C.ExecuteUbergraph_BP_PROJ_BleedGrenade // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

