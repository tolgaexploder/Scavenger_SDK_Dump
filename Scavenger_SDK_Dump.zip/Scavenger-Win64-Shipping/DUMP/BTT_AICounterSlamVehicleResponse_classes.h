// BlueprintGeneratedClass BTT_AICounterSlamVehicleResponse.BTT_AICounterSlamVehicleResponse_C
// Size: 0xe0 (Inherited: 0xa8)
struct UBTT_AICounterSlamVehicleResponse_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AIController* AIController; // 0xb0(0x08)
	struct AS_AICharacter* aiCharacter; // 0xb8(0x08)
	struct FName IsPlayingAnimMontage; // 0xc0(0x08)
	struct FName TryDodgeDanger; // 0xc8(0x08)
	struct FName DangerLocationPositive; // 0xd0(0x08)
	struct FName GrenadeLandedNearby; // 0xd8(0x08)

	void Interrupted_499CA48243CA34ED4DF79ABA776940E1(); // Function BTT_AICounterSlamVehicleResponse.BTT_AICounterSlamVehicleResponse_C.Interrupted_499CA48243CA34ED4DF79ABA776940E1 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Completed_499CA48243CA34ED4DF79ABA776940E1(); // Function BTT_AICounterSlamVehicleResponse.BTT_AICounterSlamVehicleResponse_C.Completed_499CA48243CA34ED4DF79ABA776940E1 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_AICounterSlamVehicleResponse.BTT_AICounterSlamVehicleResponse_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_AICounterSlamVehicleResponse(int32_t EntryPoint); // Function BTT_AICounterSlamVehicleResponse.BTT_AICounterSlamVehicleResponse_C.ExecuteUbergraph_BTT_AICounterSlamVehicleResponse // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

