// BlueprintGeneratedClass BTD_OpportunityReached.BTD_OpportunityReached_C
// Size: 0xa0 (Inherited: 0xa0)
struct UBTD_OpportunityReached_C : UBTDecorator_BlueprintBase {

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_OpportunityReached.BTD_OpportunityReached_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

