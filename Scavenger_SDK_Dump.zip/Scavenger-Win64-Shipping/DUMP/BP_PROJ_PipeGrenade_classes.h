// BlueprintGeneratedClass BP_PROJ_PipeGrenade.BP_PROJ_PipeGrenade_C
// Size: 0x55a (Inherited: 0x549)
struct ABP_PROJ_PipeGrenade_C : ABP_PROJ_Grenade_Base_C {
	char UnknownData_549[0x7]; // 0x549(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x550(0x08)
	enum class ECollisionChannel NewVar_0_1; // 0x558(0x01)
	enum class ECollisionEnabled CollisionEnabledSetting_1; // 0x559(0x01)

	void OnFinish_8A4A8BBC45824232632F40833C1D0230(); // Function BP_PROJ_PipeGrenade.BP_PROJ_PipeGrenade_C.OnFinish_8A4A8BBC45824232632F40833C1D0230 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnImpact(struct FHitResult ImpactResult); // Function BP_PROJ_PipeGrenade.BP_PROJ_PipeGrenade_C.OnImpact // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_PROJ_PipeGrenade.BP_PROJ_PipeGrenade_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void BP_OnExplode(struct UPhysicalMaterial* hitMaterial); // Function BP_PROJ_PipeGrenade.BP_PROJ_PipeGrenade_C.BP_OnExplode // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_PROJ_PipeGrenade(int32_t EntryPoint); // Function BP_PROJ_PipeGrenade.BP_PROJ_PipeGrenade_C.ExecuteUbergraph_BP_PROJ_PipeGrenade // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

