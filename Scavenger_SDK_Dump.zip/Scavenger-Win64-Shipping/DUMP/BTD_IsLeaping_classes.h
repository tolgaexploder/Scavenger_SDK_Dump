// BlueprintGeneratedClass BTD_IsLeaping.BTD_IsLeaping_C
// Size: 0xb0 (Inherited: 0xa0)
struct UBTD_IsLeaping_C : UBTDecorator_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa0(0x08)
	struct FName IsPlayingAnimMontage; // 0xa8(0x08)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_IsLeaping.BTD_IsLeaping_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecutionFinish(struct AActor* OwnerActor, enum class EBTNodeResult NodeResult); // Function BTD_IsLeaping.BTD_IsLeaping_C.ReceiveExecutionFinish // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTD_IsLeaping(int32_t EntryPoint); // Function BTD_IsLeaping.BTD_IsLeaping_C.ExecuteUbergraph_BTD_IsLeaping // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

