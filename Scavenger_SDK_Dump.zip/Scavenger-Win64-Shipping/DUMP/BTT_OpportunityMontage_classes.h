// BlueprintGeneratedClass BTT_OpportunityMontage.BTT_OpportunityMontage_C
// Size: 0xd4 (Inherited: 0xa8)
struct UBTT_OpportunityMontage_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xb0(0x08)
	struct AS_AIController* CachedAIController; // 0xb8(0x08)
	float PathfindingAcceptanceRadius; // 0xc0(0x04)
	bool StopFire; // 0xc4(0x01)
	char UnknownData_C5[0x3]; // 0xc5(0x03)
	float MoveStartTime; // 0xc8(0x04)
	struct FName IsPlayingAnimMontage; // 0xcc(0x08)

	void Interrupted_C1FA404F4FDABA153E17AF841E45FBF5(); // Function BTT_OpportunityMontage.BTT_OpportunityMontage_C.Interrupted_C1FA404F4FDABA153E17AF841E45FBF5 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Completed_C1FA404F4FDABA153E17AF841E45FBF5(); // Function BTT_OpportunityMontage.BTT_OpportunityMontage_C.Completed_C1FA404F4FDABA153E17AF841E45FBF5 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_OpportunityMontage.BTT_OpportunityMontage_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_OpportunityMontage(int32_t EntryPoint); // Function BTT_OpportunityMontage.BTT_OpportunityMontage_C.ExecuteUbergraph_BTT_OpportunityMontage // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

