// BlueprintGeneratedClass GE_HelpingHand.GE_HelpingHand_C
// Size: 0x7c0 (Inherited: 0x7b8)
struct UGE_HelpingHand_C : UGameplayEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7b8(0x08)

	void ExecuteUbergraph_GE_HelpingHand(int32_t EntryPoint); // Function GE_HelpingHand.GE_HelpingHand_C.ExecuteUbergraph_GE_HelpingHand // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

