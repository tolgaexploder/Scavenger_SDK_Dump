// BlueprintGeneratedClass BPI_ReviveInfo.BPI_ReviveInfo_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_ReviveInfo_C : UInterface {

	void Get Revive Target(struct AActor* Revive Target); // Function BPI_ReviveInfo.BPI_ReviveInfo_C.Get Revive Target // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Get Revive Initiator(struct AActor* Revive Initiator); // Function BPI_ReviveInfo.BPI_ReviveInfo_C.Get Revive Initiator // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

