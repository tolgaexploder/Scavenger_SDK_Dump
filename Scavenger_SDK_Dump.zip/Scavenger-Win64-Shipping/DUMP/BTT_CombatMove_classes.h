// BlueprintGeneratedClass BTT_CombatMove.BTT_CombatMove_C
// Size: 0x164 (Inherited: 0xa8)
struct UBTT_CombatMove_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xb0(0x08)
	struct AS_AIController* CachedAIController; // 0xb8(0x08)
	struct US_CharacterMovementComponent* CachedMovementComponent; // 0xc0(0x08)
	struct UAITask_MoveTo* AsyncTaskInstance; // 0xc8(0x08)
	float MaxDistanceForADSShooting; // 0xd0(0x04)
	float LongMoveDistance; // 0xd4(0x04)
	float CurrentPathLength; // 0xd8(0x04)
	float DontMoveIfCloseToDestination; // 0xdc(0x04)
	float MoveAcceptanceRadius; // 0xe0(0x04)
	float CombinedMoveAcceptanceRadius; // 0xe4(0x04)
	float CombatMoveSpeedScalar; // 0xe8(0x04)
	float LongRangeMoveSpeedScalar; // 0xec(0x04)
	float MinFireTime; // 0xf0(0x04)
	float MaxFireTime; // 0xf4(0x04)
	float FireDuration; // 0xf8(0x04)
	float MoveStartTime; // 0xfc(0x04)
	float VisibilityThresholdToFire; // 0x100(0x04)
	float stopFireAge; // 0x104(0x04)
	bool SprintMove; // 0x108(0x01)
	bool MovingTowardTarget; // 0x109(0x01)
	bool IsLongRangeMove; // 0x10a(0x01)
	bool UseADS; // 0x10b(0x01)
	bool HasStringWeapon; // 0x10c(0x01)
	bool ClearFocus; // 0x10d(0x01)
	bool ForceFocusTarget; // 0x10e(0x01)
	char UnknownData_10F[0x1]; // 0x10f(0x01)
	struct FName CombatIsLongRangeMove; // 0x110(0x08)
	struct FName IsInCover; // 0x118(0x08)
	struct FName WantToSearch; // 0x120(0x08)
	struct FName WantToInvestigate; // 0x128(0x08)
	int32_t FireCount; // 0x130(0x04)
	struct FName FoundIdealPosition; // 0x134(0x08)
	char UnknownData_13C[0x4]; // 0x13c(0x04)
	struct US_AIAudioEventType* Move To Audio; // 0x140(0x08)
	struct US_AIAudioEventType* Cover Audio; // 0x148(0x08)
	struct FVector GoalLocation; // 0x150(0x0c)
	struct FName StringWeapon; // 0x15c(0x08)

	void ScaleSpeedByDistance(float MinScalerClamp, float MaxScalerClamp); // Function BTT_CombatMove.BTT_CombatMove_C.ScaleSpeedByDistance // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsTargetInRange(bool TargetInRange?); // Function BTT_CombatMove.BTT_CombatMove_C.IsTargetInRange // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ShouldHoldPosition(bool ShouldHold?); // Function BTT_CombatMove.BTT_CombatMove_C.ShouldHoldPosition // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckForCover(); // Function BTT_CombatMove.BTT_CombatMove_C.CheckForCover // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void AllowFire(bool bAllow, bool bSuccess); // Function BTT_CombatMove.BTT_CombatMove_C.AllowFire // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetFocalPointToTarget(); // Function BTT_CombatMove.BTT_CombatMove_C.SetFocalPointToTarget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CountReached_2B9AF1E34AE0C780BCBA34898CDD7C27(enum class ES_ScavengerResult Result); // Function BTT_CombatMove.BTT_CombatMove_C.CountReached_2B9AF1E34AE0C780BCBA34898CDD7C27 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnMoveFinished_0AB9A32A47A4AF54629CB3BF5E670152(struct AAIController* AIController, enum class EPathFollowingResult PathFollowingResult, enum class ENavPathEvent NavPathEvent, enum class EPathFollowingRequestResult PathFollowingRequestResult); // Function BTT_CombatMove.BTT_CombatMove_C.OnMoveFinished_0AB9A32A47A4AF54629CB3BF5E670152 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnAlreadyAtTargetLocation(); // Function BTT_CombatMove.BTT_CombatMove_C.OnAlreadyAtTargetLocation // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_CombatMove.BTT_CombatMove_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatMove(int32_t EntryPoint); // Function BTT_CombatMove.BTT_CombatMove_C.ExecuteUbergraph_BTT_CombatMove // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

