// BlueprintGeneratedClass BTS_CombatRunner.BTS_CombatRunner_C
// Size: 0x130 (Inherited: 0x98)
struct UBTS_CombatRunner_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xa0(0x08)
	struct AS_AIController* CachedAIController; // 0xa8(0x08)
	struct FName IsCloseRange; // 0xb0(0x08)
	struct FName IsMediumRange; // 0xb8(0x08)
	struct FName IsLongRange; // 0xc0(0x08)
	struct FName HoldPosition; // 0xc8(0x08)
	struct FName HealthIsLow; // 0xd0(0x08)
	struct FName RunnerExplodes; // 0xd8(0x08)
	struct FName IsCheap; // 0xe0(0x08)
	struct FName IsInCover; // 0xe8(0x08)
	struct FName CanLeap; // 0xf0(0x08)
	struct FName LeapWillSucceed; // 0xf8(0x08)
	struct FName Leaped; // 0x100(0x08)
	float DeltaSeconds; // 0x108(0x04)
	float CurrentTime; // 0x10c(0x04)
	float LowHealthThreshold; // 0x110(0x04)
	float LeapTimer; // 0x114(0x04)
	float LeapCooldownDelay; // 0x118(0x04)
	float LeapInitialDelay; // 0x11c(0x04)
	bool LowHealth; // 0x120(0x01)
	char UnknownData_121[0x3]; // 0x121(0x03)
	float TimeInCloseRange; // 0x124(0x04)
	float TargetCloseRange; // 0x128(0x04)
	float ExplodeTimeTrigger; // 0x12c(0x04)

	void CanRunnerLeapSucceed(bool Result); // Function BTS_CombatRunner.BTS_CombatRunner_C.CanRunnerLeapSucceed // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckTargetCloseRange(bool TargetInCloseRange); // Function BTS_CombatRunner.BTS_CombatRunner_C.CheckTargetCloseRange // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateLeapTimer(bool RestartCooldown); // Function BTS_CombatRunner.BTS_CombatRunner_C.UpdateLeapTimer // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateHealthIsLow(); // Function BTS_CombatRunner.BTS_CombatRunner_C.UpdateHealthIsLow // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_CombatRunner.BTS_CombatRunner_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTS_CombatRunner(int32_t EntryPoint); // Function BTS_CombatRunner.BTS_CombatRunner_C.ExecuteUbergraph_BTS_CombatRunner // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

