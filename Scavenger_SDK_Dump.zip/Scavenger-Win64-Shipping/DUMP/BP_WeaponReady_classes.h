// BlueprintGeneratedClass BP_WeaponReady.BP_WeaponReady_C
// Size: 0x41 (Inherited: 0x40)
struct UBP_WeaponReady_C : US_AnimNotifyBase {
	enum class ES_WeaponSlot DesiredSlot; // 0x40(0x01)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function BP_WeaponReady.BP_WeaponReady_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xffff8009123b0000
};

