// BlueprintGeneratedClass GC_Keyword_HealDuration.GC_Keyword_HealDuration_C
// Size: 0x468 (Inherited: 0x460)
struct AGC_Keyword_HealDuration_C : AGC_StatusEffect_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)

	void ReceiveBeginPlay(); // Function GC_Keyword_HealDuration.GC_Keyword_HealDuration_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GC_Keyword_HealDuration.GC_Keyword_HealDuration_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_GC_Keyword_HealDuration(int32_t EntryPoint); // Function GC_Keyword_HealDuration.GC_Keyword_HealDuration_C.ExecuteUbergraph_GC_Keyword_HealDuration // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

