// BlueprintGeneratedClass GC_Ability_Overshield.GC_Ability_Overshield_C
// Size: 0x46c (Inherited: 0x460)
struct AGC_Ability_Overshield_C : AGC_StatusEffect_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)
	int32_t Shell ID 2; // 0x468(0x04)

	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GC_Ability_Overshield.GC_Ability_Overshield_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_GC_Ability_Overshield(int32_t EntryPoint); // Function GC_Ability_Overshield.GC_Ability_Overshield_C.ExecuteUbergraph_GC_Ability_Overshield // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

