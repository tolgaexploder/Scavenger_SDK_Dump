// BlueprintGeneratedClass AIC_Spitter.AIC_Spitter_C
// Size: 0x8e0 (Inherited: 0x8cb)
struct AAIC_Spitter_C : AAIC_Scourge_BP_C {
	char UnknownData_8CB[0x5]; // 0x8cb(0x05)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x8d0(0x08)
	struct FName DEBUG_ForceRoarBBKey; // 0x8d8(0x08)

	void RegisterDebugBBKeys(); // Function AIC_Spitter.AIC_Spitter_C.RegisterDebugBBKeys // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function AIC_Spitter.AIC_Spitter_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_AIC_Spitter(int32_t EntryPoint); // Function AIC_Spitter.AIC_Spitter_C.ExecuteUbergraph_AIC_Spitter // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

