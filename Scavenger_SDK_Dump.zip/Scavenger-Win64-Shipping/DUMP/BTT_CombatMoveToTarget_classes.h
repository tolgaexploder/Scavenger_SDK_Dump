// BlueprintGeneratedClass BTT_CombatMoveToTarget.BTT_CombatMoveToTarget_C
// Size: 0xe9 (Inherited: 0xa8)
struct UBTT_CombatMoveToTarget_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct FName PursueTarget; // 0xb0(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xb8(0x08)
	struct AS_AIController* CachedAIController; // 0xc0(0x08)
	float PathfindingAcceptanceRadius; // 0xc8(0x04)
	bool StopFire; // 0xcc(0x01)
	char UnknownData_CD[0x3]; // 0xcd(0x03)
	float MoveStartTime; // 0xd0(0x04)
	char UnknownData_D4[0x4]; // 0xd4(0x04)
	struct US_AIAudioEventType* Move To Audio; // 0xd8(0x08)
	bool StalkingSpeed; // 0xe0(0x01)
	bool ContinuousGoalTracking; // 0xe1(0x01)
	char UnknownData_E2[0x2]; // 0xe2(0x02)
	float CombinedPathfindingAcceptanceRadius; // 0xe4(0x04)
	bool ForceFocusTarget; // 0xe8(0x01)

	void OnMoveFinished_2AAB8F0C47E15CD9BEA0489B4E3752DC(struct AAIController* AIController, enum class EPathFollowingResult PathFollowingResult, enum class ENavPathEvent NavPathEvent, enum class EPathFollowingRequestResult PathFollowingRequestResult); // Function BTT_CombatMoveToTarget.BTT_CombatMoveToTarget_C.OnMoveFinished_2AAB8F0C47E15CD9BEA0489B4E3752DC // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_CombatMoveToTarget.BTT_CombatMoveToTarget_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnAlreadyAtTargetLocation(); // Function BTT_CombatMoveToTarget.BTT_CombatMoveToTarget_C.OnAlreadyAtTargetLocation // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatMoveToTarget(int32_t EntryPoint); // Function BTT_CombatMoveToTarget.BTT_CombatMoveToTarget_C.ExecuteUbergraph_BTT_CombatMoveToTarget // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

