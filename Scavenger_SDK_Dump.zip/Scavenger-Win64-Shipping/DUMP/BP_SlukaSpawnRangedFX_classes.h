// BlueprintGeneratedClass BP_SlukaSpawnRangedFX.BP_SlukaSpawnRangedFX_C
// Size: 0x40 (Inherited: 0x40)
struct UBP_SlukaSpawnRangedFX_C : US_AnimNotifyBase {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function BP_SlukaSpawnRangedFX.BP_SlukaSpawnRangedFX_C.Received_Notify // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xffff8009123b0000
};

