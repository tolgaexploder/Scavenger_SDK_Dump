// BlueprintGeneratedClass BP_PROJ_CryoGrenade.BP_PROJ_CryoGrenade_C
// Size: 0x5a8 (Inherited: 0x549)
struct ABP_PROJ_CryoGrenade_C : ABP_PROJ_Grenade_Base_C {
	char UnknownData_549[0x7]; // 0x549(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x550(0x08)
	struct UBillboardComponent* Billboard; // 0x558(0x08)
	struct UStaticMeshComponent* Sphere; // 0x560(0x08)
	struct US_GameplayEffectVolumeComponent* S_GameplayEffectVolume; // 0x568(0x08)
	float Decal_Controls_Hologram_Speed_EB543DD5474814A79AF3BEBD08057A0B; // 0x570(0x04)
	float Decal_Controls_Ice_Growth_EB543DD5474814A79AF3BEBD08057A0B; // 0x574(0x04)
	enum class ETimelineDirection Decal_Controls__Direction_EB543DD5474814A79AF3BEBD08057A0B; // 0x578(0x01)
	char UnknownData_579[0x7]; // 0x579(0x07)
	struct UTimelineComponent* Decal Controls; // 0x580(0x08)
	enum class ECollisionEnabled CollisionEnabledSetting_1; // 0x588(0x01)
	char UnknownData_589[0x7]; // 0x589(0x07)
	struct UMaterialInstanceDynamic* Decal Material; // 0x590(0x08)
	float Grenade Radius; // 0x598(0x04)
	char UnknownData_59C[0x4]; // 0x59c(0x04)
	struct AS_CharacterBase* OwnerCharacter; // 0x5a0(0x08)

	void OnRep_NewVar_2(); // Function BP_PROJ_CryoGrenade.BP_PROJ_CryoGrenade_C.OnRep_NewVar_2 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UserConstructionScript(); // Function BP_PROJ_CryoGrenade.BP_PROJ_CryoGrenade_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Decal Controls__FinishedFunc(); // Function BP_PROJ_CryoGrenade.BP_PROJ_CryoGrenade_C.Decal Controls__FinishedFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void Decal Controls__UpdateFunc(); // Function BP_PROJ_CryoGrenade.BP_PROJ_CryoGrenade_C.Decal Controls__UpdateFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void OnComponentBeginOverlap_Event_1(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function BP_PROJ_CryoGrenade.BP_PROJ_CryoGrenade_C.OnComponentBeginOverlap_Event_1 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnComponentEndOverlap_Event_1(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_PROJ_CryoGrenade.BP_PROJ_CryoGrenade_C.OnComponentEndOverlap_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void BP_OnExplode(struct UPhysicalMaterial* hitMaterial); // Function BP_PROJ_CryoGrenade.BP_PROJ_CryoGrenade_C.BP_OnExplode // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_PROJ_CryoGrenade.BP_PROJ_CryoGrenade_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnImpact(struct FHitResult ImpactResult); // Function BP_PROJ_CryoGrenade.BP_PROJ_CryoGrenade_C.OnImpact // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_PROJ_CryoGrenade(int32_t EntryPoint); // Function BP_PROJ_CryoGrenade.BP_PROJ_CryoGrenade_C.ExecuteUbergraph_BP_PROJ_CryoGrenade // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

