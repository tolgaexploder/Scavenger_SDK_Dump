// BlueprintGeneratedClass GC_Keyword_StaminaDuration.GC_Keyword_StaminaDuration_C
// Size: 0x468 (Inherited: 0x460)
struct AGC_Keyword_StaminaDuration_C : AGC_StatusEffect_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)

	void ReceiveBeginPlay(); // Function GC_Keyword_StaminaDuration.GC_Keyword_StaminaDuration_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_GC_Keyword_StaminaDuration(int32_t EntryPoint); // Function GC_Keyword_StaminaDuration.GC_Keyword_StaminaDuration_C.ExecuteUbergraph_GC_Keyword_StaminaDuration // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

