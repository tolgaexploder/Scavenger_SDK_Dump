// BlueprintGeneratedClass GC_Keyword_Sprint.GC_Keyword_Sprint_C
// Size: 0x470 (Inherited: 0x460)
struct AGC_Keyword_Sprint_C : AGC_StatusEffect_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)
	struct UParticleSystemComponent* PS_Sprint_DashLines; // 0x468(0x08)

	void ReceiveBeginPlay(); // Function GC_Keyword_Sprint.GC_Keyword_Sprint_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GC_Keyword_Sprint.GC_Keyword_Sprint_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_GC_Keyword_Sprint(int32_t EntryPoint); // Function GC_Keyword_Sprint.GC_Keyword_Sprint_C.ExecuteUbergraph_GC_Keyword_Sprint // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

