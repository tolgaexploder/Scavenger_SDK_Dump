// BlueprintGeneratedClass BP_FlyCameraPerformanceTestPawn.BP_FlyCameraPerformanceTestPawn_C
// Size: 0x378 (Inherited: 0x378)
struct ABP_FlyCameraPerformanceTestPawn_C : AS_FlyCameraPerformanceTestPawn {

	void InitialiseTests(); // Function BP_FlyCameraPerformanceTestPawn.BP_FlyCameraPerformanceTestPawn_C.InitialiseTests // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

