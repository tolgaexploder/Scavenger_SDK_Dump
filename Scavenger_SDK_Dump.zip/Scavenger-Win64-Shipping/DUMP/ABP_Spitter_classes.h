// AnimBlueprintGeneratedClass ABP_Spitter.ABP_Spitter_C
// Size: 0x1202 (Inherited: 0x500)
struct UABP_Spitter_C : US_CharacterAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x500(0x08)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x508(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x528(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7; // 0x548(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_9; // 0x5c8(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9; // 0x5f8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8; // 0x620(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7; // 0x648(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6; // 0x670(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5; // 0x698(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // 0x6c0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // 0x6e8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x710(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x738(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6; // 0x760(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8; // 0x7e0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5; // 0x810(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7; // 0x890(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4; // 0x8c0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6; // 0x940(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x970(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5; // 0x9f0(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer; // 0xa20(0xe8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // 0xb08(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0xb38(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0xbb8(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_2; // 0xbe8(0xb0)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0xc98(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0xcc8(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0xd48(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0xd78(0xb0)
	char UnknownData_E28[0x8]; // 0xe28(0x08)
	struct FAnimNode_Fabrik AnimGraphNode_Fabrik_2; // 0xe30(0x190)
	struct FAnimNode_Fabrik AnimGraphNode_Fabrik; // 0xfc0(0x190)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x1150(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x1180(0x48)
	struct AS_CharacterBase* ScavengerCharacterBase; // 0x11c8(0x08)
	struct FTransform B_Jaw_T; // 0x11d0(0x30)
	bool IsLeaping; // 0x1200(0x01)
	bool IsLanding; // 0x1201(0x01)

	void AnimGraph(struct FPoseLink AnimGraph); // Function ABP_Spitter.ABP_Spitter_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Spitter_AnimGraphNode_TransitionResult_D9AC2CAB43E2FBEADB74CC82394AA8DB(); // Function ABP_Spitter.ABP_Spitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Spitter_AnimGraphNode_TransitionResult_D9AC2CAB43E2FBEADB74CC82394AA8DB // (BlueprintEvent) // @ game+0xffff8009123b0000
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Spitter_AnimGraphNode_TransitionResult_7E0093284AAE9571F86E69A3B989BE91(); // Function ABP_Spitter.ABP_Spitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Spitter_AnimGraphNode_TransitionResult_7E0093284AAE9571F86E69A3B989BE91 // (BlueprintEvent) // @ game+0xffff8009123b0000
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Spitter_AnimGraphNode_TransitionResult_0891D0094263B672BD33B19E6225D4A2(); // Function ABP_Spitter.ABP_Spitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Spitter_AnimGraphNode_TransitionResult_0891D0094263B672BD33B19E6225D4A2 // (BlueprintEvent) // @ game+0xffff8009123b0000
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Spitter.ABP_Spitter_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_ABP_Spitter(int32_t EntryPoint); // Function ABP_Spitter.ABP_Spitter_C.ExecuteUbergraph_ABP_Spitter // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

