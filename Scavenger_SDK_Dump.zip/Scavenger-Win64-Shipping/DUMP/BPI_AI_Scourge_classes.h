// BlueprintGeneratedClass BPI_AI_Scourge.BPI_AI_Scourge_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_AI_Scourge_C : UInterface {

	void SpawnGroundMiasma(struct FVector Location); // Function BPI_AI_Scourge.BPI_AI_Scourge_C.SpawnGroundMiasma // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SpawnGroundGoop(struct FVector Location); // Function BPI_AI_Scourge.BPI_AI_Scourge_C.SpawnGroundGoop // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

