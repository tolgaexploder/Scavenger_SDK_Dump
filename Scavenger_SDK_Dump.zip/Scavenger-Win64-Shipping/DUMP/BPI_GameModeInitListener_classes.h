// BlueprintGeneratedClass BPI_GameModeInitListener.BPI_GameModeInitListener_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_GameModeInitListener_C : UInterface {

	void OnGameModeInit(); // Function BPI_GameModeInitListener.BPI_GameModeInitListener_C.OnGameModeInit // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

