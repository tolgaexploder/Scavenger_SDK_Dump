// BlueprintGeneratedClass GC_Ability_StunTrap.GC_Ability_StunTrap_C
// Size: 0x488 (Inherited: 0x460)
struct AGC_Ability_StunTrap_C : AGC_StatusEffect_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)
	struct USceneCaptureComponent2D* SceneCaptureComponent2D; // 0x468(0x08)
	float FlashBirghtness_Brightness_D2B49B1D47316FD5BC2094B06388D2D6; // 0x470(0x04)
	enum class ETimelineDirection FlashBirghtness__Direction_D2B49B1D47316FD5BC2094B06388D2D6; // 0x474(0x01)
	char UnknownData_475[0x3]; // 0x475(0x03)
	struct UTimelineComponent* FlashBirghtness; // 0x478(0x08)
	struct UMaterialInstanceDynamic* PP_MID; // 0x480(0x08)

	void FlashBirghtness__FinishedFunc(); // Function GC_Ability_StunTrap.GC_Ability_StunTrap_C.FlashBirghtness__FinishedFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void FlashBirghtness__UpdateFunc(); // Function GC_Ability_StunTrap.GC_Ability_StunTrap_C.FlashBirghtness__UpdateFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Function GC_Ability_StunTrap.GC_Ability_StunTrap_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function GC_Ability_StunTrap.GC_Ability_StunTrap_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_GC_Ability_StunTrap(int32_t EntryPoint); // Function GC_Ability_StunTrap.GC_Ability_StunTrap_C.ExecuteUbergraph_GC_Ability_StunTrap // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

