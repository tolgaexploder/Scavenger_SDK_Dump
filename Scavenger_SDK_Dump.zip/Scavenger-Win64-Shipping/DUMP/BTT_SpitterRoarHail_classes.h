// BlueprintGeneratedClass BTT_SpitterRoarHail.BTT_SpitterRoarHail_C
// Size: 0xdc (Inherited: 0xa8)
struct UBTT_SpitterRoarHail_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb0(0x08)
	struct AS_AIController* ScavengerAIController; // 0xb8(0x08)
	struct FName IsPlayingAnimMontage; // 0xc0(0x08)
	struct AS_CharacterBase* CurrentTarget; // 0xc8(0x08)
	float MinDotToTarget; // 0xd0(0x04)
	float MinRangeToTarget; // 0xd4(0x04)
	float MaxRangeToTarget; // 0xd8(0x04)

	void Interrupted_BCD94B8A463D81B1AA7DCE9080EFD95D(); // Function BTT_SpitterRoarHail.BTT_SpitterRoarHail_C.Interrupted_BCD94B8A463D81B1AA7DCE9080EFD95D // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Completed_BCD94B8A463D81B1AA7DCE9080EFD95D(); // Function BTT_SpitterRoarHail.BTT_SpitterRoarHail_C.Completed_BCD94B8A463D81B1AA7DCE9080EFD95D // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_SpitterRoarHail.BTT_SpitterRoarHail_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_SpitterRoarHail(int32_t EntryPoint); // Function BTT_SpitterRoarHail.BTT_SpitterRoarHail_C.ExecuteUbergraph_BTT_SpitterRoarHail // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

