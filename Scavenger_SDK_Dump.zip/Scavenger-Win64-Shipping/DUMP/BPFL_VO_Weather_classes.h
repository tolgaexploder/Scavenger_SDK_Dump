// BlueprintGeneratedClass BPFL_VO_Weather.BPFL_VO_Weather_C
// Size: 0x28 (Inherited: 0x28)
struct UBPFL_VO_Weather_C : UBlueprintFunctionLibrary {

	void VO_Weather_Storm_Warning(struct AS_CharacterBase* Speaker, struct UObject* __WorldContext); // Function BPFL_VO_Weather.BPFL_VO_Weather_C.VO_Weather_Storm_Warning // (Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void VO_Weather_Storm_Exit(struct AS_CharacterBase* Speaker, struct UObject* __WorldContext); // Function BPFL_VO_Weather.BPFL_VO_Weather_C.VO_Weather_Storm_Exit // (Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void VO_Weather_Storm_Enter(struct AS_CharacterBase* Speaker, struct UObject* __WorldContext); // Function BPFL_VO_Weather.BPFL_VO_Weather_C.VO_Weather_Storm_Enter // (Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void VO_Weather_StormCategory(int32_t StormCAT, struct UObject* __WorldContext); // Function BPFL_VO_Weather.BPFL_VO_Weather_C.VO_Weather_StormCategory // (Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

