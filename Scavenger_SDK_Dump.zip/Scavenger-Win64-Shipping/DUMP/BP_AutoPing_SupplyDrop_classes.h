// BlueprintGeneratedClass BP_AutoPing_SupplyDrop.BP_AutoPing_SupplyDrop_C
// Size: 0x209 (Inherited: 0x209)
struct UBP_AutoPing_SupplyDrop_C : UBP_AutoPing_C {

	bool EvaluatePing_BP(struct AS_PlayerController* PlayerController); // Function BP_AutoPing_SupplyDrop.BP_AutoPing_SupplyDrop_C.EvaluatePing_BP // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

