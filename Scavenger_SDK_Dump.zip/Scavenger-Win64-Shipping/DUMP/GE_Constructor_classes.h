// BlueprintGeneratedClass GE_Constructor.GE_Constructor_C
// Size: 0x7c0 (Inherited: 0x7b8)
struct UGE_Constructor_C : UGameplayEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7b8(0x08)

	void ExecuteUbergraph_GE_Constructor(int32_t EntryPoint); // Function GE_Constructor.GE_Constructor_C.ExecuteUbergraph_GE_Constructor // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

