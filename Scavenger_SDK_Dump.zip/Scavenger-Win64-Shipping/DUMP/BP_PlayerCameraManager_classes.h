// BlueprintGeneratedClass BP_PlayerCameraManager.BP_PlayerCameraManager_C
// Size: 0x2e40 (Inherited: 0x2e40)
struct ABP_PlayerCameraManager_C : AS_PlayerCameraManager {

	void BlueprintVewTargetChanged(struct AActor* NewCameraTarget, struct AActor* OldCameraTarget); // Function BP_PlayerCameraManager.BP_PlayerCameraManager_C.BlueprintVewTargetChanged // (BlueprintCosmetic|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

