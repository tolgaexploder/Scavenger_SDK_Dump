// BlueprintGeneratedClass BTT_CombatStrafe.BTT_CombatStrafe_C
// Size: 0x11d (Inherited: 0xa8)
struct UBTT_CombatStrafe_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xb0(0x08)
	struct AS_AIController* CachedAIController; // 0xb8(0x08)
	struct US_CharacterMovementComponent* CachedMovementComponent; // 0xc0(0x08)
	struct UAITask_MoveTo* AsyncTaskInstance; // 0xc8(0x08)
	float MaxDistanceForADSShooting; // 0xd0(0x04)
	float LongRangeMoveDistance; // 0xd4(0x04)
	float DistanceToActiveAIPoint; // 0xd8(0x04)
	float DontMoveIfCloseToDestination; // 0xdc(0x04)
	float MoveAcceptanceRadius; // 0xe0(0x04)
	float CombatMoveSpeedScalar; // 0xe4(0x04)
	float StrafeMoveSpeedScalar; // 0xe8(0x04)
	float MinFireTime; // 0xec(0x04)
	float MaxFireTime; // 0xf0(0x04)
	float FireDuration; // 0xf4(0x04)
	float MoveStartTime; // 0xf8(0x04)
	float stopFireAge; // 0xfc(0x04)
	float CurrentPathLength; // 0x100(0x04)
	bool FireMove; // 0x104(0x01)
	bool UseADS; // 0x105(0x01)
	char UnknownData_106[0x2]; // 0x106(0x02)
	struct FName CombatIsLongRangeMove; // 0x108(0x08)
	struct FName IsInCover; // 0x110(0x08)
	int32_t FireCount; // 0x118(0x04)
	bool HeadOnlyFocus; // 0x11c(0x01)

	void IsTargetInRange(bool TargetInRange?); // Function BTT_CombatStrafe.BTT_CombatStrafe_C.IsTargetInRange // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ShouldHoldPosition(bool ShouldHold?); // Function BTT_CombatStrafe.BTT_CombatStrafe_C.ShouldHoldPosition // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CheckForCover(); // Function BTT_CombatStrafe.BTT_CombatStrafe_C.CheckForCover // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void AllowFire(bool bAllow, bool bSuccess); // Function BTT_CombatStrafe.BTT_CombatStrafe_C.AllowFire // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetFocalPointToTarget(bool Success); // Function BTT_CombatStrafe.BTT_CombatStrafe_C.SetFocalPointToTarget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void CountReached_A38FDDA44650AC113A7AAF93FA7F1189(enum class ES_ScavengerResult Result); // Function BTT_CombatStrafe.BTT_CombatStrafe_C.CountReached_A38FDDA44650AC113A7AAF93FA7F1189 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnMoveFinished_A9440E0645D90924D0CCF0AFDDE66128(struct AAIController* AIController, enum class EPathFollowingResult PathFollowingResult, enum class ENavPathEvent NavPathEvent, enum class EPathFollowingRequestResult PathFollowingRequestResult); // Function BTT_CombatStrafe.BTT_CombatStrafe_C.OnMoveFinished_A9440E0645D90924D0CCF0AFDDE66128 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_CombatStrafe.BTT_CombatStrafe_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnAlreadyAtTargetLocation(); // Function BTT_CombatStrafe.BTT_CombatStrafe_C.OnAlreadyAtTargetLocation // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatStrafe(int32_t EntryPoint); // Function BTT_CombatStrafe.BTT_CombatStrafe_C.ExecuteUbergraph_BTT_CombatStrafe // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

