// BlueprintGeneratedClass BTD_CanPatrol.BTD_CanPatrol_C
// Size: 0xa0 (Inherited: 0xa0)
struct UBTD_CanPatrol_C : UBTDecorator_BlueprintBase {

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_CanPatrol.BTD_CanPatrol_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

