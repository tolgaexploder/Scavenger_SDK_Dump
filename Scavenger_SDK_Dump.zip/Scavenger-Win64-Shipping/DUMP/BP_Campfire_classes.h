// BlueprintGeneratedClass BP_Campfire.BP_Campfire_C
// Size: 0x2e8 (Inherited: 0x288)
struct ABP_Campfire_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x288(0x08)
	struct UAkComponent* AkSound; // 0x290(0x08)
	struct UStaticMeshComponent* outlander_fire; // 0x298(0x08)
	struct UAudioComponent* Fire_Sparks01_Cue; // 0x2a0(0x08)
	struct US_StatChangeVolumeComponent* S_StatChangeVolume; // 0x2a8(0x08)
	struct UPointLightComponent* PointLight; // 0x2b0(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x2b8(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x2c0(0x08)
	bool FireActive; // 0x2c8(0x01)
	char UnknownData_2C9[0x3]; // 0x2c9(0x03)
	float CookTimeMax; // 0x2cc(0x04)
	struct US_InventoryComponent* CachedInventory; // 0x2d0(0x08)
	struct UAkAudioEvent* Fire Audio Event; // 0x2d8(0x08)
	struct US_EquipmentComponent* Cached Equipment; // 0x2e0(0x08)

	void CookFood(struct APlayerController* PlayerController, float InteractionPercentage); // Function BP_Campfire.BP_Campfire_C.CookFood // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventInteractLightFire(struct AS_PlayerController* PlayerController, struct AActor* InteractableActor, struct UPrimitiveComponent* InteractableComponent, int32_t InteractableIndex, float InteractionPercentage); // Function BP_Campfire.BP_Campfire_C.EventInteractLightFire // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventFireState(); // Function BP_Campfire.BP_Campfire_C.EventFireState // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventRegisterInteractLightFire(); // Function BP_Campfire.BP_Campfire_C.EventRegisterInteractLightFire // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventRegisterCookMeat(); // Function BP_Campfire.BP_Campfire_C.EventRegisterCookMeat // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventInteractCookMeat(struct AS_PlayerController* PlayerController, struct AActor* InteractableActor, struct UPrimitiveComponent* InteractableComponent, int32_t InteractableIndex, float InteractionPercentage); // Function BP_Campfire.BP_Campfire_C.EventInteractCookMeat // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventActiveTimer(); // Function BP_Campfire.BP_Campfire_C.EventActiveTimer // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void EventToggleFire(); // Function BP_Campfire.BP_Campfire_C.EventToggleFire // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_Campfire.BP_Campfire_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Campfire(int32_t EntryPoint); // Function BP_Campfire.BP_Campfire_C.ExecuteUbergraph_BP_Campfire // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

