// BlueprintGeneratedClass BPI_AI_General.BPI_AI_General_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_AI_General_C : UInterface {

	void GetLastHitByAbilityActor(struct AActor* ActorPerformingTheHIt); // Function BPI_AI_General.BPI_AI_General_C.GetLastHitByAbilityActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetLastHitByAbilityActor(struct AActor* ActorPerformingLastHit, struct AActor* ActorHit); // Function BPI_AI_General.BPI_AI_General_C.SetLastHitByAbilityActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateGrenadeCount(int32_t NewCount); // Function BPI_AI_General.BPI_AI_General_C.UpdateGrenadeCount // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetGrenadeCount(int32_t GrenadeInvCount); // Function BPI_AI_General.BPI_AI_General_C.GetGrenadeCount // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsFollowerCompanion(bool IsFollowerCompanion); // Function BPI_AI_General.BPI_AI_General_C.IsFollowerCompanion // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GrenadeCooldownTime(float GrenadeCooldownTime); // Function BPI_AI_General.BPI_AI_General_C.GrenadeCooldownTime // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SetAIIgnored(); // Function BPI_AI_General.BPI_AI_General_C.SetAIIgnored // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void RevealAI(); // Function BPI_AI_General.BPI_AI_General_C.RevealAI // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

