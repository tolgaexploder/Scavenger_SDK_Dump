// BlueprintGeneratedClass BP_Sluka_Spit_Projectile.BP_Sluka_Spit_Projectile_C
// Size: 0x371 (Inherited: 0x288)
struct ABP_Sluka_Spit_Projectile_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x288(0x08)
	struct USplineComponent* Spline; // 0x290(0x08)
	struct UArrowComponent* Arrow; // 0x298(0x08)
	struct UParticleSystemComponent* PS_Sluka_Spit_Projectile; // 0x2a0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x2a8(0x08)
	float Lerp_to_Position_Lerp_E9B772244123F630BBFBCE89621BB5A6; // 0x2b0(0x04)
	enum class ETimelineDirection Lerp_to_Position__Direction_E9B772244123F630BBFBCE89621BB5A6; // 0x2b4(0x01)
	char UnknownData_2B5[0x3]; // 0x2b5(0x03)
	struct UTimelineComponent* Lerp to Position; // 0x2b8(0x08)
	struct FTransform Mouth; // 0x2c0(0x30)
	struct FTransform vomit; // 0x2f0(0x30)
	struct FTransform Imapct  Location; // 0x320(0x30)
	struct FVector Target; // 0x350(0x0c)
	float Alpha; // 0x35c(0x04)
	enum class EPhysicalSurface Surface Type; // 0x360(0x01)
	char UnknownData_361[0x3]; // 0x361(0x03)
	struct FVector Impact Point; // 0x364(0x0c)
	bool More work; // 0x370(0x01)

	void OnRep_Imapct  Location(); // Function BP_Sluka_Spit_Projectile.BP_Sluka_Spit_Projectile_C.OnRep_Imapct  Location // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Lerp to Position__FinishedFunc(); // Function BP_Sluka_Spit_Projectile.BP_Sluka_Spit_Projectile_C.Lerp to Position__FinishedFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void Lerp to Position__UpdateFunc(); // Function BP_Sluka_Spit_Projectile.BP_Sluka_Spit_Projectile_C.Lerp to Position__UpdateFunc // (BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_Sluka_Spit_Projectile.BP_Sluka_Spit_Projectile_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Sluka_Spit_Projectile(int32_t EntryPoint); // Function BP_Sluka_Spit_Projectile.BP_Sluka_Spit_Projectile_C.ExecuteUbergraph_BP_Sluka_Spit_Projectile // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

