// BlueprintGeneratedClass BTT_ReturnTRUE.BTT_ReturnTRUE_C
// Size: 0xb0 (Inherited: 0xa8)
struct UBTT_ReturnTRUE_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)

	void ReceiveExecute(struct AActor* OwnerActor); // Function BTT_ReturnTRUE.BTT_ReturnTRUE_C.ReceiveExecute // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_ReturnTRUE(int32_t EntryPoint); // Function BTT_ReturnTRUE.BTT_ReturnTRUE_C.ExecuteUbergraph_BTT_ReturnTRUE // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

