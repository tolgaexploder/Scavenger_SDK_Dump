// BlueprintGeneratedClass BTD_Flee_Events.BTD_Flee_Events_C
// Size: 0xac (Inherited: 0xa0)
struct UBTD_Flee_Events_C : UBTDecorator_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa0(0x08)
	float Minimum Leap Velocity; // 0xa8(0x04)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_Flee_Events.BTD_Flee_Events_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecutionFinish(struct AActor* OwnerActor, enum class EBTNodeResult NodeResult); // Function BTD_Flee_Events.BTD_Flee_Events_C.ReceiveExecutionFinish // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecutionStart(struct AActor* OwnerActor); // Function BTD_Flee_Events.BTD_Flee_Events_C.ReceiveExecutionStart // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTD_Flee_Events(int32_t EntryPoint); // Function BTD_Flee_Events.BTD_Flee_Events_C.ExecuteUbergraph_BTD_Flee_Events // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

