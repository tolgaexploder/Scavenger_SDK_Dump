// BlueprintGeneratedClass BP_VehicleInterface.BP_VehicleInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_VehicleInterface_C : UInterface {

	void OnDriverRevived(); // Function BP_VehicleInterface.BP_VehicleInterface_C.OnDriverRevived // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnDriverDown(); // Function BP_VehicleInterface.BP_VehicleInterface_C.OnDriverDown // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void GetVehicleDataForAnim(float YawSpeed, float throttle, float Desired Heading, float Model Rel Desired Heading, float strafe, float boost, float Hover Force Multiplier, bool Vehicle Active, bool Dirver Seat Occupied); // Function BP_VehicleInterface.BP_VehicleInterface_C.GetVehicleDataForAnim // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

