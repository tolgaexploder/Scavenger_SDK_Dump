// BlueprintGeneratedClass BTT_CombatBloatbileExplode.BTT_CombatBloatbileExplode_C
// Size: 0xe8 (Inherited: 0xa8)
struct UBTT_CombatBloatbileExplode_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb0(0x08)
	struct AS_AIController* ScavengerController; // 0xb8(0x08)
	struct AActor* CurrentTarget; // 0xc0(0x08)
	float AttackAlpha; // 0xc8(0x04)
	struct FName IsPlayingAnimMontage; // 0xcc(0x08)
	int32_t Shards; // 0xd4(0x04)
	struct FName StartingExplodeSelf; // 0xd8(0x08)
	struct US_DamageTypeExplosive* ExplosiveType; // 0xe0(0x08)

	void ActivateSelfDestruct(); // Function BTT_CombatBloatbileExplode.BTT_CombatBloatbileExplode_C.ActivateSelfDestruct // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void PostSelfDestruct(bool Interrupted); // Function BTT_CombatBloatbileExplode.BTT_CombatBloatbileExplode_C.PostSelfDestruct // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTT_CombatBloatbileExplode.BTT_CombatBloatbileExplode_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatBloatbileExplode(int32_t EntryPoint); // Function BTT_CombatBloatbileExplode.BTT_CombatBloatbileExplode_C.ExecuteUbergraph_BTT_CombatBloatbileExplode // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

