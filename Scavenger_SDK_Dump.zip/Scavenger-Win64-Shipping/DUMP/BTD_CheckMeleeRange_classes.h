// BlueprintGeneratedClass BTD_CheckMeleeRange.BTD_CheckMeleeRange_C
// Size: 0xbc (Inherited: 0xa0)
struct UBTD_CheckMeleeRange_C : UBTDecorator_BlueprintBase {
	struct AS_AIController* ScavengerAIController; // 0xa0(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xa8(0x08)
	enum class ES_TriggerType MeleeTriggerType; // 0xb0(0x01)
	bool CheckSingleFloorHeight; // 0xb1(0x01)
	char UnknownData_B2[0x2]; // 0xb2(0x02)
	float VehicleAddition; // 0xb4(0x04)
	float ForwardOriginOffsets; // 0xb8(0x04)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_CheckMeleeRange.BTD_CheckMeleeRange_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

