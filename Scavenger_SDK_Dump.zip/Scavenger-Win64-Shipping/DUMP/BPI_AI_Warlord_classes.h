// BlueprintGeneratedClass BPI_AI_Warlord.BPI_AI_Warlord_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_AI_Warlord_C : UInterface {

	void IsRallyable(bool IsRallyable); // Function BPI_AI_Warlord.BPI_AI_Warlord_C.IsRallyable // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsWarlord(); // Function BPI_AI_Warlord.BPI_AI_Warlord_C.IsWarlord // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

