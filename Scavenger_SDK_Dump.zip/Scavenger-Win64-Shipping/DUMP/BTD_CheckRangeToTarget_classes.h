// BlueprintGeneratedClass BTD_CheckRangeToTarget.BTD_CheckRangeToTarget_C
// Size: 0xc1 (Inherited: 0xa0)
struct UBTD_CheckRangeToTarget_C : UBTDecorator_BlueprintBase {
	struct AS_AIController* ScavengerAIController; // 0xa0(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xa8(0x08)
	float TargetRange; // 0xb0(0x04)
	bool CheckSingleFloorHeight; // 0xb4(0x01)
	char UnknownData_B5[0x3]; // 0xb5(0x03)
	float VehicleAddition; // 0xb8(0x04)
	float ForwardOriginOffsets; // 0xbc(0x04)
	bool AddVehicleDistance; // 0xc0(0x01)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_CheckRangeToTarget.BTD_CheckRangeToTarget_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

