// BlueprintGeneratedClass BP_VOL_BaitGrenade.BP_VOL_BaitGrenade_C
// Size: 0x2a8 (Inherited: 0x290)
struct ABP_VOL_BaitGrenade_C : AS_GameplayEffectVolume {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct ABP_Spawner_BaitGrenade_C* spawner; // 0x298(0x08)
	int32_t SpawnCount; // 0x2a0(0x04)
	int32_t MaxSpawns; // 0x2a4(0x04)

	void SpawnDurationTimer(); // Function BP_VOL_BaitGrenade.BP_VOL_BaitGrenade_C.SpawnDurationTimer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_VOL_BaitGrenade.BP_VOL_BaitGrenade_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveActorBeginOverlap(struct AActor* OtherActor); // Function BP_VOL_BaitGrenade.BP_VOL_BaitGrenade_C.ReceiveActorBeginOverlap // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTick(float DeltaSeconds); // Function BP_VOL_BaitGrenade.BP_VOL_BaitGrenade_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveDestroyed(); // Function BP_VOL_BaitGrenade.BP_VOL_BaitGrenade_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_VOL_BaitGrenade(int32_t EntryPoint); // Function BP_VOL_BaitGrenade.BP_VOL_BaitGrenade_C.ExecuteUbergraph_BP_VOL_BaitGrenade // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

