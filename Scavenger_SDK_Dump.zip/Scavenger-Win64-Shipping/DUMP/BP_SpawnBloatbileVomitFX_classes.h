// BlueprintGeneratedClass BP_SpawnBloatbileVomitFX.BP_SpawnBloatbileVomitFX_C
// Size: 0x40 (Inherited: 0x40)
struct UBP_SpawnBloatbileVomitFX_C : US_AnimNotifyBase {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function BP_SpawnBloatbileVomitFX.BP_SpawnBloatbileVomitFX_C.Received_Notify // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xffff8009123b0000
};

