// BlueprintGeneratedClass BTT_ClearMontage.BTT_ClearMontage_C
// Size: 0xc9 (Inherited: 0xa8)
struct UBTT_ClearMontage_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xb0(0x08)
	struct AS_AIController* CachedAIController; // 0xb8(0x08)
	struct FName IsPlayingAnimMontage; // 0xc0(0x08)
	bool ReturnTrue; // 0xc8(0x01)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_ClearMontage.BTT_ClearMontage_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_ClearMontage(int32_t EntryPoint); // Function BTT_ClearMontage.BTT_ClearMontage_C.ExecuteUbergraph_BTT_ClearMontage // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

