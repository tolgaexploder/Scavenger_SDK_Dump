// Class ArchVisCharacter.ArchVisCharacter
// Size: 0x590 (Inherited: 0x530)
struct AArchVisCharacter : ACharacter {
	struct FString LookUpAxisName; // 0x528(0x10)
	struct FString LookUpAtRateAxisName; // 0x538(0x10)
	struct FString TurnAxisName; // 0x548(0x10)
	struct FString TurnAtRateAxisName; // 0x558(0x10)
	struct FString MoveForwardAxisName; // 0x568(0x10)
	struct FString MoveRightAxisName; // 0x578(0x10)
	float MouseSensitivityScale_Pitch; // 0x588(0x04)
	float MouseSensitivityScale_Yaw; // 0x58c(0x04)
};

// Class ArchVisCharacter.ArchVisCharMovementComponent
// Size: 0xb50 (Inherited: 0xb00)
struct UArchVisCharMovementComponent : UCharacterMovementComponent {
	struct FRotator RotationalAcceleration; // 0xb00(0x0c)
	struct FRotator RotationalDeceleration; // 0xb0c(0x0c)
	struct FRotator MaxRotationalVelocity; // 0xb18(0x0c)
	float MinPitch; // 0xb24(0x04)
	float MaxPitch; // 0xb28(0x04)
	float WalkingFriction; // 0xb2c(0x04)
	float WalkingSpeed; // 0xb30(0x04)
	float WalkingAcceleration; // 0xb34(0x04)
	char UnknownData_B38[0x18]; // 0xb38(0x18)
};

