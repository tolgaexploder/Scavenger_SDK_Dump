// BlueprintGeneratedClass BTT_CombatMeleeAttack.BTT_CombatMeleeAttack_C
// Size: 0xfc (Inherited: 0xa8)
struct UBTT_CombatMeleeAttack_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb0(0x08)
	struct AS_AIController* ScavengerController; // 0xb8(0x08)
	struct AActor* CurrentTarget; // 0xc0(0x08)
	float AttackAlpha; // 0xc8(0x04)
	float MaxAngleToTarget; // 0xcc(0x04)
	struct FName IsAttackingWithMelee; // 0xd0(0x08)
	int32_t notifyAfterCount; // 0xd8(0x04)
	char UnknownData_DC[0x4]; // 0xdc(0x04)
	struct US_AIAudioEventType* Attack Audio; // 0xe0(0x08)
	bool ForceOffhandAttack; // 0xe8(0x01)
	char UnknownData_E9[0x3]; // 0xe9(0x03)
	float OffhandChance; // 0xec(0x04)
	enum class ES_TriggerType triggerType; // 0xf0(0x01)
	char UnknownData_F1[0x3]; // 0xf1(0x03)
	struct FName MeleeShove; // 0xf4(0x08)

	void CountReached_8C8A21F0403EC4BA62B81E97A81AF4DF(enum class ES_ScavengerResult Result); // Function BTT_CombatMeleeAttack.BTT_CombatMeleeAttack_C.CountReached_8C8A21F0403EC4BA62B81E97A81AF4DF // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTT_CombatMeleeAttack.BTT_CombatMeleeAttack_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatMeleeAttack(int32_t EntryPoint); // Function BTT_CombatMeleeAttack.BTT_CombatMeleeAttack_C.ExecuteUbergraph_BTT_CombatMeleeAttack // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

