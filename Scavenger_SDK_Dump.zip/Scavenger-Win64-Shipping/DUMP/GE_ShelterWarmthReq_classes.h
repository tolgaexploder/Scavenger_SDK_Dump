// BlueprintGeneratedClass GE_ShelterWarmthReq.GE_ShelterWarmthReq_C
// Size: 0x28 (Inherited: 0x28)
struct UGE_ShelterWarmthReq_C : UGameplayEffectCustomApplicationRequirement {

	bool CanApplyGameplayEffect(struct UGameplayEffect* GameplayEffect, struct FGameplayEffectSpec Spec, struct UAbilitySystemComponent* ASC); // Function GE_ShelterWarmthReq.GE_ShelterWarmthReq_C.CanApplyGameplayEffect // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xffff8009123b0000
};

