// BlueprintGeneratedClass BP_WPN_Player_CompoundBow_Base.BP_WPN_Player_CompoundBow_Base_C
// Size: 0xd98 (Inherited: 0xd90)
struct ABP_WPN_Player_CompoundBow_Base_C : ABP_WPN_Bow_Wood_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd90(0x08)

	void ReceiveBeginPlay(); // Function BP_WPN_Player_CompoundBow_Base.BP_WPN_Player_CompoundBow_Base_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTick(float DeltaSeconds); // Function BP_WPN_Player_CompoundBow_Base.BP_WPN_Player_CompoundBow_Base_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_WPN_Player_CompoundBow_Base(int32_t EntryPoint); // Function BP_WPN_Player_CompoundBow_Base.BP_WPN_Player_CompoundBow_Base_C.ExecuteUbergraph_BP_WPN_Player_CompoundBow_Base // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

