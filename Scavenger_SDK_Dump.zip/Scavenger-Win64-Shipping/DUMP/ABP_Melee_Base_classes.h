// AnimBlueprintGeneratedClass ABP_Melee_Base.ABP_Melee_Base_C
// Size: 0x6a0 (Inherited: 0x370)
struct UABP_Melee_Base_C : US_WeaponAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x370(0x08)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend; // 0x378(0xc0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x438(0x158)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x590(0x48)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x5d8(0x30)
	struct AS_CharacterBase* ScavengerCharacterBase; // 0x608(0x08)
	struct US_HumanAnimInstance* ABP_Human_Ref; // 0x610(0x08)
	enum class ES_WeaponClass WeaponEnum; // 0x618(0x01)
	bool Ready; // 0x619(0x01)
	bool AttachedStow; // 0x61a(0x01)
	char UnknownData_61B[0x5]; // 0x61b(0x05)
	struct AS_WeaponBase* WeaponInstance; // 0x620(0x08)
	bool WeaponReadied; // 0x628(0x01)
	char UnknownData_629[0x3]; // 0x629(0x03)
	struct FName WeaponLocationName; // 0x62c(0x08)
	bool IsAI; // 0x634(0x01)
	char UnknownData_635[0xb]; // 0x635(0x0b)
	struct FTransform WeaponLocation; // 0x640(0x30)
	struct FTransform WeaponStowLocation; // 0x670(0x30)

	void AnimGraph(struct FPoseLink AnimGraph); // Function ABP_Melee_Base.ABP_Melee_Base_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Melee_Base.ABP_Melee_Base_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_ABP_Melee_Base(int32_t EntryPoint); // Function ABP_Melee_Base.ABP_Melee_Base_C.ExecuteUbergraph_ABP_Melee_Base // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

