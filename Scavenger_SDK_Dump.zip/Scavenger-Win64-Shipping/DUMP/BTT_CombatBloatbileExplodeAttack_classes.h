// BlueprintGeneratedClass BTT_CombatBloatbileExplodeAttack.BTT_CombatBloatbileExplodeAttack_C
// Size: 0xf0 (Inherited: 0xa8)
struct UBTT_CombatBloatbileExplodeAttack_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb0(0x08)
	struct AS_AIController* ScavengerController; // 0xb8(0x08)
	struct AActor* CurrentTarget; // 0xc0(0x08)
	float AttackAlpha; // 0xc8(0x04)
	struct FName IsPlayingAnimMontage; // 0xcc(0x08)
	struct FVector FartLocation; // 0xd4(0x0c)
	float FartOffset; // 0xe0(0x04)
	char UnknownData_E4[0x4]; // 0xe4(0x04)
	struct US_AIAudioEventType* FlatulenceAudio; // 0xe8(0x08)

	void Interrupted_650F97AD4EDC8D8ABE4F3AAD2B8D15CF(); // Function BTT_CombatBloatbileExplodeAttack.BTT_CombatBloatbileExplodeAttack_C.Interrupted_650F97AD4EDC8D8ABE4F3AAD2B8D15CF // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Completed_650F97AD4EDC8D8ABE4F3AAD2B8D15CF(); // Function BTT_CombatBloatbileExplodeAttack.BTT_CombatBloatbileExplodeAttack_C.Completed_650F97AD4EDC8D8ABE4F3AAD2B8D15CF // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SpawnGroundMiasma(struct FVector Location); // Function BTT_CombatBloatbileExplodeAttack.BTT_CombatBloatbileExplodeAttack_C.SpawnGroundMiasma // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTT_CombatBloatbileExplodeAttack.BTT_CombatBloatbileExplodeAttack_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void SpawnGroundGoop(struct FVector Location); // Function BTT_CombatBloatbileExplodeAttack.BTT_CombatBloatbileExplodeAttack_C.SpawnGroundGoop // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatBloatbileExplodeAttack(int32_t EntryPoint); // Function BTT_CombatBloatbileExplodeAttack.BTT_CombatBloatbileExplodeAttack_C.ExecuteUbergraph_BTT_CombatBloatbileExplodeAttack // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

