// BlueprintGeneratedClass BP_WPN_Outlander_CoachGunJackal_Base.BP_WPN_Outlander_CoachGunJackal_Base_C
// Size: 0xd68 (Inherited: 0xd61)
struct ABP_WPN_Outlander_CoachGunJackal_Base_C : ABP_WPN_WeaponBase_C {
	char UnknownData_D61[0x3]; // 0xd61(0x03)
	int32_t AmmoCount; // 0xd64(0x04)

	void UserConstructionScript(); // Function BP_WPN_Outlander_CoachGunJackal_Base.BP_WPN_Outlander_CoachGunJackal_Base_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

