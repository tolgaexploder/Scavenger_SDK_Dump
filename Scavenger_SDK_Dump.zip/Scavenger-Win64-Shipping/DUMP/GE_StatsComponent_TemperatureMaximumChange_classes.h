// BlueprintGeneratedClass GE_StatsComponent_TemperatureMaximumChange.GE_StatsComponent_TemperatureMaximumChange_C
// Size: 0x7c0 (Inherited: 0x7b8)
struct UGE_StatsComponent_TemperatureMaximumChange_C : UGameplayEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7b8(0x08)

	void ExecuteUbergraph_GE_StatsComponent_TemperatureMaximumChange(int32_t EntryPoint); // Function GE_StatsComponent_TemperatureMaximumChange.GE_StatsComponent_TemperatureMaximumChange_C.ExecuteUbergraph_GE_StatsComponent_TemperatureMaximumChange // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

