// BlueprintGeneratedClass BTT_PatrolMoveTo.BTT_PatrolMoveTo_C
// Size: 0xec (Inherited: 0xa8)
struct UBTT_PatrolMoveTo_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xb0(0x08)
	struct AS_AIController* CachedAIController; // 0xb8(0x08)
	float MoveAcceptanceRadius; // 0xc0(0x04)
	float MoveStartTime; // 0xc4(0x04)
	bool PlayIdleMontage; // 0xc8(0x01)
	char UnknownData_C9[0x7]; // 0xc9(0x07)
	struct US_AIAudioEventType* Patrol Idle Audio; // 0xd0(0x08)
	struct US_AIAudioEventType* Patrol Move Audio; // 0xd8(0x08)
	struct FName IsPlayingAnimMontage; // 0xe0(0x08)
	float PatrolIdleRate; // 0xe8(0x04)

	void OnMoveFinished_FE88432F4C94B417B0F5D2AFC37F9732(struct AAIController* AIController, enum class EPathFollowingResult PathFollowingResult, enum class ENavPathEvent NavPathEvent, enum class EPathFollowingRequestResult PathFollowingRequestResult); // Function BTT_PatrolMoveTo.BTT_PatrolMoveTo_C.OnMoveFinished_FE88432F4C94B417B0F5D2AFC37F9732 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Interrupted_EC56B6BC4CEE3C3025E7A1B9BBD048A0(); // Function BTT_PatrolMoveTo.BTT_PatrolMoveTo_C.Interrupted_EC56B6BC4CEE3C3025E7A1B9BBD048A0 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Completed_EC56B6BC4CEE3C3025E7A1B9BBD048A0(); // Function BTT_PatrolMoveTo.BTT_PatrolMoveTo_C.Completed_EC56B6BC4CEE3C3025E7A1B9BBD048A0 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_PatrolMoveTo.BTT_PatrolMoveTo_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnAlreadyAtTargetLocation(); // Function BTT_PatrolMoveTo.BTT_PatrolMoveTo_C.OnAlreadyAtTargetLocation // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void Abort Patrol Montage(struct AActor* DamagedActor, float UnmodifiedDamageAmount, float ArmorDamageAmount, float HealthDamageAmount, struct FDamageEvent DamageEvent, struct AActor* CauseActor, enum class None DamageModifiersApplied, struct AController* InstigatorController, struct FS_PreTakeDamageInfo DamageInfo); // Function BTT_PatrolMoveTo.BTT_PatrolMoveTo_C.Abort Patrol Montage // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_PatrolMoveTo(int32_t EntryPoint); // Function BTT_PatrolMoveTo.BTT_PatrolMoveTo_C.ExecuteUbergraph_BTT_PatrolMoveTo // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

