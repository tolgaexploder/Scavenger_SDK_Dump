// BlueprintGeneratedClass BPI_AI_Boss.BPI_AI_Boss_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_AI_Boss_C : UInterface {

	void ReportDeathToGPM(); // Function BPI_AI_Boss.BPI_AI_Boss_C.ReportDeathToGPM // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsNamedBear(bool NamedBear); // Function BPI_AI_Boss.BPI_AI_Boss_C.IsNamedBear // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsNamedWarlord(bool NamedWarlord); // Function BPI_AI_Boss.BPI_AI_Boss_C.IsNamedWarlord // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void IsNamedBloatbile(bool NamedBloater); // Function BPI_AI_Boss.BPI_AI_Boss_C.IsNamedBloatbile // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void InitWanderingBoss(int32_t PointsValue); // Function BPI_AI_Boss.BPI_AI_Boss_C.InitWanderingBoss // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

