// BlueprintGeneratedClass GE_Last_Chance.GE_Last_Chance_C
// Size: 0x7c0 (Inherited: 0x7b8)
struct UGE_Last_Chance_C : UGameplayEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7b8(0x08)

	void ExecuteUbergraph_GE_Last_Chance(int32_t EntryPoint); // Function GE_Last_Chance.GE_Last_Chance_C.ExecuteUbergraph_GE_Last_Chance // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

