// BlueprintGeneratedClass BP_PlayerRadarComponent.BP_PlayerRadarComponent_C
// Size: 0x421 (Inherited: 0x350)
struct UBP_PlayerRadarComponent_C : US_PlayerRadarComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x350(0x08)
	struct FS_KRADLEnemyInfo ChampionKRADLEnemyInfo; // 0x358(0x40)
	struct FS_KRADLEnemyInfo outEnemyInfo; // 0x398(0x40)
	struct AActor* EnemyToTrack; // 0x3d8(0x08)
	int32_t Owner Team; // 0x3e0(0x04)
	struct FVector ScanningPlayerLocation; // 0x3e4(0x0c)
	struct AActor* OwnerCharacter; // 0x3f0(0x08)
	float ClosestEnemyDist; // 0x3f8(0x04)
	char UnknownData_3FC[0x4]; // 0x3fc(0x04)
	struct AActor* ClosestEnemy; // 0x400(0x08)
	bool TrackingEnabled; // 0x408(0x01)
	char UnknownData_409[0x7]; // 0x409(0x07)
	struct TArray<int32_t> Top3TeamIndexes; // 0x410(0x10)
	bool DoesModeSupportRadar; // 0x420(0x01)

	void TopTeamsTracking(); // Function BP_PlayerRadarComponent.BP_PlayerRadarComponent_C.TopTeamsTracking // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	bool IsVisibleToKRADLScan(); // Function BP_PlayerRadarComponent.BP_PlayerRadarComponent_C.IsVisibleToKRADLScan // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void FindNearestEnemy(); // Function BP_PlayerRadarComponent.BP_PlayerRadarComponent_C.FindNearestEnemy // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	bool OnAddEnemyInfo(struct FS_KRADLEnemyInfo inEnemyInfo, struct FS_KRADLEnemyInfo outEnemyInfo); // Function BP_PlayerRadarComponent.BP_PlayerRadarComponent_C.OnAddEnemyInfo // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnRadarFoundEnemy Event(struct FS_KRADLEnemyInfo EnemyInfo); // Function BP_PlayerRadarComponent.BP_PlayerRadarComponent_C.OnRadarFoundEnemy Event // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_PlayerRadarComponent(int32_t EntryPoint); // Function BP_PlayerRadarComponent.BP_PlayerRadarComponent_C.ExecuteUbergraph_BP_PlayerRadarComponent // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

