// BlueprintGeneratedClass BTT_CombatBloatbileVomit.BTT_CombatBloatbileVomit_C
// Size: 0xe8 (Inherited: 0xa8)
struct UBTT_CombatBloatbileVomit_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct AS_AICharacter* ScavengerAICharacter; // 0xb0(0x08)
	struct AS_AIController* ScavengerController; // 0xb8(0x08)
	struct AActor* CurrentTarget; // 0xc0(0x08)
	float AttackAlpha; // 0xc8(0x04)
	float AllowFireAngle; // 0xcc(0x04)
	struct FName IsAttackingWithMelee; // 0xd0(0x08)
	struct FName LastOffhandMeleeAttack; // 0xd8(0x08)
	struct FName StunProofAbilityKey; // 0xe0(0x08)

	void CountReached_EC16A6284F9A16CEFCCA1F821719CFD5(enum class ES_ScavengerResult Result); // Function BTT_CombatBloatbileVomit.BTT_CombatBloatbileVomit_C.CountReached_EC16A6284F9A16CEFCCA1F821719CFD5 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTT_CombatBloatbileVomit.BTT_CombatBloatbileVomit_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTT_CombatBloatbileVomit(int32_t EntryPoint); // Function BTT_CombatBloatbileVomit.BTT_CombatBloatbileVomit_C.ExecuteUbergraph_BTT_CombatBloatbileVomit // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

