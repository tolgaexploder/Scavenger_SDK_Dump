// BlueprintGeneratedClass BP_Pickup_i_food_rotten_guts.BP_Pickup_i_food_rotten_guts_C
// Size: 0x49d (Inherited: 0x490)
struct ABP_Pickup_i_food_rotten_guts_C : ABP_pickup_i_food_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x490(0x08)
	int32_t DynamicOppPointID; // 0x498(0x04)
	bool Consumed; // 0x49c(0x01)

	void OnRep_Consumed(); // Function BP_Pickup_i_food_rotten_guts.BP_Pickup_i_food_rotten_guts_C.OnRep_Consumed // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveBeginPlay(); // Function BP_Pickup_i_food_rotten_guts.BP_Pickup_i_food_rotten_guts_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void Consume_2(bool Consumed); // Function BP_Pickup_i_food_rotten_guts.BP_Pickup_i_food_rotten_guts_C.Consume_2 // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Pickup_i_food_rotten_guts(int32_t EntryPoint); // Function BP_Pickup_i_food_rotten_guts.BP_Pickup_i_food_rotten_guts_C.ExecuteUbergraph_BP_Pickup_i_food_rotten_guts // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

