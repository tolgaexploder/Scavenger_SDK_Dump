// BlueprintGeneratedClass BP_AutoPing_Lojack.BP_AutoPing_Lojack_C
// Size: 0x210 (Inherited: 0x209)
struct UBP_AutoPing_Lojack_C : UBP_AutoPing_C {
	char UnknownData_209[0x3]; // 0x209(0x03)
	int32_t RecentTeamIndex; // 0x20c(0x04)

	bool EvaluatePing_BP(struct AS_PlayerController* PlayerController); // Function BP_AutoPing_Lojack.BP_AutoPing_Lojack_C.EvaluatePing_BP // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

