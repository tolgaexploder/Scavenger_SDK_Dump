// BlueprintGeneratedClass BPI_ConsumableFriend.BPI_ConsumableFriend_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_ConsumableFriend_C : UInterface {

	void ConsumeAndBefriend(bool Consumed); // Function BPI_ConsumableFriend.BPI_ConsumableFriend_C.ConsumeAndBefriend // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
};

