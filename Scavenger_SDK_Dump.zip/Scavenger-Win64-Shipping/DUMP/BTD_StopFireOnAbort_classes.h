// BlueprintGeneratedClass BTD_StopFireOnAbort.BTD_StopFireOnAbort_C
// Size: 0xb8 (Inherited: 0xa0)
struct UBTD_StopFireOnAbort_C : UBTDecorator_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa0(0x08)
	struct FName IsInCover; // 0xa8(0x08)
	struct FName PursueTarget; // 0xb0(0x08)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_StopFireOnAbort.BTD_StopFireOnAbort_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecutionStart(struct AActor* OwnerActor); // Function BTD_StopFireOnAbort.BTD_StopFireOnAbort_C.ReceiveExecutionStart // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveExecutionFinish(struct AActor* OwnerActor, enum class EBTNodeResult NodeResult); // Function BTD_StopFireOnAbort.BTD_StopFireOnAbort_C.ReceiveExecutionFinish // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTD_StopFireOnAbort(int32_t EntryPoint); // Function BTD_StopFireOnAbort.BTD_StopFireOnAbort_C.ExecuteUbergraph_BTD_StopFireOnAbort // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

