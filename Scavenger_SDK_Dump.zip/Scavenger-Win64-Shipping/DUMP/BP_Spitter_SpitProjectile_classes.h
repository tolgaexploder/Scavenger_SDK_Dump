// BlueprintGeneratedClass BP_Spitter_SpitProjectile.BP_Spitter_SpitProjectile_C
// Size: 0x404 (Inherited: 0x3d8)
struct ABP_Spitter_SpitProjectile_C : AS_BulletProjectile {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d8(0x08)
	struct UAkComponent* AkVomitSound; // 0x3e0(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x3e8(0x08)
	struct UParticleSystemComponent* PS_Spitter_VomitProjectile; // 0x3f0(0x08)
	struct FVector Location; // 0x3f8(0x0c)

	void ReceiveBeginPlay(); // Function BP_Spitter_SpitProjectile.BP_Spitter_SpitProjectile_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void SpawnGroundMiasma(struct FVector Location); // Function BP_Spitter_SpitProjectile.BP_Spitter_SpitProjectile_C.SpawnGroundMiasma // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void SpawnGroundGoop(struct FVector Location); // Function BP_Spitter_SpitProjectile.BP_Spitter_SpitProjectile_C.SpawnGroundGoop // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void OnImpact(struct FHitResult ImpactResult); // Function BP_Spitter_SpitProjectile.BP_Spitter_SpitProjectile_C.OnImpact // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BP_Spitter_SpitProjectile(int32_t EntryPoint); // Function BP_Spitter_SpitProjectile.BP_Spitter_SpitProjectile_C.ExecuteUbergraph_BP_Spitter_SpitProjectile // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

