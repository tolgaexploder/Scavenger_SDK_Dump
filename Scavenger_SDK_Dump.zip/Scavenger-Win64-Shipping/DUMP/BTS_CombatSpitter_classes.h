// BlueprintGeneratedClass BTS_CombatSpitter.BTS_CombatSpitter_C
// Size: 0xec (Inherited: 0x98)
struct UBTS_CombatSpitter_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	struct AS_AICharacter* CachedAICharacter; // 0xa0(0x08)
	struct AS_AIController* CachedAIController; // 0xa8(0x08)
	struct FName HealthIsLow; // 0xb0(0x08)
	float DeltaSeconds; // 0xb8(0x04)
	float CurrentTime; // 0xbc(0x04)
	float CoverTimer; // 0xc0(0x04)
	float CoverCooldownDelay; // 0xc4(0x04)
	float LowHealthThreshold; // 0xc8(0x04)
	float ChargeHealthTrigger; // 0xcc(0x04)
	float SpitterRetreatTrigger; // 0xd0(0x04)
	float ExplodeHealthTrigger; // 0xd4(0x04)
	float TargetCloseRange; // 0xd8(0x04)
	float TimeInCloseRange; // 0xdc(0x04)
	bool LowHealth; // 0xe0(0x01)
	bool WasInCover; // 0xe1(0x01)
	bool WasHolding; // 0xe2(0x01)
	char UnknownData_E3[0x1]; // 0xe3(0x01)
	struct FName IsTurningInPlace; // 0xe4(0x08)

	void CheckTargetCloseRange(bool TargetInCloseRange); // Function BTS_CombatSpitter.BTS_CombatSpitter_C.CheckTargetCloseRange // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void UpdateHealthIsLow(); // Function BTS_CombatSpitter.BTS_CombatSpitter_C.UpdateHealthIsLow // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_CombatSpitter.BTS_CombatSpitter_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0xffff8009123b0000
	void unturning(); // Function BTS_CombatSpitter.BTS_CombatSpitter_C.unturning // (BlueprintCallable|BlueprintEvent) // @ game+0xffff8009123b0000
	void ExecuteUbergraph_BTS_CombatSpitter(int32_t EntryPoint); // Function BTS_CombatSpitter.BTS_CombatSpitter_C.ExecuteUbergraph_BTS_CombatSpitter // (Final|UbergraphFunction|HasDefaults) // @ game+0xffff8009123b0000
};

