// BlueprintGeneratedClass GE_StatsComponent_HealthMaximumChange.GE_StatsComponent_HealthMaximumChange_C
// Size: 0x7c0 (Inherited: 0x7b8)
struct UGE_StatsComponent_HealthMaximumChange_C : UGameplayEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7b8(0x08)

	void ExecuteUbergraph_GE_StatsComponent_HealthMaximumChange(int32_t EntryPoint); // Function GE_StatsComponent_HealthMaximumChange.GE_StatsComponent_HealthMaximumChange_C.ExecuteUbergraph_GE_StatsComponent_HealthMaximumChange // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

