// BlueprintGeneratedClass GE_Recovery.GE_Recovery_C
// Size: 0x7c0 (Inherited: 0x7b8)
struct UGE_Recovery_C : UGameplayEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7b8(0x08)

	void ExecuteUbergraph_GE_Recovery(int32_t EntryPoint); // Function GE_Recovery.GE_Recovery_C.ExecuteUbergraph_GE_Recovery // (Final|UbergraphFunction) // @ game+0xffff8009123b0000
};

